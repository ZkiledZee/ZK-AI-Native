import SwiftUI
import WebKit
import UIKit

// MARK: - Official cTrader market chart widget

struct CTraderMarketChart: View {
    @Environment(\.zkScale) private var scale
    let symbol: String

    @State private var loading = true
    @State private var failed = false
    @State private var errorText = ""
    @State private var reloadToken = UUID()

    var body: some View {
        ZStack {
            CTraderWidgetWebView(
                symbol: symbol,
                loading: $loading,
                failed: $failed,
                errorText: $errorText
            )
            .id("\(symbol)-\(reloadToken.uuidString)")

            if loading {
                VStack(spacing: 8 * scale) {
                    ProgressView().tint(ZKTheme.purple)
                    Text("Loading cTrader • \(symbol)")
                        .font(.system(size: 9 * scale, weight: .bold))
                        .foregroundStyle(ZKTheme.textMuted)
                }
                .padding(13 * scale)
                .background(ZKTheme.card.opacity(0.95))
                .clipShape(RoundedRectangle(cornerRadius: 13 * scale))
            }

            if failed {
                VStack(spacing: 9 * scale) {
                    Image(systemName: "wifi.exclamationmark")
                        .font(.system(size: 22 * scale, weight: .semibold))
                        .foregroundStyle(ZKTheme.gold)
                    Text("cTrader chart didn't load")
                        .font(.system(size: 11 * scale, weight: .bold))
                    Text(errorText.isEmpty ? "Open the Web terminal instead." : errorText)
                        .font(.system(size: 7.5 * scale, weight: .medium))
                        .foregroundStyle(ZKTheme.textMuted)
                        .multilineTextAlignment(.center)
                        .lineLimit(2)
                    HStack(spacing: 8 * scale) {
                        Button("Retry") {
                            loading = true
                            failed = false
                            errorText = ""
                            reloadToken = UUID()
                        }
                        .buttonStyle(.bordered)
                        .tint(ZKTheme.purple)

                        Button("cTrader Web") {
                            NotificationCenter.default.post(name: .zkOpenCTraderWeb, object: nil)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(ZKTheme.purple)
                    }
                    .font(.system(size: 8 * scale, weight: .black))
                }
                .padding(16 * scale)
                .background(ZKTheme.card.opacity(0.98))
                .overlay(RoundedRectangle(cornerRadius: 14 * scale).stroke(ZKTheme.border))
                .clipShape(RoundedRectangle(cornerRadius: 14 * scale))
                .padding(12 * scale)
            }
        }
        .background(Color.black)
        .clipShape(RoundedRectangle(cornerRadius: 16 * scale))
        .onChange(of: symbol) { _, _ in
            loading = true
            failed = false
            errorText = ""
            reloadToken = UUID()
        }
    }
}

private struct CTraderWidgetWebView: UIViewRepresentable {
    let symbol: String
    @Binding var loading: Bool
    @Binding var failed: Bool
    @Binding var errorText: String

    func makeCoordinator() -> Coordinator { Coordinator(parent: self) }

    func makeUIView(context: Context) -> WKWebView {
        let userContent = WKUserContentController()
        userContent.add(context.coordinator, name: "zkWidget")

        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        configuration.userContentController = userContent
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = true
        configuration.allowsInlineMediaPlayback = true

        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = .black
        webView.scrollView.backgroundColor = .black
        webView.scrollView.bounces = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.allowsLinkPreview = false

        context.coordinator.loadedSymbol = symbol
        webView.loadHTMLString(Self.html(symbol: symbol), baseURL: URL(string: "https://ct.spotware.com/"))
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        guard context.coordinator.loadedSymbol != symbol else { return }
        context.coordinator.loadedSymbol = symbol
        DispatchQueue.main.async {
            loading = true
            failed = false
            errorText = ""
        }
        webView.loadHTMLString(Self.html(symbol: symbol), baseURL: URL(string: "https://ct.spotware.com/"))
    }

    static func dismantleUIView(_ uiView: WKWebView, coordinator: Coordinator) {
        uiView.configuration.userContentController.removeScriptMessageHandler(forName: "zkWidget")
    }

    private static func html(symbol: String) -> String {
        let clean = symbol
            .replacingOccurrences(of: "\"", with: "")
            .replacingOccurrences(of: "'", with: "")
            .replacingOccurrences(of: "<", with: "")
            .replacingOccurrences(of: ">", with: "")

        // cTrader's documented embed requires width/height on the root element itself.
        // The previous build only set those through CSS, which could leave the plugin with a zero-sized root.
        return """
        <!doctype html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
          <style>
            html, body { margin:0; padding:0; width:100%; height:100%; overflow:hidden; background:#050508; }
            body { display:block; }
          </style>
        </head>
        <body>
          <div id="ctrader-plugin-root" style="width:100%; height:100%; position:relative"></div>
          <script>
            (function () {
              const root = document.getElementById('ctrader-plugin-root');
              let finished = false;
              const report = (value) => {
                try { window.webkit.messageHandlers.zkWidget.postMessage(value); } catch (_) {}
              };
              const ready = () => {
                if (finished) return;
                if (root && root.children && root.children.length > 0) {
                  finished = true;
                  report('ready');
                }
              };
              new MutationObserver(ready).observe(root, { childList:true, subtree:true });
              window.addEventListener('error', (e) => report('error:' + (e.message || 'widget script error')));
              setTimeout(() => {
                ready();
                if (!finished) report('error:cTrader widget timed out');
              }, 12000);
            })();
          </script>
          <script id="init" type="text/javascript" defer src="https://ct.spotware.com/widget.js"></script>
          <script type="text/javascript">
            const script = document.getElementById('init');
            script.onerror = () => {
              try { window.webkit.messageHandlers.zkWidget.postMessage('error:Could not reach ct.spotware.com'); } catch (_) {}
            };
            script.onload = () => {
              try {
                putInitScript('runPlugin');
                runPlugin('ctrader-plugin-root', {"route":"/market-chart/?s=\(clean)&period=M1&charttype=candlestick&palettename=dark&lang=en&w=900&h=900"});
              } catch (e) {
                try { window.webkit.messageHandlers.zkWidget.postMessage('error:' + e.message); } catch (_) {}
              }
            };
          </script>
        </body>
        </html>
        """
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
        var parent: CTraderWidgetWebView
        var loadedSymbol = ""

        init(parent: CTraderWidgetWebView) { self.parent = parent }

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            guard message.name == "zkWidget", let value = message.body as? String else { return }
            DispatchQueue.main.async {
                if value == "ready" {
                    self.parent.loading = false
                    self.parent.failed = false
                    self.parent.errorText = ""
                } else if value.hasPrefix("error:") {
                    self.parent.loading = false
                    self.parent.failed = true
                    self.parent.errorText = String(value.dropFirst(6))
                }
            }
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            fail(error.localizedDescription)
        }

        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            fail(error.localizedDescription)
        }

        private func fail(_ text: String) {
            DispatchQueue.main.async {
                self.parent.loading = false
                self.parent.failed = true
                self.parent.errorText = text
            }
        }

        func webView(
            _ webView: WKWebView,
            createWebViewWith configuration: WKWebViewConfiguration,
            for navigationAction: WKNavigationAction,
            windowFeatures: WKWindowFeatures
        ) -> WKWebView? {
            if navigationAction.targetFrame == nil, let url = navigationAction.request.url {
                webView.load(URLRequest(url: url))
            }
            return nil
        }
    }
}

// MARK: - Browser-style cTrader Web terminal

extension Notification.Name {
    static let zkOpenCTraderWeb = Notification.Name("zk.open.cTraderWeb")
}

@MainActor
final class CTraderBrowserState: ObservableObject {
    @Published var isLoading = true
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var host = "app.ctrader.com"
    @Published var errorMessage: String?

    weak var webView: WKWebView?

    static let homeURL = URL(string: "https://app.ctrader.com/?lang=en&theme=dark")!
    static let icLoginURL = URL(string: "https://id-ct.icmarkets.com/login?onSuccess=cTwebSilent")!

    func attach(_ webView: WKWebView) {
        // Attach only once. Calling sync() from every SwiftUI update can create a
        // publish -> updateUIView -> publish feedback loop that locks the main thread.
        guard self.webView !== webView else { return }
        self.webView = webView
        sync(webView)
    }

    func sync(_ webView: WKWebView) {
        // Only publish when values actually change. This keeps WKWebView navigation
        // state from continuously invalidating the SwiftUI hierarchy.
        let newCanGoBack = webView.canGoBack
        let newCanGoForward = webView.canGoForward
        let newHost = webView.url?.host ?? "app.ctrader.com"

        if canGoBack != newCanGoBack { canGoBack = newCanGoBack }
        if canGoForward != newCanGoForward { canGoForward = newCanGoForward }
        if host != newHost { host = newHost }
    }

    func goBack() { webView?.goBack() }
    func goForward() { webView?.goForward() }
    func reload() { webView?.reload() }
    func stop() { webView?.stopLoading() }

    func goHome() {
        webView?.load(URLRequest(url: Self.homeURL, cachePolicy: .reloadRevalidatingCacheData, timeoutInterval: 30))
    }

    func openICLogin() {
        webView?.load(URLRequest(url: Self.icLoginURL, cachePolicy: .reloadRevalidatingCacheData, timeoutInterval: 30))
    }

    func openExternally() {
        guard let url = webView?.url ?? Optional(Self.homeURL) else { return }
        UIApplication.shared.open(url)
    }
}

struct CTraderBrowserWindow: View {
    @Environment(\.zkScale) private var scale
    @StateObject private var browser = CTraderBrowserState()

    var body: some View {
        VStack(spacing: 0) {
            browserChrome

            ZStack(alignment: .top) {
                CTraderDirectWebView(browser: browser, initialURL: CTraderBrowserState.homeURL)

                if browser.isLoading {
                    ProgressView()
                        .tint(ZKTheme.purple)
                        .padding(.top, 12 * scale)
                }

                if let error = browser.errorMessage {
                    errorOverlay(error)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .background(Color.black)
        .clipShape(RoundedRectangle(cornerRadius: 16 * scale))
        .overlay(RoundedRectangle(cornerRadius: 16 * scale).stroke(ZKTheme.borderStrong.opacity(0.82)))
        .onReceive(NotificationCenter.default.publisher(for: .zkOpenCTraderWeb)) { _ in
            browser.goHome()
        }
    }

    private var browserChrome: some View {
        VStack(spacing: 6 * scale) {
            HStack(spacing: 7 * scale) {
                Circle()
                    .fill(ZKTheme.green)
                    .frame(width: 6 * scale, height: 6 * scale)

                Image(systemName: "lock.fill")
                    .font(.system(size: 7 * scale, weight: .bold))
                    .foregroundStyle(ZKTheme.textMuted)

                Text(browser.host)
                    .font(.system(size: 8.5 * scale, weight: .bold, design: .rounded))
                    .foregroundStyle(ZKTheme.textSoft)
                    .lineLimit(1)

                Spacer(minLength: 4)

                Button("IC LOGIN") { browser.openICLogin() }
                    .font(.system(size: 7 * scale, weight: .black, design: .rounded))
                    .foregroundStyle(ZKTheme.purpleLight)
                    .buttonStyle(.plain)
            }

            HStack(spacing: 5 * scale) {
                browserButton("chevron.left", enabled: browser.canGoBack) { browser.goBack() }
                browserButton("chevron.right", enabled: browser.canGoForward) { browser.goForward() }
                browserButton("house", enabled: true) { browser.goHome() }
                browserButton(browser.isLoading ? "xmark" : "arrow.clockwise", enabled: true) {
                    browser.isLoading ? browser.stop() : browser.reload()
                }

                Spacer()

                Text("cTrader Web")
                    .font(.system(size: 7.5 * scale, weight: .black, design: .rounded))
                    .foregroundStyle(ZKTheme.textMuted)

                Spacer()

                browserButton("safari", enabled: true) { browser.openExternally() }
            }
        }
        .padding(.horizontal, 10 * scale)
        .padding(.vertical, 8 * scale)
        .background(ZKTheme.card.opacity(0.96))
        .overlay(alignment: .bottom) { Rectangle().fill(ZKTheme.border.opacity(0.8)).frame(height: 0.5) }
    }

    private func browserButton(_ icon: String, enabled: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 9 * scale, weight: .semibold))
                .foregroundStyle(enabled ? ZKTheme.textSoft : ZKTheme.textMuted.opacity(0.35))
                .frame(width: 28 * scale, height: 24 * scale)
                .background(ZKTheme.background.opacity(0.72))
                .clipShape(RoundedRectangle(cornerRadius: 7 * scale))
        }
        .buttonStyle(.plain)
        .disabled(!enabled)
    }

    private func errorOverlay(_ error: String) -> some View {
        VStack(spacing: 9 * scale) {
            Image(systemName: "network.slash")
                .font(.system(size: 22 * scale, weight: .semibold))
                .foregroundStyle(ZKTheme.gold)
            Text("cTrader Web couldn't open")
                .font(.system(size: 11 * scale, weight: .black))
            Text(error)
                .font(.system(size: 7.5 * scale, weight: .medium))
                .foregroundStyle(ZKTheme.textMuted)
                .multilineTextAlignment(.center)
                .lineLimit(3)
            Button("Reload") {
                browser.errorMessage = nil
                browser.goHome()
            }
            .font(.system(size: 8 * scale, weight: .black))
            .buttonStyle(.borderedProminent)
            .tint(ZKTheme.purple)
        }
        .padding(18 * scale)
        .background(ZKTheme.card.opacity(0.98))
        .clipShape(RoundedRectangle(cornerRadius: 14 * scale))
        .padding(14 * scale)
    }
}

private struct CTraderDirectWebView: UIViewRepresentable {
    @ObservedObject var browser: CTraderBrowserState
    let initialURL: URL

    func makeCoordinator() -> Coordinator { Coordinator(browser: browser) }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        configuration.defaultWebpagePreferences.preferredContentMode = .desktop
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = true
        configuration.allowsInlineMediaPlayback = true

        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = .black
        webView.scrollView.backgroundColor = .black
        webView.scrollView.keyboardDismissMode = .interactive
        webView.scrollView.bounces = true
        webView.allowsBackForwardNavigationGestures = true
        webView.allowsLinkPreview = false

        // cTrader Web is a desktop-class web app. Request its desktop layout instead of a mobile fallback.
        webView.customUserAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15"
        webView.pageZoom = 0.68

        // Defer the ObservableObject attachment until after SwiftUI has finished
        // creating the representable. This avoids publishing state from makeUIView.
        DispatchQueue.main.async { [weak webView] in
            guard let webView else { return }
            browser.attach(webView)
        }
        webView.load(URLRequest(url: initialURL, cachePolicy: .useProtocolCachePolicy, timeoutInterval: 30))
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        // Intentionally no state publishing here. updateUIView is called as a result
        // of SwiftUI state changes, so publishing more @Published values from this
        // callback can recurse indefinitely and freeze the whole app.
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        let browser: CTraderBrowserState

        init(browser: CTraderBrowserState) { self.browser = browser }

        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            Task { @MainActor in
                browser.isLoading = true
                browser.errorMessage = nil
                browser.sync(webView)
            }
        }

        func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
            Task { @MainActor in browser.sync(webView) }
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            Task { @MainActor in
                browser.isLoading = false
                browser.errorMessage = nil
                browser.sync(webView)
            }
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            fail(error, webView: webView)
        }

        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            fail(error, webView: webView)
        }

        private func fail(_ error: Error, webView: WKWebView) {
            let ns = error as NSError
            // -999 is WebKit's normal cancellation code when a navigation is replaced.
            if ns.code == NSURLErrorCancelled { return }
            Task { @MainActor in
                browser.isLoading = false
                browser.errorMessage = error.localizedDescription
                browser.sync(webView)
            }
        }

        func webView(
            _ webView: WKWebView,
            decidePolicyFor navigationAction: WKNavigationAction,
            decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
        ) {
            guard let url = navigationAction.request.url else {
                decisionHandler(.allow)
                return
            }

            let scheme = url.scheme?.lowercased() ?? ""
            if scheme == "http" || scheme == "https" || scheme == "about" {
                if navigationAction.targetFrame == nil {
                    webView.load(navigationAction.request)
                    decisionHandler(.cancel)
                } else {
                    decisionHandler(.allow)
                }
                return
            }

            if UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url)
            }
            decisionHandler(.cancel)
        }

        func webView(
            _ webView: WKWebView,
            createWebViewWith configuration: WKWebViewConfiguration,
            for navigationAction: WKNavigationAction,
            windowFeatures: WKWindowFeatures
        ) -> WKWebView? {
            if let url = navigationAction.request.url {
                webView.load(URLRequest(url: url))
            }
            return nil
        }
    }
}
