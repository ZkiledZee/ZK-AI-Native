# ZK AI Native v0.6.1 — Local AI crash fix

This is a stability patch for v0.6.0 local chat.

## Root cause fixed
The pinned SwiftLlama generation path submits the complete prompt into one `llama_batch`. v0.6.0 configured `batchSize: 256`, while ZK AI injects app context + recent candles + conversation, so a normal prompt can exceed 256 tokens. SwiftLlama writes those prompt tokens into the C batch without a capacity guard, which can terminate the process with an out-of-bounds native memory write instead of throwing a Swift error.

## v0.6.1 changes
- raises the inference batch to 4096 to match the 4096-token context window
- caps the composed prompt to 6000 characters and trims individual history turns
- reduces raw injected candle rows from 24 to 12 while keeping full calculated market features
- reduces response ceiling from 420 to 300 tokens to leave more KV/context headroom
- defaults the local model to CPU compatibility mode for first-run stability on lower-memory iPhones
- keeps the downloaded GGUF in Application Support; updating over v0.6.0 should not require downloading the model again
- exposes the current prompt character count in Settings for diagnostics

Once this path is verified stable on-device, Metal acceleration can be reintroduced as an optional Fast mode without changing the model.
