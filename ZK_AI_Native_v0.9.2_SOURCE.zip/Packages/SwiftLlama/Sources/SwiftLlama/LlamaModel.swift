import Foundation
import os.log

public final class LlamaModel: @unchecked Sendable {
    public let model: OpaquePointer
    public let vocab: OpaquePointer
    public let config: ModelConfig

    private static let logger = Logger(subsystem: "com.zk.swift-llama", category: "LlamaModel")

    public init(path: String, config: ModelConfig = ModelConfig()) throws {
        guard FileManager.default.fileExists(atPath: path) else {
            throw LlamaError.invalidModelPath(path)
        }
        llama_backend_init()
        var modelParams = llama_model_default_params()
        modelParams.use_mmap = true
        modelParams.use_mlock = false
        modelParams.n_gpu_layers = config.gpuLayers.rawValue
        guard let model = llama_model_load_from_file(path, modelParams) else {
            throw LlamaError.failedToLoadModel(path: path)
        }
        self.model = model
        self.vocab = llama_model_get_vocab(model)
        self.config = config
        Self.logger.info("Model loaded; GPU layers: \(config.gpuLayers.rawValue)")
    }

    public func makeContext() throws -> LlamaContext { try LlamaContext(model: self) }

    deinit {
        llama_model_free(model)
        llama_backend_free()
    }
}
