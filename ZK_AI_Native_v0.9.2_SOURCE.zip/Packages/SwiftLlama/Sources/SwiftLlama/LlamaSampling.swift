import Foundation

/// Stability-first sampler for iOS.
///
/// llama.cpp has had iOS crashes when top-k/top-p sampler chains are combined in
/// SwiftUI integrations. For the first stable ZK AI build we deliberately use the
/// core greedy sampler only. Once inference is proven stable on-device we can add
/// controlled randomness back one sampler at a time.
public final class LlamaSampling: @unchecked Sendable {
    let sampler: UnsafeMutablePointer<llama_sampler>

    public init(params: SamplingParams = .greedy) {
        guard let greedy = llama_sampler_init_greedy() else {
            fatalError("llama_sampler_init_greedy failed")
        }
        self.sampler = greedy
    }

    func sample(context: OpaquePointer) -> llama_token {
        // -1 means the last output from the most recent llama_decode, matching the
        // official llama.cpp simple example and avoiding output-index ambiguity.
        llama_sampler_sample(sampler, context, -1)
    }

    func reset() {
        llama_sampler_reset(sampler)
    }

    deinit {
        llama_sampler_free(sampler)
    }
}
