# Third-party notices

## Qwen2.5-0.5B-Instruct-GGUF

The app offers an optional user-initiated download of `Qwen/Qwen2.5-0.5B-Instruct-GGUF` from Hugging Face. The model repository identifies the model license as Apache-2.0. Model weights are not redistributed inside this source archive or IPA.

## Qwen2.5-1.5B-Instruct-GGUF

The app also offers an optional user-initiated download of `Qwen/Qwen2.5-1.5B-Instruct-GGUF` from Hugging Face. The model repository identifies the model license as Apache-2.0. The v0.8 Smart option uses the official Q3_K_M GGUF. Model weights are not redistributed inside this source archive or IPA.

## swift-llama / llama.cpp

This source archive contains a small modified subset of the MIT-licensed SwiftLlama wrapper so ZK AI can use bounded/chunked prompt prefill and the proven stable greedy sampling path on iOS. The original SwiftLlama copyright and MIT license are preserved in `Packages/SwiftLlama/LICENSE`.

The local package links the pinned pre-built llama.cpp Apple XCFramework from the upstream llama.cpp release and remains subject to its upstream license.
