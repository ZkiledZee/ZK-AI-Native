import SwiftUI

@main
struct ZKAINativeApp: App {
    @StateObject private var state = AppState()
    @StateObject private var market = MarketDataService()
    @StateObject private var ai = LocalAIService()
    @StateObject private var signalEngine = SignalEngine()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(state)
                .environmentObject(market)
                .environmentObject(ai)
                .environmentObject(signalEngine)
                .preferredColorScheme(.dark)
                .task {
                    market.start()
                    signalEngine.start(market: market, state: state)
                }
        }
    }
}
