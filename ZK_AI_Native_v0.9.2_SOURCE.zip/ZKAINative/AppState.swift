import SwiftUI
import Foundation

@MainActor
final class AppState: ObservableObject {
    @Published var page: ZKPage = .home
    @Published var signal: SignalSnapshot = .dataOnly
    @Published var models: [ModelRecord] = ModelRecord.seed
    @Published var selectedModelID: UUID?
    @Published var drawings: [ChartDrawing] = []
    @Published var journal: [TradeJournalEntry] = []
    @Published var macroCoverage: Double = 0
    @Published var macroRegime: String = "NO MACRO DATA"
    @Published var agentLoaded = false
    @Published var chartMode: Int = UserDefaults.standard.integer(forKey: "zk.settings.chartMode")
    @Published var notificationPermission = false
    @Published var pendingChatPrompt: String?
    @Published var agentSteps: [AgentStep] = []
    @Published private(set) var chatThreads: [ChatThread] = []
    @Published private(set) var currentThreadID: UUID?
    @Published var chatMessages: [ChatMessage] = []

    private(set) var installID: String = ""
    private(set) var launchCount: Int = 0

    private let welcomeText = "ZK AI is local, app-aware and chart-aware. I can inspect the same 1M chart used by the Signal Engine, explain its current paper setup, call app tools, draw levels, navigate the app and keep this conversation on your iPhone."

    init() {
        let defaults = UserDefaults.standard
        let existing = defaults.string(forKey: "zk.installID")
        let id = existing ?? UUID().uuidString
        if existing == nil { defaults.set(id, forKey: "zk.installID") }

        let nextCount = defaults.integer(forKey: "zk.launchCount") + 1
        defaults.set(nextCount, forKey: "zk.launchCount")

        installID = id
        launchCount = nextCount
        selectedModelID = models.first?.id
        loadDrawings()
        loadChats()
    }

    var selectedModel: ModelRecord? {
        models.first(where: { $0.id == selectedModelID })
    }

    var currentThread: ChatThread? {
        guard let currentThreadID else { return nil }
        return chatThreads.first(where: { $0.id == currentThreadID })
    }

    func go(_ destination: ZKPage) {
        if destination == .chart {
            chartMode = UserDefaults.standard.integer(forKey: "zk.settings.chartMode")
        }
        withAnimation(.easeOut(duration: 0.18)) { page = destination }
    }

    func replaceSupportResistance(around passedPrice: Double? = nil) {
        guard let price = referencePrice(passedPrice) else { return }
        let distance = max(price * 0.0012, 4.0)
        drawings.removeAll { $0.kind == .support || $0.kind == .resistance }
        drawings.append(.init(kind: .support, price: price - distance, label: "SUPPORT"))
        drawings.append(.init(kind: .resistance, price: price + distance, label: "RESISTANCE"))
        persistDrawings()
    }

    func addZone(around passedPrice: Double? = nil) {
        guard let price = referencePrice(passedPrice) else { return }
        let half = max(price * 0.00035, 1.25)
        drawings.removeAll { $0.kind == .zone }
        drawings.append(.init(kind: .zone, price: price - half, secondaryPrice: price + half, label: "MARKET ZONE"))
        persistDrawings()
    }

    func setAILevels(support: Double?, resistance: Double?) {
        drawings.removeAll { $0.kind == .support || $0.kind == .resistance }
        if let support, support > 0 { drawings.append(.init(kind: .support, price: support, label: "AI SUPPORT")) }
        if let resistance, resistance > 0 { drawings.append(.init(kind: .resistance, price: resistance, label: "AI RESISTANCE")) }
        persistDrawings()
    }

    func askAI(_ prompt: String) {
        pendingChatPrompt = prompt
        go(.chat)
    }

    func removeLastDrawing() {
        guard !drawings.isEmpty else { return }
        drawings.removeLast(); persistDrawings()
    }

    func clearAllDrawings() { drawings.removeAll(); persistDrawings() }
    func removeSupport() { drawings.removeAll { $0.kind == .support }; persistDrawings() }
    func removeResistance() { drawings.removeAll { $0.kind == .resistance }; persistDrawings() }

    private func referencePrice(_ passedPrice: Double?) -> Double? {
        if let passedPrice, passedPrice > 0 { return passedPrice }
        let saved = UserDefaults.standard.double(forKey: "zk.lastMarketPrice")
        return saved > 0 ? saved : nil
    }

    private func persistDrawings() {
        if let data = try? JSONEncoder().encode(drawings) { UserDefaults.standard.set(data, forKey: "zk.drawings") }
    }

    private func loadDrawings() {
        guard let data = UserDefaults.standard.data(forKey: "zk.drawings"),
              let decoded = try? JSONDecoder().decode([ChartDrawing].self, from: data) else { return }
        drawings = decoded.filter { !$0.label.uppercased().contains("DEMO") }
    }

    // MARK: - Persistent local conversations

    func appendUserMessage(_ text: String) {
        ensureThread()
        chatMessages.append(.init(role: .user, text: text))
        if let firstUser = chatMessages.first(where: { $0.role == .user }), firstUser.text == text {
            setCurrentTitle(makeTitle(text))
        }
        persistCurrentChat()
    }

    @discardableResult
    func appendAssistantMessage(_ text: String = "") -> UUID {
        ensureThread()
        let message = ChatMessage(role: .assistant, text: text)
        chatMessages.append(message)
        persistCurrentChat()
        return message.id
    }

    func appendToAssistantMessage(id: UUID, token: String) {
        guard let index = chatMessages.firstIndex(where: { $0.id == id }) else { return }
        chatMessages[index].text += token
        // Persist continuously so a background termination does not erase the conversation.
        persistCurrentChat()
    }

    func replaceAssistantMessage(id: UUID, text: String) {
        guard let index = chatMessages.firstIndex(where: { $0.id == id }) else { return }
        chatMessages[index].text = text
        persistCurrentChat()
    }

    func newChat() {
        persistCurrentChat()
        let thread = ChatThread(title: "New analysis", messages: [.init(role: .assistant, text: welcomeText)])
        chatThreads.insert(thread, at: 0)
        currentThreadID = thread.id
        chatMessages = thread.messages
        agentSteps = []
        persistChats()
    }

    func selectChat(_ id: UUID) {
        persistCurrentChat()
        guard let thread = chatThreads.first(where: { $0.id == id }) else { return }
        currentThreadID = id
        chatMessages = thread.messages
        agentSteps = []
        persistChats()
    }

    func deleteChat(_ id: UUID) {
        chatThreads.removeAll { $0.id == id }
        if currentThreadID == id {
            if let next = chatThreads.first {
                currentThreadID = next.id
                chatMessages = next.messages
            } else {
                let thread = ChatThread(title: "New analysis", messages: [.init(role: .assistant, text: welcomeText)])
                chatThreads = [thread]
                currentThreadID = thread.id
                chatMessages = thread.messages
            }
        }
        persistChats()
    }

    func clearChat() { newChat() }

    func renameCurrentChat(_ title: String) {
        let clean = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return }
        setCurrentTitle(String(clean.prefix(44)))
        persistChats()
    }

    func setAgentSteps(_ steps: [AgentStep]) { agentSteps = steps }

    func updateAgentStep(index: Int, status: AgentStep.Status, detail: String? = nil) {
        guard agentSteps.indices.contains(index) else { return }
        agentSteps[index].status = status
        if let detail { agentSteps[index].detail = detail }
    }

    private func ensureThread() {
        if currentThreadID == nil || chatThreads.isEmpty { newChat() }
    }

    private func setCurrentTitle(_ title: String) {
        guard let id = currentThreadID, let index = chatThreads.firstIndex(where: { $0.id == id }) else { return }
        chatThreads[index].title = title
        chatThreads[index].updatedAt = Date()
    }

    private func persistCurrentChat() {
        guard let id = currentThreadID, let index = chatThreads.firstIndex(where: { $0.id == id }) else { return }
        chatThreads[index].messages = chatMessages
        chatThreads[index].updatedAt = Date()
        chatThreads.sort { $0.updatedAt > $1.updatedAt }
        persistChats()
    }

    private func persistChats() {
        if let data = try? JSONEncoder().encode(chatThreads) {
            UserDefaults.standard.set(data, forKey: "zk.chat.threads.v1")
        }
        if let currentThreadID { UserDefaults.standard.set(currentThreadID.uuidString, forKey: "zk.chat.current") }
    }

    private func loadChats() {
        let defaults = UserDefaults.standard
        if let data = defaults.data(forKey: "zk.chat.threads.v1"),
           let decoded = try? JSONDecoder().decode([ChatThread].self, from: data),
           !decoded.isEmpty {
            chatThreads = decoded.sorted { $0.updatedAt > $1.updatedAt }
            if let raw = defaults.string(forKey: "zk.chat.current"), let id = UUID(uuidString: raw), let selected = chatThreads.first(where: { $0.id == id }) {
                currentThreadID = selected.id
                chatMessages = selected.messages
            } else if let first = chatThreads.first {
                currentThreadID = first.id
                chatMessages = first.messages
            }
            return
        }
        let thread = ChatThread(title: "ZK Agent", messages: [.init(role: .assistant, text: welcomeText)])
        chatThreads = [thread]
        currentThreadID = thread.id
        chatMessages = thread.messages
        persistChats()
    }

    private func makeTitle(_ text: String) -> String {
        let line = text.replacingOccurrences(of: "\n", with: " ").trimmingCharacters(in: .whitespacesAndNewlines)
        if line.isEmpty { return "New analysis" }
        return String(line.prefix(42))
    }
}
