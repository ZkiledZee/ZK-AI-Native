import SwiftUI

struct AILabView: View {
    @EnvironmentObject private var state: AppState
    @EnvironmentObject private var ai: LocalAIService
    @Environment(\.zkScale) private var scale
    @State private var showAdvanced = false

    var body: some View {
        ScrollView {
            VStack(spacing: 10 * scale) {
                ZKPageHeader(
                    micro: "AI + MODELS",
                    title: "AI Lab",
                    pill: ai.isReady ? "READY" : "LOCAL",
                    pillColor: ai.isReady ? ZKTheme.green : ZKTheme.purple
                )

                agentCard
                tradingModelCard
                modelVaultCard
                advancedCard
            }
            .padding(.horizontal, 16 * scale)
            .padding(.top, 8 * scale)
            .padding(.bottom, 18 * scale)
        }
        .scrollIndicators(.hidden)
        .background(ZKTheme.background)
    }

    private var agentCard: some View {
        ZKCard(strongBorder: true) {
            HStack(spacing: 11 * scale) {
                Image(systemName: "brain.head.profile.fill")
                    .font(.system(size: 20 * scale, weight: .bold))
                    .foregroundStyle(ai.isReady ? ZKTheme.green : ZKTheme.purple)
                    .frame(width: 44 * scale, height: 44 * scale)
                    .background((ai.isReady ? ZKTheme.green : ZKTheme.purple).opacity(0.08))
                    .clipShape(RoundedRectangle(cornerRadius: 13 * scale))

                VStack(alignment: .leading, spacing: 3 * scale) {
                    Text("ZK AGENT")
                        .font(.system(size: 8 * scale, weight: .black))
                        .foregroundStyle(ZKTheme.textMuted)
                    Text(ai.modelName)
                        .font(.system(size: 12 * scale, weight: .bold))
                        .lineLimit(1)
                    Text(ai.isReady ? "Ready on device" : ai.statusDetail)
                        .font(.system(size: 8 * scale, weight: .medium))
                        .foregroundStyle(ai.isReady ? ZKTheme.green : ZKTheme.textMuted)
                        .lineLimit(1)
                }

                Spacer()

                Button { state.go(.chat) } label: {
                    Image(systemName: "arrow.right")
                        .font(.system(size: 13 * scale, weight: .black))
                        .foregroundStyle(.white)
                        .frame(width: 34 * scale, height: 34 * scale)
                        .background(ZKTheme.accentGradient)
                        .clipShape(Circle())
                }
                .buttonStyle(ZKPressStyle())
            }
        }
    }

    private var tradingModelCard: some View {
        ZKCard {
            VStack(alignment: .leading, spacing: 9 * scale) {
                HStack {
                    VStack(alignment: .leading, spacing: 2 * scale) {
                        Text("TRADING MODEL")
                            .font(.system(size: 8 * scale, weight: .black))
                            .foregroundStyle(ZKTheme.textMuted)
                        Text(state.selectedModel?.name ?? "No model")
                            .font(.system(size: 13 * scale, weight: .bold))
                            .lineLimit(1)
                    }
                    Spacer()
                    Text(state.selectedModel?.status ?? "EMPTY")
                        .font(.system(size: 7.5 * scale, weight: .black))
                        .foregroundStyle(ZKTheme.gold)
                        .padding(.horizontal, 9 * scale)
                        .frame(height: 25 * scale)
                        .background(ZKTheme.gold.opacity(0.06))
                        .clipShape(Capsule())
                }

                if let model = state.selectedModel {
                    HStack(spacing: 5 * scale) {
                        MetricCell(label: "TRADES", value: "\(model.resolvedTrades)")
                        MetricCell(label: "PF", value: model.profitFactor.map { String(format: "%.2f", $0) } ?? "—")
                        MetricCell(label: "EXP", value: model.expectancyR.map { String(format: "%+.2fR", $0) } ?? "—")
                        MetricCell(label: "DD", value: model.drawdownR.map { String(format: "%.1fR", $0) } ?? "—")
                    }
                }
            }
        }
    }

    private var modelVaultCard: some View {
        ZKCard {
            HStack(spacing: 10 * scale) {
                VStack(alignment: .leading, spacing: 2 * scale) {
                    Text("MODEL VAULT")
                        .font(.system(size: 8 * scale, weight: .black))
                        .foregroundStyle(ZKTheme.textMuted)
                    Text("\(state.models.count) saved")
                        .font(.system(size: 10 * scale, weight: .bold))
                }
                Spacer()
                Menu {
                    ForEach(state.models) { model in
                        Button("\(model.status) • \(model.name)") { state.selectedModelID = model.id }
                    }
                } label: {
                    HStack(spacing: 6 * scale) {
                        Text(state.selectedModel?.status ?? "SELECT")
                            .font(.system(size: 8.5 * scale, weight: .black))
                        Image(systemName: "chevron.down")
                            .font(.system(size: 8 * scale, weight: .bold))
                    }
                    .foregroundStyle(.white)
                    .padding(.horizontal, 11 * scale)
                    .frame(height: 31 * scale)
                    .background(ZKTheme.card2)
                    .overlay(Capsule().stroke(ZKTheme.borderStrong))
                    .clipShape(Capsule())
                }
            }
        }
    }

    private var advancedCard: some View {
        ZKCard {
            DisclosureGroup(isExpanded: $showAdvanced) {
                VStack(spacing: 9 * scale) {
                    Divider().overlay(ZKTheme.border)
                    compactRow("Macro coverage", "\(Int(state.macroCoverage * 100))%", state.macroCoverage >= 0.6 ? ZKTheme.green : ZKTheme.textMuted)
                    compactRow("Journal", "\(state.journal.count) trades", ZKTheme.textSoft)
                    compactRow("Architecture", "Agent + separate market model", ZKTheme.purple)
                }
                .padding(.top, 7 * scale)
            } label: {
                HStack {
                    Text("ADVANCED")
                        .font(.system(size: 8 * scale, weight: .black))
                        .foregroundStyle(ZKTheme.textMuted)
                    Spacer()
                    Text(showAdvanced ? "HIDE" : "SHOW")
                        .font(.system(size: 7 * scale, weight: .black))
                        .foregroundStyle(ZKTheme.purple)
                }
            }
            .tint(ZKTheme.purple)
        }
    }

    private func compactRow(_ title: String, _ value: String, _ color: Color) -> some View {
        HStack {
            Text(title)
                .font(.system(size: 9 * scale, weight: .semibold))
                .foregroundStyle(ZKTheme.textMuted)
            Spacer()
            Text(value)
                .font(.system(size: 9 * scale, weight: .bold))
                .foregroundStyle(color)
                .lineLimit(1)
        }
    }
}
