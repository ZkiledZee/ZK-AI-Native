import SwiftUI

struct ChartView: View {
    @EnvironmentObject private var state: AppState
    @EnvironmentObject private var market: MarketDataService
    @Environment(\.zkScale) private var scale

    var body: some View {
        VStack(spacing: 8 * scale) {
            ZKPageHeader(
                micro: "XAUUSD • 1M",
                title: "Chart",
                pill: state.chartMode == 0 ? "ICM TV" : market.feedStatus.rawValue,
                pillColor: state.chartMode == 0 ? ZKTheme.green : feedColor
            )

            controls
            chartArea
        }
        .padding(.horizontal, 14 * scale)
        .padding(.top, 8 * scale)
        .padding(.bottom, 8 * scale)
        .background(ZKTheme.background)
        .refreshable { await market.refreshAll() }
        .onChange(of: state.chartMode) { _, newValue in
            UserDefaults.standard.set(newValue, forKey: "zk.settings.chartMode")
        }
    }

    private var controls: some View {
        HStack(spacing: 8 * scale) {
            HStack(spacing: 4 * scale) {
                compactTab("ICM", 0)
                compactTab("ZK", 1)
            }
            .padding(3 * scale)
            .background(ZKTheme.card)
            .clipShape(Capsule())

            VStack(alignment: .leading, spacing: 1 * scale) {
                Text(market.currentPrice.map { String(format: "$%.2f", $0) } ?? "—")
                    .font(.system(size: 13 * scale, weight: .black, design: .monospaced))
                    .contentTransition(.numericText())
                Text(state.chartMode == 0 ? "ICMARKETS:XAUUSD" : "ZK CUSTOM")
                    .font(.system(size: 6.8 * scale, weight: .black))
                    .foregroundStyle(ZKTheme.textMuted)
            }

            Spacer(minLength: 4)

            Button {
                state.askAI("Analyse the current XAUUSD chart. Give me the structure, important levels, liquidity and what would confirm next. Keep it concise.")
            } label: {
                Image(systemName: "brain.head.profile.fill")
                    .font(.system(size: 12 * scale, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 34 * scale, height: 34 * scale)
                    .background(ZKTheme.accentGradient)
                    .clipShape(Circle())
            }
            .buttonStyle(ZKPressStyle())
            .accessibilityLabel("Ask ZK AI")

            if state.chartMode == 1 {
                Button {
                    Task { await market.refreshAll() }
                } label: {
                    Image(systemName: "arrow.clockwise")
                        .font(.system(size: 12 * scale, weight: .bold))
                        .foregroundStyle(ZKTheme.textSoft)
                        .frame(width: 34 * scale, height: 34 * scale)
                        .background(ZKTheme.card)
                        .overlay(Circle().stroke(ZKTheme.border))
                        .clipShape(Circle())
                }
                .buttonStyle(ZKPressStyle())
                .accessibilityLabel("Refresh chart")
            }
        }
        .padding(.horizontal, 8 * scale)
        .frame(height: 44 * scale)
        .background(Color(red: 0.035, green: 0.027, blue: 0.051))
        .overlay(RoundedRectangle(cornerRadius: 13 * scale).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 13 * scale))
    }

    private func compactTab(_ title: String, _ index: Int) -> some View {
        Button { state.chartMode = index } label: {
            Text(title)
                .font(.system(size: 8 * scale, weight: .black))
                .foregroundStyle(state.chartMode == index ? .white : ZKTheme.textMuted)
                .frame(width: 42 * scale, height: 27 * scale)
                .background(state.chartMode == index ? ZKTheme.purple.opacity(0.30) : .clear)
                .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }

    @ViewBuilder
    private var chartArea: some View {
        if state.chartMode == 0 {
            TradingViewICMarketsChart(compact: false, showHeader: false)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.black)
                .overlay(RoundedRectangle(cornerRadius: 16 * scale).stroke(ZKTheme.borderStrong.opacity(0.75)))
                .clipShape(RoundedRectangle(cornerRadius: 16 * scale))
        } else if market.candles.isEmpty {
            emptyState
        } else {
            nativeChart
        }
    }

    private var nativeChart: some View {
        let read = ChartIntelligenceEngine.snapshot(candles: market.candles, currentPrice: market.currentPrice)

        return ZStack(alignment: .top) {
            NativeAgentChart(candles: market.candles, drawings: state.drawings)
                .padding(.top, 38 * scale)

            HStack(spacing: 8 * scale) {
                VStack(alignment: .leading, spacing: 1 * scale) {
                    Text("1M \(read.trend1m) • \(read.structure)")
                        .font(.system(size: 8.5 * scale, weight: .black))
                        .lineLimit(1)
                    Text("S \(level(read.support?.price))  •  R \(level(read.resistance?.price))")
                        .font(.system(size: 7 * scale, weight: .bold, design: .monospaced))
                        .foregroundStyle(ZKTheme.textMuted)
                }
                Spacer()
                Menu {
                    Button("Mark support + resistance") { state.replaceSupportResistance(around: market.currentPrice) }
                    Button("Add zone") { state.addZone(around: market.currentPrice) }
                    Divider()
                    Button("Undo last") { state.removeLastDrawing() }
                    Button("Clear drawings", role: .destructive) { state.clearAllDrawings() }
                } label: {
                    Image(systemName: "ellipsis")
                        .font(.system(size: 13 * scale, weight: .black))
                        .foregroundStyle(ZKTheme.textSoft)
                        .frame(width: 31 * scale, height: 31 * scale)
                        .background(ZKTheme.card2)
                        .clipShape(Circle())
                }
            }
            .padding(.horizontal, 10 * scale)
            .frame(height: 38 * scale)
            .background(Color(red: 0.035, green: 0.027, blue: 0.051).opacity(0.96))
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(red: 0.025, green: 0.021, blue: 0.036))
        .overlay(RoundedRectangle(cornerRadius: 16 * scale).stroke(ZKTheme.borderStrong.opacity(0.75)))
        .clipShape(RoundedRectangle(cornerRadius: 16 * scale))
    }

    private var emptyState: some View {
        VStack(spacing: 10 * scale) {
            Spacer()
            Image(systemName: market.feedStatus == .offline ? "wifi.slash" : "chart.xyaxis.line")
                .font(.system(size: 28 * scale, weight: .medium))
                .foregroundStyle(feedColor)
            Text(market.feedStatus == .offline ? "Chart unavailable" : "Loading chart")
                .font(.system(size: 14 * scale, weight: .bold))
            Button("Retry") { Task { await market.refreshAll() } }
                .font(.system(size: 9 * scale, weight: .black))
                .buttonStyle(.bordered)
                .tint(ZKTheme.purple)
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(ZKTheme.card.opacity(0.45))
        .overlay(RoundedRectangle(cornerRadius: 16 * scale).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 16 * scale))
    }

    private func level(_ value: Double?) -> String {
        value.map { String(format: "%.1f", $0) } ?? "—"
    }

    private var feedColor: Color {
        switch market.feedStatus {
        case .live: return ZKTheme.green
        case .stale, .connecting: return ZKTheme.gold
        case .offline: return ZKTheme.red
        }
    }
}
