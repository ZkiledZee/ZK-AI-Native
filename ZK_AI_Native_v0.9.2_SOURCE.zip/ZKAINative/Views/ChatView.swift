import SwiftUI

struct ChatView: View {
    @EnvironmentObject private var state: AppState
    @EnvironmentObject private var market: MarketDataService
    @EnvironmentObject private var ai: LocalAIService
    @Environment(\.zkScale) private var scale
    @State private var input = ""
    @State private var showHistory = false
    @State private var showActions = false
    @FocusState private var composerFocused: Bool

    var body: some View {
        VStack(spacing: 0) {
            topBar
            Divider().overlay(Color.white.opacity(0.07))
            messages
            if shouldShowModelPrompt { modelPrompt }
            if ai.state == .generating && !state.agentSteps.isEmpty { compactAgentActivity }
            composer
        }
        .padding(.horizontal, 12 * scale)
        .padding(.top, 2 * scale)
        .padding(.bottom, 8 * scale)
        .background(Color(red: 0.012, green: 0.012, blue: 0.018))
        .sheet(isPresented: $showHistory) { ChatHistorySheet().environmentObject(state) }
        .confirmationDialog("ZK Agent tools", isPresented: $showActions, titleVisibility: .visible) {
            Button("Analyse current gold chart") { send("Analyse gold like an agent. Inspect the current chart and tell me what matters now.") }
            Button("Mark key support and resistance") { send("Inspect the current chart and mark the most important support and resistance levels.") }
            Button("Open Signal") { state.go(.signal) }
            Button("New chat") { state.newChat() }
            Button("Cancel", role: .cancel) {}
        }
        .task {
            if ai.isInstalled && !ai.isReady && !ai.isBusy { await ai.loadModel() }
            consumePendingPrompt()
        }
        .onChange(of: state.pendingChatPrompt) { consumePendingPrompt() }
    }

    private var topBar: some View {
        HStack(spacing: 8 * scale) {
            Button { showHistory = true } label: {
                Image(systemName: "line.3.horizontal")
                    .font(.system(size: 17 * scale, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.92))
                    .frame(width: 38 * scale, height: 40 * scale)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            Spacer(minLength: 4)

            VStack(spacing: 1 * scale) {
                HStack(spacing: 5 * scale) {
                    Text("ZK AI")
                        .font(.system(size: 15 * scale, weight: .semibold))
                        .foregroundStyle(.white)
                    Image(systemName: "chevron.down")
                        .font(.system(size: 8 * scale, weight: .bold))
                        .foregroundStyle(.white.opacity(0.55))
                }
                HStack(spacing: 4 * scale) {
                    Circle().fill(aiColor).frame(width: 5 * scale, height: 5 * scale)
                    Text("\(ai.selectedTier == .smart ? "Smart" : "Fast") • chart-aware agent")
                        .font(.system(size: 8 * scale, weight: .medium))
                        .foregroundStyle(.white.opacity(0.46))
                }
            }

            Spacer(minLength: 4)

            Button { state.newChat() } label: {
                Image(systemName: "square.and.pencil")
                    .font(.system(size: 16 * scale, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.92))
                    .frame(width: 38 * scale, height: 40 * scale)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
        }
        .frame(height: 49 * scale)
    }

    private var messages: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 20 * scale) {
                    if let title = state.currentThread?.title, title != "New analysis", title != "ZK Agent" {
                        Text(title)
                            .font(.system(size: 11 * scale, weight: .semibold))
                            .foregroundStyle(.white.opacity(0.38))
                            .frame(maxWidth: .infinity, alignment: .center)
                            .padding(.top, 10 * scale)
                    }

                    ForEach(state.chatMessages) { message in
                        messageRow(message).id(message.id)
                    }
                }
                .padding(.horizontal, 4 * scale)
                .padding(.top, 15 * scale)
                .padding(.bottom, 18 * scale)
            }
            .scrollDismissesKeyboard(.interactively)
            .scrollIndicators(.hidden)
            .onChange(of: state.chatMessages) {
                if let last = state.chatMessages.last {
                    withAnimation(.easeOut(duration: 0.16)) { proxy.scrollTo(last.id, anchor: .bottom) }
                }
            }
        }
    }

    @ViewBuilder
    private func messageRow(_ message: ChatMessage) -> some View {
        if message.role == .user {
            HStack {
                Spacer(minLength: 62 * scale)
                Text(message.text)
                    .font(.system(size: 13.5 * scale, weight: .regular))
                    .foregroundStyle(.white.opacity(0.96))
                    .lineSpacing(3 * scale)
                    .textSelection(.enabled)
                    .padding(.horizontal, 14 * scale)
                    .padding(.vertical, 10 * scale)
                    .background(Color.white.opacity(0.105))
                    .clipShape(RoundedRectangle(cornerRadius: 18 * scale, style: .continuous))
            }
        } else {
            HStack(alignment: .top, spacing: 10 * scale) {
                ZStack {
                    Circle().fill(Color.white.opacity(0.94))
                    Text("ZK")
                        .font(.system(size: 7.5 * scale, weight: .black))
                        .foregroundStyle(.black)
                }
                .frame(width: 25 * scale, height: 25 * scale)
                .padding(.top, 1 * scale)

                Group {
                    if message.text.isEmpty {
                        HStack(spacing: 7 * scale) {
                            ProgressView().controlSize(.small).tint(.white.opacity(0.75))
                            Text(currentWorkingText)
                                .font(.system(size: 13 * scale, weight: .regular))
                                .foregroundStyle(.white.opacity(0.58))
                        }
                    } else {
                        Text(message.text)
                            .font(.system(size: 13.5 * scale, weight: .regular))
                            .foregroundStyle(.white.opacity(0.94))
                            .lineSpacing(4 * scale)
                            .textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                Spacer(minLength: 0)
            }
        }
    }

    private var modelPrompt: some View {
        VStack(alignment: .leading, spacing: 8 * scale) {
            HStack(spacing: 8 * scale) {
                Image(systemName: "arrow.down.circle")
                    .font(.system(size: 17 * scale, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.8))
                VStack(alignment: .leading, spacing: 1 * scale) {
                    Text(ai.isInstalled ? "Local model ready to load" : "Local model required")
                        .font(.system(size: 11 * scale, weight: .semibold))
                    Text(ai.isInstalled ? ai.statusDetail : "Download the selected model once. It stays on your iPhone.")
                        .font(.system(size: 8.5 * scale, weight: .regular))
                        .foregroundStyle(.white.opacity(0.48))
                }
                Spacer()
                Button {
                    if ai.isInstalled { Task { await ai.loadModel() } } else { ai.downloadModel() }
                } label: {
                    Text(ai.isInstalled ? "Load" : "Download")
                        .font(.system(size: 9 * scale, weight: .semibold))
                        .foregroundStyle(.black)
                        .padding(.horizontal, 12 * scale)
                        .frame(height: 30 * scale)
                        .background(Color.white)
                        .clipShape(Capsule())
                }
                .buttonStyle(.plain)
                .disabled(ai.isBusy)
            }
            if case .downloading = ai.state {
                ProgressView(value: ai.downloadProgress).tint(.white)
            }
        }
        .padding(11 * scale)
        .background(Color.white.opacity(0.06))
        .overlay(RoundedRectangle(cornerRadius: 14 * scale).stroke(Color.white.opacity(0.08)))
        .clipShape(RoundedRectangle(cornerRadius: 14 * scale))
        .padding(.bottom, 8 * scale)
    }

    private var compactAgentActivity: some View {
        HStack(spacing: 8 * scale) {
            if ai.state == .generating {
                ProgressView().controlSize(.mini).tint(.white.opacity(0.72))
            } else {
                Image(systemName: "checkmark.circle.fill")
                    .font(.system(size: 11 * scale))
                    .foregroundStyle(ZKTheme.green)
            }
            Text(agentActivityText)
                .font(.system(size: 9 * scale, weight: .medium))
                .foregroundStyle(.white.opacity(0.52))
                .lineLimit(1)
            Spacer()
            Text("\(state.agentSteps.filter { $0.status == .complete }.count)/\(state.agentSteps.count)")
                .font(.system(size: 8 * scale, weight: .medium, design: .monospaced))
                .foregroundStyle(.white.opacity(0.32))
        }
        .padding(.horizontal, 4 * scale)
        .frame(height: 28 * scale)
    }

    private var composer: some View {
        HStack(alignment: .bottom, spacing: 8 * scale) {
            Button { showActions = true } label: {
                Image(systemName: "plus")
                    .font(.system(size: 17 * scale, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.88))
                    .frame(width: 38 * scale, height: 38 * scale)
                    .background(Color.white.opacity(0.08))
                    .clipShape(Circle())
            }
            .buttonStyle(.plain)

            HStack(alignment: .bottom, spacing: 7 * scale) {
                TextField("Message ZK AI", text: $input, axis: .vertical)
                    .focused($composerFocused)
                    .font(.system(size: 14 * scale, weight: .regular))
                    .foregroundStyle(.white)
                    .lineLimit(1...5)
                    .padding(.leading, 4 * scale)
                    .padding(.vertical, 9 * scale)
                    .submitLabel(.send)
                    .onSubmit { send() }
                    .disabled(ai.state == .generating)

                Button(action: send) {
                    Image(systemName: ai.state == .generating ? "ellipsis" : "arrow.up")
                        .font(.system(size: 15 * scale, weight: .bold))
                        .foregroundStyle(canSend ? .black : .white.opacity(0.35))
                        .frame(width: 32 * scale, height: 32 * scale)
                        .background(canSend ? Color.white : Color.white.opacity(0.08))
                        .clipShape(Circle())
                }
                .buttonStyle(.plain)
                .disabled(!canSend)
                .padding(.trailing, 3 * scale)
                .padding(.bottom, 3 * scale)
            }
            .padding(.horizontal, 8 * scale)
            .background(Color.white.opacity(0.075))
            .overlay(RoundedRectangle(cornerRadius: 22 * scale, style: .continuous).stroke(Color.white.opacity(0.10)))
            .clipShape(RoundedRectangle(cornerRadius: 22 * scale, style: .continuous))
        }
        .padding(.top, 5 * scale)
    }

    private var canSend: Bool {
        !input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && ai.state != .generating
    }

    private var shouldShowModelPrompt: Bool {
        !ai.isReady && ai.state != .generating
    }

    private var currentWorkingText: String {
        state.agentSteps.first(where: { $0.status == .running })?.title ?? "Thinking locally…"
    }

    private var agentActivityText: String {
        if let running = state.agentSteps.first(where: { $0.status == .running }) { return running.title }
        if let last = state.agentSteps.last(where: { $0.status == .complete }) { return last.title }
        return "Agent ready"
    }

    private func send() { send(input) }

    private func send(_ supplied: String) {
        let text = supplied.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        input = ""
        composerFocused = false

        guard ai.isInstalled else {
            state.appendUserMessage(text)
            state.appendAssistantMessage("Download the selected local model first. Fast is the lightweight fallback; Smart is the stronger optional model in Settings.")
            return
        }
        guard ai.state != .generating else { return }

        Task {
            state.appendUserMessage(text)
            let preparation = await ZKAgentCoordinator.prepare(query: text, state: state, market: market)
            let history = state.chatMessages
            let responseID = state.appendAssistantMessage()
            do {
                try await ai.generate(appContext: preparation.context, conversation: history) { token in
                    state.appendToAssistantMessage(id: responseID, token: token)
                }
                if state.chatMessages.first(where: { $0.id == responseID })?.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == true {
                    state.replaceAssistantMessage(id: responseID, text: "I finished the agent checks but the local model returned no usable text. Try again or switch model tier in Settings.")
                }
            } catch {
                state.replaceAssistantMessage(id: responseID, text: "Local agent error: \(error.localizedDescription)")
            }
        }
    }

    private func consumePendingPrompt() {
        guard let prompt = state.pendingChatPrompt?.trimmingCharacters(in: .whitespacesAndNewlines), !prompt.isEmpty else { return }
        state.pendingChatPrompt = nil
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) { send(prompt) }
    }

    private var aiColor: Color {
        switch ai.state {
        case .ready, .generating: return ZKTheme.green
        case .downloading, .verifying, .loading, .downloaded: return ZKTheme.gold
        case .failed: return ZKTheme.red
        case .notDownloaded: return ZKTheme.textMuted
        }
    }
}

private struct ChatHistorySheet: View {
    @EnvironmentObject private var state: AppState
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                ForEach(state.chatThreads) { thread in
                    Button {
                        state.selectChat(thread.id)
                        dismiss()
                    } label: {
                        VStack(alignment: .leading, spacing: 4) {
                            HStack {
                                Text(thread.title).font(.headline).foregroundStyle(.primary).lineLimit(1)
                                Spacer()
                                if thread.id == state.currentThreadID { Image(systemName: "checkmark.circle.fill").foregroundStyle(.white) }
                            }
                            Text("\(thread.messages.count) messages • \(thread.updatedAt.formatted(date: .abbreviated, time: .shortened))")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    .swipeActions {
                        Button(role: .destructive) { state.deleteChat(thread.id) } label: { Label("Delete", systemImage: "trash") }
                    }
                }
            }
            .navigationTitle("Chats")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Done") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { state.newChat(); dismiss() } label: { Image(systemName: "square.and.pencil") }
                }
            }
        }
        .preferredColorScheme(.dark)
    }
}
