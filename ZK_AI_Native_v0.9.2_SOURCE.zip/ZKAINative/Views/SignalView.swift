import SwiftUI

struct SignalView: View {
    @EnvironmentObject private var state: AppState
    @EnvironmentObject private var market: MarketDataService
    @EnvironmentObject private var engine: SignalEngine
    @Environment(\.zkScale) private var scale
    @StateObject private var notifications = NotificationManager.shared

    var body: some View {
        VStack(spacing: 8 * scale) {
            ZKPageHeader(
                micro: "XAUUSD • 1M",
                title: "Signal",
                pill: engine.enabled ? engine.mode.rawValue : "PAUSED",
                pillColor: engine.enabled ? modeColor : ZKTheme.textMuted
            )

            topBar
            chart
            signalStrip

            if engine.activeTrade != nil {
                tradeStrip
            }

            footerBar
        }
        .padding(.horizontal, 16 * scale)
        .padding(.top, 8 * scale)
        .padding(.bottom, 8 * scale)
        .background(ZKTheme.background)
        .task { state.notificationPermission = await notifications.refresh() }
    }

    private var topBar: some View {
        VStack(spacing: 8 * scale) {
            HStack(spacing: 10 * scale) {
                VStack(alignment: .leading, spacing: 1 * scale) {
                    Text(market.currentPrice.map { String(format: "$%.2f", $0) } ?? "—")
                        .font(.system(size: 19 * scale, weight: .black, design: .monospaced))
                        .contentTransition(.numericText())
                    Text("XAUUSD  •  \(market.feedStatus.rawValue)  •  \(market.freshnessText)")
                        .font(.system(size: 7 * scale, weight: .black))
                        .foregroundStyle(feedColor)
                        .lineLimit(1)
                }

                Spacer()

                Toggle("", isOn: Binding(get: { engine.enabled }, set: { engine.setEnabled($0) }))
                    .labelsHidden()
                    .tint(ZKTheme.green)
                    .scaleEffect(0.86)
            }

            Picker("Signal mode", selection: Binding(get: { engine.mode }, set: { engine.setMode($0) })) {
                Text("SELECTIVE").tag(SignalEngineMode.selective)
                Text("FAST SCALPER").tag(SignalEngineMode.fastScalper)
            }
            .pickerStyle(.segmented)
            .disabled(!engine.enabled)
        }
        .padding(.horizontal, 12 * scale)
        .padding(.vertical, 9 * scale)
        .background(Color(red: 0.035, green: 0.027, blue: 0.051))
        .overlay(RoundedRectangle(cornerRadius: 14 * scale).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 14 * scale))
    }

    private var chart: some View {
        ZStack(alignment: .topTrailing) {
            Group {
                if market.candles.isEmpty {
                    VStack(spacing: 8 * scale) {
                        ProgressView().tint(ZKTheme.purple)
                        Text(market.feedStatus == .offline ? "Chart unavailable" : "Loading 1M chart…")
                            .font(.system(size: 9 * scale, weight: .bold))
                            .foregroundStyle(ZKTheme.textMuted)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    NativeAgentChart(candles: market.candles, drawings: signalDrawings)
                        .padding(4 * scale)
                }
            }

            Button { engine.forceEvaluate() } label: {
                Image(systemName: "arrow.clockwise")
                    .font(.system(size: 11 * scale, weight: .bold))
                    .foregroundStyle(ZKTheme.textSoft)
                    .frame(width: 31 * scale, height: 31 * scale)
                    .background(ZKTheme.card2.opacity(0.95))
                    .overlay(Circle().stroke(ZKTheme.border))
                    .clipShape(Circle())
            }
            .buttonStyle(ZKPressStyle())
            .padding(9 * scale)
            .accessibilityLabel("Scan now")
        }
        .frame(minHeight: 330 * scale, maxHeight: .infinity)
        .background(Color(red: 0.025, green: 0.021, blue: 0.036))
        .overlay(RoundedRectangle(cornerRadius: 16 * scale).stroke(ZKTheme.borderStrong.opacity(0.80)))
        .clipShape(RoundedRectangle(cornerRadius: 16 * scale))
    }

    private var signalDrawings: [ChartDrawing] {
        guard let trade = engine.activeTrade else { return [] }
        return [
            .init(kind: .entry, price: trade.entry, label: "ENTRY"),
            .init(kind: .stopLoss, price: trade.stopLoss, label: "SL"),
            .init(kind: .takeProfit, price: trade.takeProfit, label: "TP")
        ]
    }

    private var signalStrip: some View {
        let s = engine.snapshot
        return VStack(spacing: 5 * scale) {
            HStack(spacing: 8 * scale) {
                Circle().fill(signalColor).frame(width: 7 * scale, height: 7 * scale)
                Text(s.side.rawValue)
                    .font(.system(size: 17 * scale, weight: .black, design: .rounded))
                    .foregroundStyle(signalColor)
                Text("\(Int((s.executionConfidence * 100).rounded()))%")
                    .font(.system(size: 9 * scale, weight: .black, design: .monospaced))
                    .foregroundStyle(ZKTheme.textSoft)
                Spacer()
                Text("SCORE \(Int(engine.lastScore))")
                    .font(.system(size: 8 * scale, weight: .black, design: .monospaced))
                    .foregroundStyle(ZKTheme.textSoft)
                Text("\(engine.todayTradeCount) TODAY")
                    .font(.system(size: 8 * scale, weight: .black, design: .monospaced))
                    .foregroundStyle(modeColor)
            }

            Text(cleanReason(s.reason))
                .font(.system(size: 8 * scale, weight: .medium))
                .foregroundStyle(ZKTheme.textMuted)
                .lineLimit(1)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(.horizontal, 12 * scale)
        .padding(.vertical, 9 * scale)
        .background(Color(red: 0.035, green: 0.027, blue: 0.051))
        .overlay(RoundedRectangle(cornerRadius: 13 * scale).stroke(signalColor.opacity(0.18)))
        .clipShape(RoundedRectangle(cornerRadius: 13 * scale))
    }

    private var tradeStrip: some View {
        guard let trade = engine.activeTrade else { return AnyView(EmptyView()) }
        return AnyView(
            HStack(spacing: 7 * scale) {
                compactLevel("ENTRY", trade.entry, signalColor)
                Divider().overlay(ZKTheme.border)
                compactLevel("SL", trade.stopLoss, ZKTheme.red)
                Divider().overlay(ZKTheme.border)
                compactLevel("TP", trade.takeProfit, ZKTheme.green)
                Divider().overlay(ZKTheme.border)
                VStack(spacing: 1 * scale) {
                    Text("R:R").font(.system(size: 6.5 * scale, weight: .black)).foregroundStyle(ZKTheme.textMuted)
                    Text(String(format: "%.2f", max(abs(trade.takeProfit - trade.entry) / max(abs(trade.entry - trade.stopLoss), 0.0001), 0)))
                        .font(.system(size: 8.5 * scale, weight: .black, design: .monospaced))
                        .foregroundStyle(ZKTheme.purple)
                }
                .frame(maxWidth: .infinity)
            }
            .padding(.horizontal, 10 * scale)
            .frame(height: 45 * scale)
            .background(Color(red: 0.035, green: 0.027, blue: 0.051))
            .overlay(RoundedRectangle(cornerRadius: 12 * scale).stroke(ZKTheme.border))
            .clipShape(RoundedRectangle(cornerRadius: 12 * scale))
        )
    }

    private func compactLevel(_ title: String, _ value: Double, _ color: Color) -> some View {
        VStack(spacing: 1 * scale) {
            Text(title)
                .font(.system(size: 6.5 * scale, weight: .black))
                .foregroundStyle(ZKTheme.textMuted)
            Text(String(format: "%.2f", value))
                .font(.system(size: 8.5 * scale, weight: .black, design: .monospaced))
                .foregroundStyle(color)
                .lineLimit(1)
                .minimumScaleFactor(0.7)
        }
        .frame(maxWidth: .infinity)
    }

    private var footerBar: some View {
        HStack(spacing: 7 * scale) {
            Circle().fill(engine.enabled ? modeColor : ZKTheme.textMuted).frame(width: 6 * scale, height: 6 * scale)
            Text(engine.enabled ? "PAPER • \(engine.mode.rawValue)" : "ENGINE PAUSED")
                .font(.system(size: 7 * scale, weight: .black))
                .foregroundStyle(ZKTheme.textMuted)
            Spacer()
            Button {
                Task {
                    if !state.notificationPermission { state.notificationPermission = await notifications.request() }
                    if state.notificationPermission { await notifications.sendDemo() }
                }
            } label: {
                Image(systemName: state.notificationPermission ? "bell.fill" : "bell")
                    .font(.system(size: 10 * scale, weight: .bold))
                    .foregroundStyle(state.notificationPermission ? ZKTheme.purple : ZKTheme.textMuted)
            }
            .buttonStyle(ZKPressStyle())
        }
        .padding(.horizontal, 4 * scale)
        .frame(height: 20 * scale)
    }

    private func cleanReason(_ reason: String) -> String {
        let cleaned = reason
            .replacingOccurrences(of: "Selective scan: ", with: "")
            .replacingOccurrences(of: "Fast scalper scan: ", with: "")
        return cleaned.isEmpty ? "Waiting for a qualified setup." : cleaned
    }

    private var signalColor: Color {
        switch engine.snapshot.side {
        case .buy: return ZKTheme.green
        case .sell: return ZKTheme.red
        case .wait: return ZKTheme.gold
        }
    }

    private var modeColor: Color { engine.mode == .fastScalper ? ZKTheme.pink : ZKTheme.purple }

    private var feedColor: Color {
        switch market.feedStatus {
        case .live: return ZKTheme.green
        case .stale, .connecting: return ZKTheme.gold
        case .offline: return ZKTheme.red
        }
    }
}
