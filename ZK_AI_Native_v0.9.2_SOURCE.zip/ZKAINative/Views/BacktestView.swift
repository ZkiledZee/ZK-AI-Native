import SwiftUI

struct BacktestView: View {
    @EnvironmentObject private var market: MarketDataService
    @EnvironmentObject private var signalEngine: SignalEngine
    @Environment(\.zkScale) private var scale
    @State private var integrityResult = UserDefaults.standard.string(forKey: "zk.backtest.integrityResult") ?? "Not checked"
    @State private var detail = UserDefaults.standard.string(forKey: "zk.backtest.integrityDetail") ?? "Run a quick check on the loaded 1M candles."
    @State private var showDetails = false

    var body: some View {
        ScrollView {
            VStack(spacing: 10 * scale) {
                ZKPageHeader(
                    micro: "VALIDATION",
                    title: "Backtest",
                    pill: signalEngine.enabled ? "PAPER LIVE" : "PAUSED",
                    pillColor: signalEngine.enabled ? ZKTheme.green : ZKTheme.textMuted
                )

                summaryCard
                integrityCard
                detailsCard
            }
            .padding(.horizontal, 16 * scale)
            .padding(.top, 8 * scale)
            .padding(.bottom, 18 * scale)
        }
        .scrollIndicators(.hidden)
        .background(ZKTheme.background)
    }

    private var summaryCard: some View {
        ZKCard(strongBorder: true) {
            HStack(spacing: 8 * scale) {
                stat("CANDLES", "\(market.candles.count)", ZKTheme.purple)
                stat("TF", "1M", ZKTheme.gold)
                stat("ENGINE", signalEngine.enabled ? "ON" : "OFF", signalEngine.enabled ? ZKTheme.green : ZKTheme.textMuted)
            }
        }
    }

    private var integrityCard: some View {
        ZKCard {
            VStack(alignment: .leading, spacing: 10 * scale) {
                HStack {
                    VStack(alignment: .leading, spacing: 2 * scale) {
                        Text("DATA CHECK")
                            .font(.system(size: 8 * scale, weight: .black))
                            .foregroundStyle(ZKTheme.textMuted)
                        Text(integrityResult)
                            .font(.system(size: 15 * scale, weight: .bold))
                            .foregroundStyle(resultColor)
                    }
                    Spacer()
                    Button { runIntegrityCheck() } label: {
                        Text("RUN")
                            .font(.system(size: 8.5 * scale, weight: .black))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 14 * scale)
                            .frame(height: 32 * scale)
                            .background(ZKTheme.accentGradient)
                            .clipShape(Capsule())
                    }
                    .buttonStyle(ZKPressStyle())
                }

                Text(detail)
                    .font(.system(size: 8.5 * scale, weight: .medium))
                    .foregroundStyle(ZKTheme.textMuted)
                    .lineLimit(2)
            }
        }
    }

    private var detailsCard: some View {
        ZKCard {
            DisclosureGroup(isExpanded: $showDetails) {
                VStack(alignment: .leading, spacing: 8 * scale) {
                    Divider().overlay(ZKTheme.border)
                    row("Forward paper signals", signalEngine.enabled ? "Active" : "Paused")
                    row("Historical broker replay", "Waiting for cTrader feed")
                    row("Walk-forward model tests", "Later")
                }
                .padding(.top, 6 * scale)
            } label: {
                Text("MORE")
                    .font(.system(size: 8 * scale, weight: .black))
                    .foregroundStyle(ZKTheme.textMuted)
            }
            .tint(ZKTheme.purple)
        }
    }

    private func runIntegrityCheck() {
        let candles = market.candles.sorted { $0.timestamp < $1.timestamp }
        guard candles.count >= 2 else {
            integrityResult = "Not enough data"
            detail = "Load at least two 1-minute candles first."
            persistIntegrity()
            return
        }

        var gaps = 0
        var duplicates = 0
        var invalidOHLC = 0
        var previous = candles[0]

        for candle in candles {
            if candle.high < max(candle.open, candle.close) || candle.low > min(candle.open, candle.close) || candle.high < candle.low {
                invalidOHLC += 1
            }
        }

        for candle in candles.dropFirst() {
            let delta = candle.timestamp.timeIntervalSince(previous.timestamp)
            if delta < 1 { duplicates += 1 }
            if delta > 90 { gaps += 1 }
            previous = candle
        }

        if invalidOHLC == 0 && duplicates == 0 && gaps == 0 {
            integrityResult = "PASS"
            detail = "\(candles.count) candles checked. Sequence and OHLC are valid."
        } else {
            integrityResult = "REVIEW"
            detail = "\(gaps) gaps • \(duplicates) duplicates • \(invalidOHLC) invalid OHLC records."
        }
        persistIntegrity()
    }

    private func persistIntegrity() {
        UserDefaults.standard.set(integrityResult, forKey: "zk.backtest.integrityResult")
        UserDefaults.standard.set(detail, forKey: "zk.backtest.integrityDetail")
        UserDefaults.standard.set(Date().timeIntervalSince1970, forKey: "zk.backtest.integrityDate")
    }

    private func stat(_ title: String, _ value: String, _ color: Color) -> some View {
        VStack(spacing: 3 * scale) {
            Text(title)
                .font(.system(size: 7 * scale, weight: .black))
                .foregroundStyle(ZKTheme.textMuted)
            Text(value)
                .font(.system(size: 12 * scale, weight: .black, design: .monospaced))
                .foregroundStyle(color)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 8 * scale)
        .background(Color.black.opacity(0.14))
        .clipShape(RoundedRectangle(cornerRadius: 9 * scale))
    }

    private func row(_ title: String, _ value: String) -> some View {
        HStack {
            Text(title)
                .font(.system(size: 9 * scale, weight: .semibold))
                .foregroundStyle(ZKTheme.textMuted)
            Spacer()
            Text(value)
                .font(.system(size: 9 * scale, weight: .bold))
                .foregroundStyle(ZKTheme.textSoft)
        }
    }

    private var resultColor: Color {
        switch integrityResult {
        case "PASS": return ZKTheme.green
        case "REVIEW", "Not enough data": return ZKTheme.gold
        default: return .white
        }
    }
}
