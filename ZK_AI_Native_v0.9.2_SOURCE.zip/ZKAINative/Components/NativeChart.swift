import SwiftUI

struct NativeAgentChart: View {
    @Environment(\.zkScale) private var scale
    let candles: [ChartCandle]
    let drawings: [ChartDrawing]

    @AppStorage("zk.settings.chartGrid") private var showGrid = true
    @AppStorage("zk.settings.priceLine") private var showPriceLine = true
    @AppStorage("zk.settings.chartMomentum") private var chartMomentum = true

    @State private var visibleCount: CGFloat = 34
    @State private var panOffset: CGFloat = 0
    @State private var pinchBaseCount: CGFloat?
    @State private var selectedIndex: Int?
    @GestureState private var dragPixels: CGFloat = 0

    var body: some View {
        GeometryReader { geo in
            let axisWidth = 50 * scale
            let plotWidth = max(geo.size.width - axisWidth, 80)
            let baseCount = max(12, min(visibleCount, CGFloat(max(candles.count, 12))))
            let step = plotWidth / max(baseCount, 1)
            let livePan = effectivePanOffset(step: step)
            let layout = makeLayout(size: geo.size, axisWidth: axisWidth, effectivePan: livePan)

            ZStack(alignment: .topTrailing) {
                Canvas { context, _ in
                    drawBackground(context: context, layout: layout)
                    if showGrid { drawGrid(context: context, layout: layout) }
                    drawCandles(context: context, layout: layout)
                    drawDrawings(context: context, layout: layout)
                    if showPriceLine { drawLatestPrice(context: context, layout: layout) }
                    drawSelection(context: context, layout: layout)
                    drawAxes(context: context, layout: layout)
                }
                .contentShape(Rectangle())
                .gesture(panGesture(step: step))
                .simultaneousGesture(zoomGesture)
                .simultaneousGesture(tapGesture(layout: layout))

                HStack(spacing: 6 * scale) {
                    if let selected = selectedCandle(in: layout.visible) {
                        Text(selectionText(selected))
                            .font(.system(size: 7.3 * scale, weight: .semibold, design: .monospaced))
                            .foregroundStyle(.white.opacity(0.90))
                            .padding(.horizontal, 7 * scale)
                            .frame(height: 24 * scale)
                            .background(Color.black.opacity(0.72))
                            .overlay(Capsule().stroke(ZKTheme.border.opacity(0.75)))
                            .clipShape(Capsule())
                            .lineLimit(1)
                            .minimumScaleFactor(0.58)
                    }

                    Button {
                        withAnimation(.snappy(duration: 0.20)) {
                            visibleCount = min(34, CGFloat(max(candles.count, 12)))
                            panOffset = 0
                            selectedIndex = nil
                        }
                    } label: {
                        Image(systemName: "arrow.up.left.and.arrow.down.right")
                            .font(.system(size: 9 * scale, weight: .bold))
                            .foregroundStyle(ZKTheme.textSoft)
                            .frame(width: 25 * scale, height: 25 * scale)
                            .background(Color.black.opacity(0.62))
                            .overlay(Circle().stroke(ZKTheme.border.opacity(0.75)))
                            .clipShape(Circle())
                    }
                    .buttonStyle(ZKPressStyle())
                    .accessibilityLabel("Fit chart")
                }
                .padding(.top, 5 * scale)
                .padding(.trailing, (axisWidth + 4 * scale))
            }
        }
        .accessibilityLabel("Interactive XAUUSD one minute candlestick chart")
        .accessibilityHint("Pinch to zoom, drag to move through candles, and tap a candle to inspect its OHLC values")
    }

    private struct Layout {
        let size: CGSize
        let visible: [ChartCandle]
        let leadingExtra: Int
        let plotWidth: CGFloat
        let axisWidth: CGFloat
        let top: CGFloat
        let bottom: CGFloat
        let high: Double
        let low: Double
        let span: Double
        let step: CGFloat
        let candleWidth: CGFloat
        let fractionalShift: CGFloat

        var plotHeight: CGFloat { max(1, size.height - top - bottom) }

        func x(for localIndex: Int) -> CGFloat {
            (CGFloat(localIndex - leadingExtra) + 0.5 + fractionalShift) * step
        }

        func y(_ value: Double) -> CGFloat {
            top + CGFloat((high - value) / span) * plotHeight
        }
    }

    private func effectivePanOffset(step: CGFloat) -> CGFloat {
        guard step > 0 else { return panOffset }
        let maxOffset = max(0, CGFloat(candles.count) - min(visibleCount, CGFloat(candles.count)))
        return min(max(panOffset + dragPixels / step, 0), maxOffset)
    }

    private func makeLayout(size: CGSize, axisWidth: CGFloat, effectivePan: CGFloat) -> Layout {
        let total = candles.count
        let count = min(max(Int(visibleCount.rounded()), 12), max(total, 12))
        let maxOffset = max(0, total - min(count, total))
        let clamped = min(max(effectivePan, 0), CGFloat(maxOffset))
        let whole = min(max(Int(floor(clamped)), 0), maxOffset)
        let fraction = clamped - CGFloat(whole)

        let end = max(0, total - whole)
        let start = max(0, end - min(count, total))
        let extraStart = max(0, start - 1)
        let extraEnd = min(total, end + 1)
        let leadingExtra = start - extraStart
        let visible = extraStart < extraEnd ? Array(candles[extraStart..<extraEnd]) : candles

        let plotted: [ChartCandle] = visible.enumerated().compactMap { index, candle in
            let x = CGFloat(index - leadingExtra) + 0.5 + fraction
            return (x >= -1 && x <= CGFloat(count) + 1) ? candle : nil
        }

        let candleHigh = plotted.map(\.high).max() ?? candles.last?.high ?? 1
        let candleLow = plotted.map(\.low).min() ?? candles.last?.low ?? 0
        let candleSpan = max(candleHigh - candleLow, max(abs(candleHigh) * 0.00008, 0.20))

        // A distant saved drawing should never squash the live candles. Only nearby overlays affect scale.
        let drawingAllowance = candleSpan * 0.85
        var scalePrices = [candleHigh, candleLow]
        for drawing in drawings {
            if drawing.price >= candleLow - drawingAllowance && drawing.price <= candleHigh + drawingAllowance {
                scalePrices.append(drawing.price)
            }
            if let p = drawing.secondaryPrice,
               p >= candleLow - drawingAllowance && p <= candleHigh + drawingAllowance {
                scalePrices.append(p)
            }
        }

        let rawHigh = scalePrices.max() ?? candleHigh
        let rawLow = scalePrices.min() ?? candleLow
        let rawSpan = max(rawHigh - rawLow, candleSpan)
        let padding = max(rawSpan * 0.10, max(abs(rawHigh) * 0.000035, 0.10))
        let high = rawHigh + padding
        let low = rawLow - padding
        let span = max(high - low, 0.001)

        let plotWidth = max(size.width - axisWidth, 80)
        let step = plotWidth / CGFloat(max(count, 1))
        let candleWidth = min(max(step * 0.70, 2.8 * scale), 12 * scale)

        return Layout(
            size: size,
            visible: visible,
            leadingExtra: leadingExtra,
            plotWidth: plotWidth,
            axisWidth: axisWidth,
            top: 12 * scale,
            bottom: 21 * scale,
            high: high,
            low: low,
            span: span,
            step: step,
            candleWidth: candleWidth,
            fractionalShift: fraction
        )
    }

    private func drawBackground(context: GraphicsContext, layout: Layout) {
        let plot = CGRect(x: 0, y: 0, width: layout.plotWidth, height: layout.size.height)
        context.fill(Path(plot), with: .color(Color.black.opacity(0.05)))

        let axis = CGRect(x: layout.plotWidth, y: 0, width: layout.axisWidth, height: layout.size.height)
        context.fill(Path(axis), with: .color(Color.black.opacity(0.15)))

        var separator = Path()
        separator.move(to: CGPoint(x: layout.plotWidth, y: 0))
        separator.addLine(to: CGPoint(x: layout.plotWidth, y: layout.size.height))
        context.stroke(separator, with: .color(ZKTheme.border.opacity(0.45)), lineWidth: 0.6)
    }

    private func drawGrid(context: GraphicsContext, layout: Layout) {
        for row in 0...4 {
            let y = layout.top + layout.plotHeight * CGFloat(row) / 4
            var path = Path()
            path.move(to: CGPoint(x: 0, y: y))
            path.addLine(to: CGPoint(x: layout.plotWidth, y: y))
            context.stroke(path, with: .color(ZKTheme.border.opacity(0.22)), lineWidth: 0.55)
        }

        for col in 1...3 {
            let x = layout.plotWidth * CGFloat(col) / 4
            var path = Path()
            path.move(to: CGPoint(x: x, y: layout.top))
            path.addLine(to: CGPoint(x: x, y: layout.size.height - layout.bottom))
            context.stroke(path, with: .color(ZKTheme.border.opacity(0.10)), lineWidth: 0.45)
        }
    }

    private func drawCandles(context: GraphicsContext, layout: Layout) {
        for (i, candle) in layout.visible.enumerated() {
            let x = layout.x(for: i)
            guard x > -layout.step && x < layout.plotWidth + layout.step else { continue }
            let color = candle.isUp ? ZKTheme.green : ZKTheme.red

            var wick = Path()
            wick.move(to: CGPoint(x: x, y: layout.y(candle.high)))
            wick.addLine(to: CGPoint(x: x, y: layout.y(candle.low)))
            context.stroke(wick, with: .color(color.opacity(0.94)), lineWidth: max(0.9, 0.9 * scale))

            let bodyTop = min(layout.y(candle.open), layout.y(candle.close))
            let bodyBottom = max(layout.y(candle.open), layout.y(candle.close))
            let rect = CGRect(
                x: x - layout.candleWidth / 2,
                y: bodyTop,
                width: layout.candleWidth,
                height: max(2 * scale, bodyBottom - bodyTop)
            )
            context.fill(Path(roundedRect: rect, cornerRadius: 1.1 * scale), with: .color(color))
        }
    }

    private func drawDrawings(context: GraphicsContext, layout: Layout) {
        for drawing in drawings {
            guard drawing.price >= layout.low && drawing.price <= layout.high else { continue }
            let y1 = layout.y(drawing.price)
            let color = color(for: drawing.kind)

            if drawing.kind == .zone, let second = drawing.secondaryPrice,
               second >= layout.low && second <= layout.high {
                let y2 = layout.y(second)
                let rect = CGRect(x: 0, y: min(y1, y2), width: layout.plotWidth, height: abs(y2 - y1))
                context.fill(Path(rect), with: .color(color.opacity(0.06)))
                context.stroke(Path(rect), with: .color(color.opacity(0.38)), lineWidth: 0.8)
            } else {
                var path = Path()
                path.move(to: CGPoint(x: 0, y: y1))
                path.addLine(to: CGPoint(x: layout.plotWidth, y: y1))
                context.stroke(path, with: .color(color.opacity(0.72)), style: StrokeStyle(lineWidth: 0.9, dash: [4, 4]))
            }

            let label = Text(drawing.label)
                .font(.system(size: 6.4 * scale, weight: .black))
                .foregroundColor(color)
            context.draw(label, at: CGPoint(x: layout.plotWidth - 5 * scale, y: max(layout.top + 6, y1 - 7 * scale)), anchor: .trailing)
        }
    }

    private func drawLatestPrice(context: GraphicsContext, layout: Layout) {
        guard let latest = candles.last,
              latest.close >= layout.low,
              latest.close <= layout.high else { return }

        let y = layout.y(latest.close)
        let color = latest.isUp ? ZKTheme.green : ZKTheme.red

        var line = Path()
        line.move(to: CGPoint(x: 0, y: y))
        line.addLine(to: CGPoint(x: layout.plotWidth, y: y))
        context.stroke(line, with: .color(color.opacity(0.34)), style: StrokeStyle(lineWidth: 0.8, dash: [2, 3]))

        let badgeWidth = layout.axisWidth - 6 * scale
        let badgeHeight = 18 * scale
        let badgeY = min(max(y - badgeHeight / 2, 1), layout.size.height - badgeHeight - 1)
        let rect = CGRect(x: layout.plotWidth + 3 * scale, y: badgeY, width: badgeWidth, height: badgeHeight)
        context.fill(Path(roundedRect: rect, cornerRadius: 4 * scale), with: .color(color.opacity(0.18)))
        context.stroke(Path(roundedRect: rect, cornerRadius: 4 * scale), with: .color(color.opacity(0.50)), lineWidth: 0.7)

        let badge = Text(String(format: "%.2f", latest.close))
            .font(.system(size: 7.1 * scale, weight: .black, design: .monospaced))
            .foregroundColor(color)
        context.draw(badge, at: CGPoint(x: rect.midX, y: rect.midY), anchor: .center)
    }

    private func drawSelection(context: GraphicsContext, layout: Layout) {
        guard let selectedIndex,
              let local = layout.visible.firstIndex(where: { $0.index == selectedIndex }) else { return }
        let candle = layout.visible[local]
        let x = layout.x(for: local)
        guard x >= 0 && x <= layout.plotWidth else { return }
        let y = layout.y(candle.close)

        var vertical = Path()
        vertical.move(to: CGPoint(x: x, y: layout.top))
        vertical.addLine(to: CGPoint(x: x, y: layout.size.height - layout.bottom))
        context.stroke(vertical, with: .color(.white.opacity(0.20)), style: StrokeStyle(lineWidth: 0.65, dash: [3, 3]))

        var horizontal = Path()
        horizontal.move(to: CGPoint(x: 0, y: y))
        horizontal.addLine(to: CGPoint(x: layout.plotWidth, y: y))
        context.stroke(horizontal, with: .color(.white.opacity(0.16)), style: StrokeStyle(lineWidth: 0.65, dash: [3, 3]))
    }

    private func drawAxes(context: GraphicsContext, layout: Layout) {
        for row in 0...4 {
            let fraction = Double(row) / 4.0
            let price = layout.high - layout.span * fraction
            let y = layout.top + layout.plotHeight * CGFloat(row) / 4
            let text = Text(String(format: "%.2f", price))
                .font(.system(size: 6.7 * scale, weight: .semibold, design: .monospaced))
                .foregroundColor(ZKTheme.textMuted)
            context.draw(text, at: CGPoint(x: layout.size.width - 3 * scale, y: y), anchor: .trailing)
        }

        let onScreen = layout.visible.enumerated().filter { pair in
            let x = layout.x(for: pair.offset)
            return x >= 0 && x <= layout.plotWidth
        }
        guard let firstPair = onScreen.first, let lastPair = onScreen.last else { return }

        let first = firstPair.element
        let last = lastPair.element
        let left = Text(timeLabel(first.timestamp))
            .font(.system(size: 6.5 * scale, weight: .medium, design: .monospaced))
            .foregroundColor(ZKTheme.textMuted)
        let right = Text(timeLabel(last.timestamp))
            .font(.system(size: 6.5 * scale, weight: .medium, design: .monospaced))
            .foregroundColor(ZKTheme.textMuted)

        context.draw(left, at: CGPoint(x: 3 * scale, y: layout.size.height - 3 * scale), anchor: .bottomLeading)
        context.draw(right, at: CGPoint(x: layout.plotWidth - 3 * scale, y: layout.size.height - 3 * scale), anchor: .bottomTrailing)
    }

    private func selectedCandle(in visible: [ChartCandle]) -> ChartCandle? {
        guard let selectedIndex else { return nil }
        return visible.first(where: { $0.index == selectedIndex })
    }

    private func panGesture(step: CGFloat) -> some Gesture {
        DragGesture(minimumDistance: 2)
            .updating($dragPixels) { value, state, _ in
                state = value.translation.width
            }
            .onChanged { _ in
                if selectedIndex != nil { selectedIndex = nil }
            }
            .onEnded { value in
                guard step > 0 else { return }
                let maxOffset = max(0, CGFloat(candles.count) - min(visibleCount, CGFloat(candles.count)))
                let finalTranslation = chartMomentum ? value.predictedEndTranslation.width : value.translation.width
                let target = min(max(panOffset + finalTranslation / step, 0), maxOffset)
                withAnimation(chartMomentum ? .interactiveSpring(response: 0.38, dampingFraction: 0.92, blendDuration: 0.06) : .easeOut(duration: 0.12)) {
                    panOffset = target
                }
            }
    }

    private var zoomGesture: some Gesture {
        MagnificationGesture()
            .onChanged { value in
                if pinchBaseCount == nil { pinchBaseCount = visibleCount }
                guard let base = pinchBaseCount else { return }
                let maxCount = max(12, min(CGFloat(candles.count), 120))
                visibleCount = min(max(base / max(value, 0.25), 12), maxCount)
                let maxOffset = max(0, CGFloat(candles.count) - min(visibleCount, CGFloat(candles.count)))
                panOffset = min(panOffset, maxOffset)
            }
            .onEnded { _ in
                pinchBaseCount = nil
            }
    }

    private func tapGesture(layout: Layout) -> some Gesture {
        SpatialTapGesture()
            .onEnded { value in
                guard value.location.x >= 0,
                      value.location.x <= layout.plotWidth,
                      !layout.visible.isEmpty else { return }

                let candidates = layout.visible.enumerated().map { index, candle in
                    (distance: abs(layout.x(for: index) - value.location.x), candle: candle)
                }
                selectedIndex = candidates.min(by: { $0.distance < $1.distance })?.candle.index
            }
    }

    private func timeLabel(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: date)
    }

    private func selectionText(_ candle: ChartCandle) -> String {
        "\(timeLabel(candle.timestamp))  O \(String(format: "%.2f", candle.open))  H \(String(format: "%.2f", candle.high))  L \(String(format: "%.2f", candle.low))  C \(String(format: "%.2f", candle.close))"
    }

    private func color(for kind: DrawingKind) -> Color {
        switch kind {
        case .support: return ZKTheme.green
        case .resistance: return ZKTheme.red
        case .zone: return ZKTheme.purple
        case .entry: return ZKTheme.blue
        case .stopLoss: return ZKTheme.red
        case .takeProfit: return ZKTheme.green
        case .note: return ZKTheme.gold
        }
    }
}
