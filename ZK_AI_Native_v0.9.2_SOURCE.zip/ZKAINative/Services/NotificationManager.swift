import Foundation
import UserNotifications

@MainActor
final class NotificationManager: ObservableObject {
    static let shared = NotificationManager()
    @Published private(set) var status = "NOT REQUESTED"

    private init() {}

    func refresh() async -> Bool {
        let settings = await UNUserNotificationCenter.current().notificationSettings()
        switch settings.authorizationStatus {
        case .authorized, .provisional, .ephemeral:
            status = "ENABLED"
            return true
        case .denied:
            status = "DENIED"
            return false
        case .notDetermined:
            status = "NOT REQUESTED"
            return false
        @unknown default:
            status = "UNKNOWN"
            return false
        }
    }

    func request() async -> Bool {
        do {
            let granted = try await UNUserNotificationCenter.current()
                .requestAuthorization(options: [.alert, .sound, .badge])
            _ = await refresh()
            return granted
        } catch {
            status = "ERROR"
            return false
        }
    }

    func sendSignal(side: String, price: Double, mode: String, stop: Double, target: Double) async {
        let settings = await UNUserNotificationCenter.current().notificationSettings()
        guard settings.authorizationStatus == .authorized || settings.authorizationStatus == .provisional || settings.authorizationStatus == .ephemeral else { return }

        let content = UNMutableNotificationContent()
        content.title = "ZK Signal — \(side) • \(mode)"
        content.body = String(format: "XAUUSD %.2f • SL %.2f • TP %.2f • paper signal", price, stop, target)
        content.sound = .default

        let request = UNNotificationRequest(
            identifier: "zk.signal.\(UUID().uuidString)",
            content: content,
            trigger: nil
        )
        try? await UNUserNotificationCenter.current().add(request)
    }

    func sendDemo() async {
        let content = UNMutableNotificationContent()
        content.title = "ZK AI — NATIVE TEST"
        content.body = "Native notifications are working. Native alerts are working. Signal Engine alerts are paper signals unless a broker execution layer is added later."
        content.sound = .default

        let request = UNNotificationRequest(
            identifier: "zk.native.test.\(UUID().uuidString)",
            content: content,
            trigger: UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        )
        try? await UNUserNotificationCenter.current().add(request)
    }
}
