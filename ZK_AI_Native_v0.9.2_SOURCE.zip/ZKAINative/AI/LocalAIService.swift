import Foundation
import SwiftUI

#if canImport(SwiftLlama)
import SwiftLlama
#endif

@MainActor
final class LocalAIService: ObservableObject {
    enum RuntimeState: Equatable {
        case notDownloaded
        case downloading
        case verifying
        case downloaded
        case loading
        case ready
        case generating
        case failed(String)
    }

    enum ModelTier: String, CaseIterable, Identifiable {
        case fast
        case smart
        var id: String { rawValue }
    }

    struct ModelProfile {
        let tier: ModelTier
        let name: String
        let shortName: String
        let repo: String
        let file: String
        let bytes: Int64
        let sha256: String
        let contextSize: UInt32
        let maxTokens: Int32
        let promptBudget: Int

        static let fast = ModelProfile(
            tier: .fast,
            name: "Qwen2.5 0.5B • Q4_K_M",
            shortName: "FAST 0.5B",
            repo: "Qwen/Qwen2.5-0.5B-Instruct-GGUF",
            file: "qwen2.5-0.5b-instruct-q4_k_m.gguf",
            bytes: 491_000_000,
            sha256: "74a4da8c9fdbcd15bd1f6d01d621410d31c6fc00986f5eb687824e7b93d7a9db",
            contextSize: 1536,
            maxTokens: 160,
            promptBudget: 3_000
        )

        // Official Qwen GGUF. Q3_K_M is intentionally used on iPhone to reduce
        // memory pressure while giving the agent noticeably better language/reasoning capacity.
        static let smart = ModelProfile(
            tier: .smart,
            name: "Qwen2.5 1.5B • Q3_K_M",
            shortName: "SMART 1.5B",
            repo: "Qwen/Qwen2.5-1.5B-Instruct-GGUF",
            file: "qwen2.5-1.5b-instruct-q3_k_m.gguf",
            bytes: 924_000_000,
            sha256: "58cb5c05ecef48e82961f1a2be6544145ea26136f69dddda4bbbd092f0e4b993",
            contextSize: 1280,
            maxTokens: 176,
            promptBudget: 2_650
        )
    }

    @Published private(set) var state: RuntimeState = .notDownloaded
    @Published private(set) var downloadProgress: Double = 0
    @Published private(set) var bytesDownloaded: Int64 = 0
    @Published private(set) var totalBytes: Int64 = ModelProfile.fast.bytes
    @Published private(set) var lastError: String?
    @Published private(set) var lastPromptCharacters: Int = 0
    @Published private(set) var selectedTier: ModelTier

    #if canImport(SwiftLlama)
    private var loadedModel: LlamaModel?
    private var loadedTier: ModelTier?
    private let downloader = ModelDownloader()
    #endif
    private var downloadTask: Task<Void, Never>?

    init() {
        let saved = UserDefaults.standard.string(forKey: "zk.ai.modelTier")
        selectedTier = ModelTier(rawValue: saved ?? "fast") ?? .fast
        refreshInstalledState()
    }

    var profile: ModelProfile { selectedTier == .smart ? .smart : .fast }
    var modelName: String { profile.name }
    var modelShortName: String { profile.shortName }
    var modelBytes: Int64 { profile.bytes }
    var safePromptCharacterBudget: Int { profile.promptBudget }

    var isInstalled: Bool { FileManager.default.fileExists(atPath: modelURL.path) }
    var fastInstalled: Bool { FileManager.default.fileExists(atPath: modelURL(for: .fast).path) }
    var smartInstalled: Bool { FileManager.default.fileExists(atPath: modelURL(for: .smart).path) }

    var isReady: Bool {
        #if canImport(SwiftLlama)
        return loadedModel != nil && loadedTier == selectedTier && state == .ready
        #else
        return false
        #endif
    }

    var lastInferenceCheckpoint: String { UserDefaults.standard.string(forKey: "zk.ai.lastCheckpoint") ?? "NONE" }

    var isBusy: Bool {
        switch state {
        case .downloading, .verifying, .loading, .generating: return true
        default: return false
        }
    }

    var shortStatus: String {
        switch state {
        case .notDownloaded: return selectedTier == .smart ? "SMART DL" : "DOWNLOAD"
        case .downloading: return "\(Int(downloadProgress * 100))%"
        case .verifying: return "VERIFY"
        case .downloaded: return modelShortName
        case .loading: return "LOADING"
        case .ready: return selectedTier == .smart ? "SMART" : "READY"
        case .generating: return "AGENT"
        case .failed: return "ERROR"
        }
    }

    var statusDetail: String {
        switch state {
        case .notDownloaded:
            return selectedTier == .smart
                ? "Optional ~924 MB Smart model. Better conversation and reasoning, with conservative iPhone memory settings."
                : "Fast ~491 MB local model. Stable and lightweight for on-device agent chat."
        case .downloading:
            return "Downloading \(Self.formatBytes(bytesDownloaded)) of \(Self.formatBytes(totalBytes))"
        case .verifying:
            return "Verifying the model checksum before it can run."
        case .downloaded:
            return "\(modelName) is stored locally and ready to load."
        case .loading:
            return "Loading \(modelShortName) into memory."
        case .ready:
            return "\(modelName) loaded. ZK Agent receives fresh app/chart evidence for every turn."
        case .generating:
            return "ZK Agent is reasoning over app tools and chart evidence locally on this iPhone."
        case .failed(let message):
            return message
        }
    }

    var modelURL: URL { modelURL(for: selectedTier) }

    func modelURL(for tier: ModelTier) -> URL {
        let base = try? FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let dir = (base ?? FileManager.default.temporaryDirectory)
            .appendingPathComponent("ZKAI", isDirectory: true)
            .appendingPathComponent("Models", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let p = tier == .smart ? ModelProfile.smart : ModelProfile.fast
        return dir.appendingPathComponent(p.file)
    }

    func selectTier(_ tier: ModelTier) {
        guard !isBusy, tier != selectedTier else { return }
        #if canImport(SwiftLlama)
        loadedModel = nil
        loadedTier = nil
        #endif
        selectedTier = tier
        UserDefaults.standard.set(tier.rawValue, forKey: "zk.ai.modelTier")
        totalBytes = profile.bytes
        bytesDownloaded = 0
        downloadProgress = 0
        refreshInstalledState()
    }

    func refreshInstalledState() {
        if isInstalled {
            if !isReady && !isBusy { state = .downloaded }
            if let attrs = try? FileManager.default.attributesOfItem(atPath: modelURL.path), let size = attrs[.size] as? NSNumber {
                bytesDownloaded = size.int64Value
                totalBytes = max(profile.bytes, size.int64Value)
                downloadProgress = 1
            }
        } else if !isBusy {
            state = .notDownloaded
            downloadProgress = 0
            bytesDownloaded = 0
            totalBytes = profile.bytes
        }
    }

    func downloadModel() {
        guard downloadTask == nil else { return }
        let requestedTier = selectedTier
        let requestedProfile = profile
        let targetURL = modelURL
        lastError = nil
        totalBytes = requestedProfile.bytes
        state = .downloading

        #if canImport(SwiftLlama)
        downloadTask = Task { [weak self] in
            guard let self else { return }
            let source = ModelSource.huggingFace(repo: requestedProfile.repo, file: requestedProfile.file)
            let stream = await downloader.download(from: source, to: targetURL, expectedSHA256: requestedProfile.sha256)

            for await event in stream {
                if Task.isCancelled { break }
                switch event {
                case .progress(let percent, let downloaded, let total):
                    guard self.selectedTier == requestedTier else { continue }
                    self.bytesDownloaded = downloaded
                    self.totalBytes = total > 0 ? total : requestedProfile.bytes
                    self.downloadProgress = min(max(percent / 100.0, 0), 1)
                    self.state = .downloading
                case .verifying:
                    if self.selectedTier == requestedTier { self.state = .verifying }
                case .completed:
                    if self.selectedTier == requestedTier {
                        self.downloadProgress = 1
                        self.bytesDownloaded = self.totalBytes
                        self.state = .downloaded
                    }
                    self.downloadTask = nil
                    if self.selectedTier == requestedTier { await self.loadModel() }
                case .failed(let error):
                    if self.selectedTier == requestedTier {
                        let text = error.localizedDescription
                        self.lastError = text
                        self.state = .failed(text)
                    }
                    self.downloadTask = nil
                }
            }
            if self.downloadTask != nil { self.downloadTask = nil }
        }
        #else
        state = .failed("The local inference runtime is not linked in this build.")
        #endif
    }

    func cancelDownload() {
        downloadTask?.cancel(); downloadTask = nil; refreshInstalledState()
    }

    func loadModel() async {
        guard isInstalled else { state = .notDownloaded; return }
        #if canImport(SwiftLlama)
        if loadedModel != nil && loadedTier == selectedTier { state = .ready; return }
        loadedModel = nil
        loadedTier = nil
        state = .loading
        lastError = nil
        let path = modelURL.path
        let tier = selectedTier
        let p = profile
        do {
            let model = try await Task.detached(priority: .userInitiated) {
                try LlamaModel(
                    path: path,
                    config: ModelConfig(
                        contextSize: p.contextSize,
                        batchSize: 64,
                        gpuLayers: .none,
                        threads: 2
                    )
                )
            }.value
            guard tier == selectedTier else { return }
            loadedModel = model
            loadedTier = tier
            state = .ready
        } catch {
            loadedModel = nil
            loadedTier = nil
            lastError = error.localizedDescription
            state = .failed("Model load failed: \(error.localizedDescription)")
        }
        #else
        state = .failed("The local inference runtime is not linked in this build.")
        #endif
    }

    func unloadModel() {
        #if canImport(SwiftLlama)
        loadedModel = nil; loadedTier = nil
        #endif
        refreshInstalledState()
    }

    func deleteModel() {
        downloadTask?.cancel(); downloadTask = nil
        #if canImport(SwiftLlama)
        loadedModel = nil; loadedTier = nil
        #endif
        try? FileManager.default.removeItem(at: modelURL)
        state = .notDownloaded
        downloadProgress = 0
        bytesDownloaded = 0
        lastError = nil
    }

    func generate(appContext: String, conversation: [ChatMessage], onToken: @escaping @MainActor (String) -> Void) async throws {
        guard isInstalled else { throw LocalAIError.modelNotDownloaded }
        #if canImport(SwiftLlama)
        if loadedModel == nil || loadedTier != selectedTier { await loadModel() }
        guard let loadedModel, loadedTier == selectedTier else { throw LocalAIError.modelNotLoaded }

        state = .generating
        defer { state = isInstalled ? .ready : .notDownloaded }

        // Keep the proven v0.6.4 stable sampler path: greedy only, tiny native batches,
        // no risky top-k/top-p chain on iOS.
        let params = SamplingParams(temperature: 0.0, topP: 1.0, topK: 1, repeatPenalty: 1.0, maxTokens: profile.maxTokens)
        let actor = try LlamaActor(model: loadedModel, params: params)
        let prompt = buildPrompt(appContext: appContext, conversation: conversation)
        lastPromptCharacters = prompt.count
        let stream = await actor.generate(prompt: prompt, params: params)
        for try await token in stream { await onToken(token) }
        #else
        throw LocalAIError.runtimeUnavailable
        #endif
    }

    private func buildPrompt(appContext: String, conversation: [ChatMessage]) -> String {
        let compactContext = clipped(appContext, maxCharacters: max(1_750, profile.promptBudget - 700))
        let system = """
        You are ZK Agent, a local autonomous-style assistant inside an XAUUSD analysis app. Talk naturally and reason from evidence instead of behaving like a FAQ bot.
        The app already calculated hard market facts and tool results for you. Use them. Never repeat feed/schema definitions unless asked.
        You may discuss the entire app: the custom Signal chart, recent candles/ticks, structure, levels, liquidity, indicators, drawings, backtest status, settings, model vault and current screen.
        AGENT WORKFLOW: understand the goal -> inspect supplied evidence -> reconcile conflicts -> explain the conclusion -> state what would confirm/invalidate it. If a tool was executed, acknowledge it.
        For chart analysis, cite actual prices and distinguish observation from inference. Do not fabricate IC Markets quotes: the custom chart is exactly what the agent reads, but it is not candle-for-candle IC Markets until an authorized broker stream is connected.
        The separate trading model is authoritative for future BUY/WAIT/SELL signals. If it is disabled, do not invent trade probabilities or claim a validated signal.
        Keep answers conversational, useful and compact. Ask a follow-up only when genuinely necessary.

        APP + AGENT EVIDENCE
        \(compactContext)
        END EVIDENCE
        """

        var parts: [String] = ["<|im_start|>system\n\(system)\n<|im_end|>"]
        // Persistent history exists on disk, but only recent turns plus an older compact summary
        // are injected so the small model remains stable.
        let recent = conversation.suffix(selectedTier == .smart ? 4 : 3)
        for message in recent {
            let role = message.role == .user ? "user" : "assistant"
            let cleaned = message.text.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !cleaned.isEmpty else { continue }
            let compact = clipped(cleaned, maxCharacters: selectedTier == .smart ? 360 : 280)
            parts.append("<|im_start|>\(role)\n\(compact)\n<|im_end|>")
        }
        parts.append("<|im_start|>assistant\n")
        return clipped(parts.joined(separator: "\n"), maxCharacters: profile.promptBudget, keepTail: true)
    }

    private func clipped(_ text: String, maxCharacters: Int, keepTail: Bool = false) -> String {
        guard text.count > maxCharacters else { return text }
        if keepTail {
            let start = text.index(text.endIndex, offsetBy: -maxCharacters)
            return String(text[start...])
        }
        let end = text.index(text.startIndex, offsetBy: maxCharacters)
        return String(text[..<end]) + "\n[context trimmed for local inference safety]"
    }

    private static func formatBytes(_ value: Int64) -> String {
        let formatter = ByteCountFormatter(); formatter.allowedUnits = [.useMB, .useGB]; formatter.countStyle = .file
        return formatter.string(fromByteCount: value)
    }
}

enum LocalAIError: LocalizedError {
    case modelNotDownloaded
    case modelNotLoaded
    case runtimeUnavailable

    var errorDescription: String? {
        switch self {
        case .modelNotDownloaded: return "Download the selected local AI model first."
        case .modelNotLoaded: return "The selected local AI model could not be loaded."
        case .runtimeUnavailable: return "The local inference runtime is unavailable in this build."
        }
    }
}
