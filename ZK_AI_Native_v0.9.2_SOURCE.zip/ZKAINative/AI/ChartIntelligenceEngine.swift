import Foundation

struct ChartLevel: Equatable {
    let price: Double
    let touches: Int
}

struct ChartIntelligenceSnapshot: Equatable {
    let currentPrice: Double?
    let trend1m: String
    let trend5m: String
    let trend15m: String
    let structure: String
    let event: String
    let support: ChartLevel?
    let resistance: ChartLevel?
    let liquidity: String
    let imbalance: String
    let momentum: String
    let volatility: String
    let rangePosition: String
    let lastCandle: String
    let candleCount: Int

    var compactPrompt: String {
        var rows: [String] = []
        rows.append("CHART READ: 1M=\(trend1m), 5M=\(trend5m), 15M=\(trend15m); structure=\(structure); event=\(event)")
        if let currentPrice { rows.append("Price=\(f(currentPrice)); position=\(rangePosition); volatility=\(volatility); momentum=\(momentum)") }
        rows.append("Levels: support=\(levelText(support)); resistance=\(levelText(resistance))")
        rows.append("Liquidity: \(liquidity)")
        rows.append("Imbalance: \(imbalance)")
        rows.append("Last candle: \(lastCandle)")
        rows.append("This is calculated from \(candleCount) machine-readable 1M candles. Interpret the chart; do not repeat feed metadata.")
        return rows.joined(separator: "\n")
    }

    var userFacingReport: String {
        var rows: [String] = []
        rows.append("CHART READ")
        if let currentPrice { rows.append("Price: \(f(currentPrice))") }
        rows.append("Trend: 1M \(trend1m) • 5M \(trend5m) • 15M \(trend15m)")
        rows.append("Structure: \(structure). \(event)")
        rows.append("Key levels: support \(levelText(support)) • resistance \(levelText(resistance))")
        rows.append("Liquidity: \(liquidity)")
        rows.append("Momentum/volatility: \(momentum); \(volatility)")
        rows.append("Imbalance: \(imbalance)")
        rows.append("Location: \(rangePosition)")
        rows.append("Latest candle: \(lastCandle)")
        rows.append("This is chart analysis, not a trained BUY/SELL signal. The trading model is still separate.")
        return rows.joined(separator: "\n\n")
    }

    private func levelText(_ level: ChartLevel?) -> String {
        guard let level else { return "unavailable" }
        return "\(f(level.price)) (\(level.touches)x)"
    }

    private func f(_ value: Double) -> String { String(format: "%.2f", value) }
}

enum ChartIntelligenceEngine {
    static func snapshot(candles: [ChartCandle], currentPrice: Double?) -> ChartIntelligenceSnapshot {
        let ordered = candles.sorted { $0.timestamp < $1.timestamp }
        guard !ordered.isEmpty else {
            return .init(
                currentPrice: currentPrice,
                trend1m: "NO DATA",
                trend5m: "NO DATA",
                trend15m: "NO DATA",
                structure: "No machine-readable candles loaded",
                event: "No structure event available",
                support: nil,
                resistance: nil,
                liquidity: "Unavailable",
                imbalance: "Unavailable",
                momentum: "Unavailable",
                volatility: "Unavailable",
                rangePosition: "Unavailable",
                lastCandle: "Unavailable",
                candleCount: 0
            )
        }

        let price = currentPrice ?? ordered.last?.close
        let atr = atr14(ordered)
        let pivots = pivotLevels(ordered, atr: atr)
        let support = nearestLevel(pivots.lows, below: price, atr: atr)
        let resistance = nearestLevel(pivots.highs, above: price, atr: atr)

        return .init(
            currentPrice: price,
            trend1m: trend(ordered),
            trend5m: trend(aggregate(ordered, minutes: 5)),
            trend15m: trend(aggregate(ordered, minutes: 15)),
            structure: structure(ordered),
            event: structureEvent(ordered),
            support: support,
            resistance: resistance,
            liquidity: liquidityRead(ordered, atr: atr),
            imbalance: imbalanceRead(ordered),
            momentum: momentumRead(ordered, atr: atr),
            volatility: volatilityRead(ordered, atr: atr),
            rangePosition: rangePosition(ordered, price: price),
            lastCandle: lastCandleRead(ordered, atr: atr),
            candleCount: ordered.count
        )
    }

    static func shouldUseDirectReport(_ query: String) -> Bool {
        let q = query.lowercased()
        let phrases = [
            "analyse gold", "analyze gold", "what do you see", "read the chart",
            "check the chart", "analyse the chart", "analyze the chart", "explain structure"
        ]
        return phrases.contains(where: q.contains)
    }

    private static func aggregate(_ candles: [ChartCandle], minutes: Int) -> [ChartCandle] {
        guard minutes > 1 else { return candles }
        let bucket = TimeInterval(minutes * 60)
        var groups: [Int: [ChartCandle]] = [:]
        for candle in candles {
            let key = Int(floor(candle.timestamp.timeIntervalSince1970 / bucket))
            groups[key, default: []].append(candle)
        }
        return groups.keys.sorted().enumerated().compactMap { index, key in
            guard let group = groups[key]?.sorted(by: { $0.timestamp < $1.timestamp }),
                  let first = group.first,
                  let last = group.last else { return nil }
            return ChartCandle(
                index: index,
                timestamp: first.timestamp,
                open: first.open,
                high: group.map(\.high).max() ?? first.high,
                low: group.map(\.low).min() ?? first.low,
                close: last.close,
                volume: group.compactMap(\.volume).reduce(0, +)
            )
        }
    }

    private static func trend(_ candles: [ChartCandle]) -> String {
        let closes = candles.map(\.close)
        guard closes.count >= 10, let last = closes.last else { return "UNCLEAR" }
        let fast = ema(closes, length: min(9, closes.count))
        let slow = ema(closes, length: min(21, closes.count))
        guard let fast, let slow else { return "UNCLEAR" }
        let slopeWindow = Array(closes.suffix(min(6, closes.count)))
        let slope = (slopeWindow.last ?? last) - (slopeWindow.first ?? last)
        if last > fast && fast > slow && slope > 0 { return "BULLISH" }
        if last < fast && fast < slow && slope < 0 { return "BEARISH" }
        return "RANGING/MIXED"
    }

    private static func structure(_ candles: [ChartCandle]) -> String {
        let pivots = swings(candles)
        guard pivots.highs.count >= 2, pivots.lows.count >= 2 else { return "No clear swing sequence yet" }
        let h1 = pivots.highs[pivots.highs.count - 2].price
        let h2 = pivots.highs.last!.price
        let l1 = pivots.lows[pivots.lows.count - 2].price
        let l2 = pivots.lows.last!.price
        if h2 > h1 && l2 > l1 { return "HH + HL bullish sequence" }
        if h2 < h1 && l2 < l1 { return "LH + LL bearish sequence" }
        if h2 > h1 && l2 < l1 { return "Expanding range / two-sided volatility" }
        return "Compressed / mixed swings"
    }

    private static func structureEvent(_ candles: [ChartCandle]) -> String {
        guard let last = candles.last else { return "No event" }
        let pivots = swings(Array(candles.dropLast()))
        guard let high = pivots.highs.last?.price, let low = pivots.lows.last?.price else { return "No confirmed BOS/CHOCH" }
        let previousTrend = trend(Array(candles.dropLast()))
        if last.close > high {
            return previousTrend == "BEARISH" ? "Bullish CHOCH: close broke the latest swing high \(f(high))" : "Bullish BOS above \(f(high))"
        }
        if last.close < low {
            return previousTrend == "BULLISH" ? "Bearish CHOCH: close broke the latest swing low \(f(low))" : "Bearish BOS below \(f(low))"
        }
        return "No fresh confirmed BOS/CHOCH on the latest close"
    }

    private static func pivotLevels(_ candles: [ChartCandle], atr: Double?) -> (highs: [Double], lows: [Double]) {
        let s = swings(candles)
        return (s.highs.map(\.price), s.lows.map(\.price))
    }

    private static func nearestLevel(_ raw: [Double], below price: Double?, atr: Double?) -> ChartLevel? {
        guard let price else { return nil }
        let candidates = raw.filter { $0 < price }.suffix(30)
        return clusteredNearest(Array(candidates), reference: price, preferBelow: true, atr: atr)
    }

    private static func nearestLevel(_ raw: [Double], above price: Double?, atr: Double?) -> ChartLevel? {
        guard let price else { return nil }
        let candidates = raw.filter { $0 > price }.suffix(30)
        return clusteredNearest(Array(candidates), reference: price, preferBelow: false, atr: atr)
    }

    private static func clusteredNearest(_ values: [Double], reference: Double, preferBelow: Bool, atr: Double?) -> ChartLevel? {
        guard !values.isEmpty else { return nil }
        let tolerance = max((atr ?? reference * 0.00025) * 0.35, reference * 0.00008)
        var clusters: [[Double]] = []
        for value in values.sorted() {
            if let index = clusters.indices.last, let mean = average(clusters[index]), abs(value - mean) <= tolerance {
                clusters[index].append(value)
            } else {
                clusters.append([value])
            }
        }
        let levels = clusters.compactMap { cluster -> ChartLevel? in
            guard let mean = average(cluster) else { return nil }
            return ChartLevel(price: mean, touches: cluster.count)
        }
        return levels.min { a, b in
            let da = abs(reference - a.price)
            let db = abs(reference - b.price)
            if abs(da - db) < tolerance { return a.touches > b.touches }
            return da < db
        }
    }

    private static func liquidityRead(_ candles: [ChartCandle], atr: Double?) -> String {
        guard candles.count >= 24, let last = candles.last else { return "Insufficient candles" }
        let prior = Array(candles.dropLast().suffix(20))
        guard let priorHigh = prior.map(\.high).max(), let priorLow = prior.map(\.low).min() else { return "Unavailable" }
        if last.high > priorHigh && last.close < priorHigh { return "Buy-side sweep above \(f(priorHigh)); price closed back below" }
        if last.low < priorLow && last.close > priorLow { return "Sell-side sweep below \(f(priorLow)); price closed back above" }

        let s = swings(Array(candles.suffix(90)))
        let tolerance = max((atr ?? 1.0) * 0.18, (candles.last?.close ?? 1) * 0.00005)
        if let pair = closestPair(s.highs.map(\.price), tolerance: tolerance) {
            return "Equal/near-equal highs around \(f((pair.0 + pair.1) / 2)); buy-side liquidity may sit above"
        }
        if let pair = closestPair(s.lows.map(\.price), tolerance: tolerance) {
            return "Equal/near-equal lows around \(f((pair.0 + pair.1) / 2)); sell-side liquidity may sit below"
        }
        return "No obvious fresh sweep or equal-high/low pool detected"
    }

    private static func imbalanceRead(_ candles: [ChartCandle]) -> String {
        guard candles.count >= 3 else { return "Insufficient candles" }
        let recent = Array(candles.suffix(40))
        for i in stride(from: recent.count - 1, through: 2, by: -1) {
            let a = recent[i - 2]
            let c = recent[i]
            if c.low > a.high { return "Recent bullish FVG \(f(a.high))-\(f(c.low))" }
            if c.high < a.low { return "Recent bearish FVG \(f(c.high))-\(f(a.low))" }
        }
        return "No obvious recent 3-candle FVG"
    }

    private static func momentumRead(_ candles: [ChartCandle], atr: Double?) -> String {
        guard let last = candles.last else { return "Unavailable" }
        let body = abs(last.close - last.open)
        let a = max(atr ?? 0, 0.0001)
        let ratio = body / a
        if ratio >= 1.25 { return last.close >= last.open ? "Strong bullish impulse (body \(String(format: "%.1f", ratio))x ATR)" : "Strong bearish impulse (body \(String(format: "%.1f", ratio))x ATR)" }
        if ratio <= 0.25 { return "Low-body / indecision candle" }
        let closes = candles.suffix(6).map(\.close)
        if let first = closes.first, let end = closes.last {
            let delta = end - first
            if delta > a { return "Bullish short-term momentum" }
            if delta < -a { return "Bearish short-term momentum" }
        }
        return "Moderate / mixed short-term momentum"
    }

    private static func volatilityRead(_ candles: [ChartCandle], atr: Double?) -> String {
        guard let atr, let price = candles.last?.close, price > 0 else { return "Unavailable" }
        let pct = atr / price * 100
        let recentRanges = candles.suffix(20).map { $0.high - $0.low }
        let avg = average(Array(recentRanges)) ?? atr
        let lastRange = recentRanges.last ?? avg
        if lastRange > avg * 1.8 { return "EXPANDING (ATR \(f(atr)), latest range elevated)" }
        if lastRange < avg * 0.55 { return "COMPRESSING (ATR \(f(atr)), latest range muted)" }
        return "NORMAL (ATR \(f(atr)), \(String(format: "%.3f", pct))% of price)"
    }

    private static func rangePosition(_ candles: [ChartCandle], price: Double?) -> String {
        guard let price else { return "Unavailable" }
        let window = Array(candles.suffix(180))
        guard let high = window.map(\.high).max(), let low = window.map(\.low).min(), high > low else { return "Unavailable" }
        let p = (price - low) / (high - low)
        if p >= 0.8 { return "Near top of recent 3h range (\(Int(p * 100))%)" }
        if p <= 0.2 { return "Near bottom of recent 3h range (\(Int(p * 100))%)" }
        return "Mid-range (\(Int(p * 100))% from recent 3h low)"
    }

    private static func lastCandleRead(_ candles: [ChartCandle], atr: Double?) -> String {
        guard let c = candles.last else { return "Unavailable" }
        let range = max(c.high - c.low, 0.0001)
        let body = abs(c.close - c.open)
        let upper = c.high - max(c.open, c.close)
        let lower = min(c.open, c.close) - c.low
        let direction = c.close >= c.open ? "bullish" : "bearish"
        if upper / range > 0.55 { return "\(direction) candle with large upper rejection wick" }
        if lower / range > 0.55 { return "\(direction) candle with large lower rejection wick" }
        if body / range > 0.72 { return "strong-bodied \(direction) candle" }
        if body / range < 0.2 { return "doji/indecision-style candle" }
        return "balanced \(direction) candle"
    }

    private struct SwingPoint {
        let price: Double
        let index: Int
    }

    private static func swings(_ candles: [ChartCandle]) -> (highs: [SwingPoint], lows: [SwingPoint]) {
        guard candles.count >= 5 else { return ([], []) }
        var highs: [SwingPoint] = []
        var lows: [SwingPoint] = []
        for i in 2..<(candles.count - 2) {
            let c = candles[i]
            if c.high > candles[i - 1].high && c.high >= candles[i - 2].high && c.high >= candles[i + 1].high && c.high > candles[i + 2].high {
                highs.append(.init(price: c.high, index: i))
            }
            if c.low < candles[i - 1].low && c.low <= candles[i - 2].low && c.low <= candles[i + 1].low && c.low < candles[i + 2].low {
                lows.append(.init(price: c.low, index: i))
            }
        }
        return (highs, lows)
    }

    private static func atr14(_ candles: [ChartCandle]) -> Double? {
        guard candles.count >= 15 else { return nil }
        let recent = Array(candles.suffix(15))
        var tr: [Double] = []
        for i in 1..<recent.count {
            let c = recent[i]
            let p = recent[i - 1]
            tr.append(max(c.high - c.low, abs(c.high - p.close), abs(c.low - p.close)))
        }
        return average(tr)
    }

    private static func ema(_ values: [Double], length: Int) -> Double? {
        guard !values.isEmpty, length > 0 else { return nil }
        let alpha = 2.0 / Double(length + 1)
        var result = values.first!
        for value in values.dropFirst() { result = alpha * value + (1 - alpha) * result }
        return result
    }

    private static func closestPair(_ values: [Double], tolerance: Double) -> (Double, Double)? {
        let sorted = values.sorted()
        guard sorted.count >= 2 else { return nil }
        var best: (Double, Double)?
        var bestDistance = Double.greatestFiniteMagnitude
        for i in 1..<sorted.count {
            let d = abs(sorted[i] - sorted[i - 1])
            if d <= tolerance && d < bestDistance {
                best = (sorted[i - 1], sorted[i])
                bestDistance = d
            }
        }
        return best
    }

    private static func average(_ values: [Double]) -> Double? {
        guard !values.isEmpty else { return nil }
        return values.reduce(0, +) / Double(values.count)
    }

    private static func f(_ value: Double) -> String { String(format: "%.2f", value) }
}
