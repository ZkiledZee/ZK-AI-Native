import Foundation
import Combine

@MainActor
final class SignalEngine: ObservableObject {
    @Published var enabled: Bool {
        didSet {
            UserDefaults.standard.set(enabled, forKey: "zk.signal.enabled")
            if !enabled { resetToWaiting(reason: "Signal engine paused by user.") }
        }
    }
    @Published var mode: SignalEngineMode {
        didSet {
            UserDefaults.standard.set(mode.rawValue, forKey: "zk.signal.mode")
            resetCandidateClock()
        }
    }
    @Published private(set) var snapshot: SignalSnapshot = .dataOnly
    @Published private(set) var activeTrade: PaperSignalTrade?
    @Published private(set) var recentTrades: [PaperSignalTrade] = []
    @Published private(set) var lastEvaluation: Date?
    @Published private(set) var lastScore: Double = 0
    @Published private(set) var lastSetupText = "Waiting for enough 1M data…"
    @Published private(set) var todayTradeCount = 0

    private var market: MarketDataService?
    private weak var appState: AppState?
    private var cancellables = Set<AnyCancellable>()
    private var lastSignalAt: Date?
    private var lastProcessedMinute: Date?
    private var lastEvaluationPrice: Double?
    private var currentTradingDay = Calendar.current.startOfDay(for: Date())

    init() {
        let defaults = UserDefaults.standard
        enabled = defaults.object(forKey: "zk.signal.enabled") == nil ? true : defaults.bool(forKey: "zk.signal.enabled")
        mode = SignalEngineMode(rawValue: defaults.string(forKey: "zk.signal.mode") ?? "") ?? .selective
        loadTrades()
        recalcTodayCount()
    }

    func start(market: MarketDataService, state: AppState) {
        guard self.market == nil else { return }
        self.market = market
        self.appState = state

        market.$candles
            .receive(on: RunLoop.main)
            .sink { [weak self] _ in self?.evaluateIfNeeded(force: true) }
            .store(in: &cancellables)

        market.$spotPrice
            .receive(on: RunLoop.main)
            .sink { [weak self] _ in self?.evaluateIfNeeded(force: false) }
            .store(in: &cancellables)

        evaluateIfNeeded(force: true)
    }

    func setEnabled(_ value: Bool) { enabled = value }
    func setMode(_ newMode: SignalEngineMode) { mode = newMode }
    func forceEvaluate() { evaluateIfNeeded(force: true) }

    private func evaluateIfNeeded(force: Bool) {
        guard let market else { return }
        rollTradingDayIfNeeded()
        guard enabled else {
            resetToWaiting(reason: "Signal engine paused by user.")
            return
        }
        guard market.feedStatus != .offline else {
            resetToWaiting(reason: "Market feed is offline; no setup is evaluated.")
            return
        }
        guard let price = market.currentPrice, market.candles.count >= 30 else {
            resetToWaiting(reason: "Waiting for at least 30 machine-readable 1M candles.")
            return
        }

        manageOpenTrade(price: price)
        if activeTrade != nil { return }

        let minute = floorMinute(market.candles.last?.timestamp ?? Date())
        let movedEnough = lastEvaluationPrice.map { abs(price - $0) >= max(price * 0.00005, 0.20) } ?? true
        if !force && !movedEnough && lastProcessedMinute == minute { return }

        lastProcessedMinute = minute
        lastEvaluationPrice = price
        lastEvaluation = Date()

        guard cooldownPassed(), todayTradeCount < dailyCap else {
            let remaining = max(0, Int(cooldownInterval - Date().timeIntervalSince(lastSignalAt ?? .distantPast)))
            snapshot = waitingSnapshot(reason: todayTradeCount >= dailyCap ? "Daily paper-signal cap reached for this mode." : "Cooldown active for roughly \(max(1, remaining / 60)) more minute(s).")
            syncSnapshot()
            return
        }

        let result = scoreSetup(candles: market.candles, price: price)
        lastScore = result.absoluteScore
        lastSetupText = result.explanation

        guard let side = result.side, result.absoluteScore >= entryThreshold else {
            snapshot = waitingSnapshot(reason: result.explanation)
            syncSnapshot()
            return
        }

        openPaperSignal(side: side, result: result, price: price)
    }

    private func manageOpenTrade(price: Double) {
        guard var trade = activeTrade else { return }
        let hitSL: Bool
        let hitTP: Bool
        switch trade.side {
        case .buy:
            hitSL = price <= trade.stopLoss
            hitTP = price >= trade.takeProfit
        case .sell:
            hitSL = price >= trade.stopLoss
            hitTP = price <= trade.takeProfit
        case .wait:
            return
        }

        if hitSL || hitTP {
            trade.closedAt = Date()
            trade.exitPrice = price
            trade.outcome = hitTP ? "TP" : "SL"
            activeTrade = nil
            if let idx = recentTrades.firstIndex(where: { $0.id == trade.id }) {
                recentTrades[idx] = trade
            } else {
                recentTrades.insert(trade, at: 0)
            }
            persistTrades()
            snapshot = waitingSnapshot(reason: "Previous paper signal closed at \(trade.outcome). Scanning for the next setup.")
            syncSnapshot()
            return
        }

        snapshot = SignalSnapshot(
            side: trade.side,
            buyProbability: trade.side == .buy ? trade.confidence : (1 - trade.confidence) * 0.25,
            waitProbability: max(0.05, 1 - trade.confidence),
            sellProbability: trade.side == .sell ? trade.confidence : (1 - trade.confidence) * 0.25,
            directionalConfidence: trade.confidence,
            executionConfidence: trade.confidence,
            entry: trade.entry,
            stopLoss: trade.stopLoss,
            takeProfit: trade.takeProfit,
            riskReward: rewardRisk(trade),
            lifecycle: "PAPER OPEN • \(trade.mode.rawValue)",
            reason: trade.reason
        )
        normalizeProbabilities()
        syncSnapshot()
    }

    private func openPaperSignal(side: SignalSide, result: SetupScore, price: Double) {
        let atr = max(result.atr, price * 0.00022)
        let stopDistance = mode == .fastScalper ? atr * 0.62 : atr * 0.92
        let rr = mode == .fastScalper ? 1.18 : 1.75
        let stop = side == .buy ? price - stopDistance : price + stopDistance
        let target = side == .buy ? price + stopDistance * rr : price - stopDistance * rr
        let confidence = min(0.91, max(0.53, 0.50 + result.absoluteScore / 200.0))

        let trade = PaperSignalTrade(
            openedAt: Date(),
            side: side,
            mode: mode,
            entry: price,
            stopLoss: stop,
            takeProfit: target,
            confidence: confidence,
            score: result.absoluteScore,
            reason: result.explanation,
            outcome: "OPEN"
        )
        activeTrade = trade
        recentTrades.insert(trade, at: 0)
        if recentTrades.count > 60 { recentTrades.removeLast(recentTrades.count - 60) }
        lastSignalAt = Date()
        todayTradeCount += 1
        persistTrades()

        snapshot = SignalSnapshot(
            side: side,
            buyProbability: side == .buy ? confidence : max(0.04, (1 - confidence) * 0.22),
            waitProbability: max(0.06, 1 - confidence),
            sellProbability: side == .sell ? confidence : max(0.04, (1 - confidence) * 0.22),
            directionalConfidence: confidence,
            executionConfidence: confidence,
            entry: price,
            stopLoss: stop,
            takeProfit: target,
            riskReward: rr,
            lifecycle: "PAPER OPEN • \(mode.rawValue)",
            reason: result.explanation
        )
        normalizeProbabilities()
        syncSnapshot()

        Task {
            await NotificationManager.shared.sendSignal(
                side: side.rawValue,
                price: price,
                mode: mode.rawValue,
                stop: stop,
                target: target
            )
        }
    }

    private func scoreSetup(candles: [ChartCandle], price: Double) -> SetupScore {
        let ordered = candles.sorted { $0.timestamp < $1.timestamp }
        let closes = ordered.map(\.close)
        guard closes.count >= 30 else { return .none("Not enough candles.") }

        let atr = atr14(ordered) ?? max(price * 0.00025, 0.5)
        let ema8 = ema(closes, length: 8) ?? price
        let ema21 = ema(closes, length: 21) ?? price
        let rsi = rsi14(closes) ?? 50
        let intel = ChartIntelligenceEngine.snapshot(candles: ordered, currentPrice: price)
        let recent = Array(ordered.suffix(mode == .fastScalper ? 12 : 24))
        let prior = Array(ordered.dropLast().suffix(mode == .fastScalper ? 12 : 24))
        let priorHigh = prior.map(\.high).max() ?? price
        let priorLow = prior.map(\.low).min() ?? price
        let latest = ordered.last!
        let body = latest.close - latest.open
        let bodyATR = body / max(atr, 0.0001)

        var score = 0.0
        var reasons: [String] = []

        if ema8 > ema21 { score += 20; reasons.append("EMA8 above EMA21") }
        if ema8 < ema21 { score -= 20; reasons.append("EMA8 below EMA21") }

        switch intel.trend5m {
        case "BULLISH": score += mode == .fastScalper ? 10 : 18; reasons.append("5M bullish")
        case "BEARISH": score -= mode == .fastScalper ? 10 : 18; reasons.append("5M bearish")
        default: break
        }
        switch intel.trend15m {
        case "BULLISH": score += mode == .fastScalper ? 4 : 11
        case "BEARISH": score -= mode == .fastScalper ? 4 : 11
        default: break
        }

        if rsi >= 53 && rsi <= 72 { score += 10; reasons.append("RSI supports upside") }
        if rsi <= 47 && rsi >= 28 { score -= 10; reasons.append("RSI supports downside") }
        if rsi > 78 { score -= 7; reasons.append("RSI stretched high") }
        if rsi < 22 { score += 7; reasons.append("RSI stretched low") }

        if latest.close > priorHigh { score += 18; reasons.append("1M breakout above recent high") }
        if latest.close < priorLow { score -= 18; reasons.append("1M breakout below recent low") }

        if bodyATR > 0.55 { score += min(13, bodyATR * 8); reasons.append("bullish impulse") }
        if bodyATR < -0.55 { score -= min(13, abs(bodyATR) * 8); reasons.append("bearish impulse") }

        let last4 = recent.suffix(4).map(\.close)
        if let first = last4.first, let last = last4.last {
            let momentum = (last - first) / max(atr, 0.0001)
            if momentum > 0.55 { score += min(12, momentum * 6) }
            if momentum < -0.55 { score -= min(12, abs(momentum) * 6) }
        }

        if intel.event.contains("Bullish BOS") || intel.event.contains("Bullish CHOCH") { score += 14; reasons.append("bullish structure break") }
        if intel.event.contains("Bearish BOS") || intel.event.contains("Bearish CHOCH") { score -= 14; reasons.append("bearish structure break") }

        if intel.liquidity.lowercased().contains("sell-side sweep") { score += 10; reasons.append("sell-side sweep reclaimed") }
        if intel.liquidity.lowercased().contains("buy-side sweep") { score -= 10; reasons.append("buy-side sweep rejected") }

        // Avoid chasing directly into a nearby opposing level in selective mode.
        if mode == .selective {
            if let resistance = intel.resistance, score > 0, resistance.price - price < atr * 0.55 {
                score -= 14; reasons.append("near resistance")
            }
            if let support = intel.support, score < 0, price - support.price < atr * 0.55 {
                score += 14; reasons.append("near support")
            }
        }

        let side: SignalSide? = score >= entryThreshold ? .buy : (score <= -entryThreshold ? .sell : nil)
        let absScore = min(100, abs(score))
        let bias = score > 8 ? "Bullish" : (score < -8 ? "Bearish" : "Mixed")
        let modeText = mode == .fastScalper ? "Fast scalp" : "Selective"
        let explanation = "\(modeText) scan: \(bias) score \(Int(absScore))/100. " + (reasons.isEmpty ? "No strong confluence yet." : reasons.prefix(5).joined(separator: " • "))
        return SetupScore(side: side, absoluteScore: absScore, rawScore: score, atr: atr, explanation: explanation)
    }

    private var entryThreshold: Double { mode == .fastScalper ? 58 : 72 }
    private var cooldownInterval: TimeInterval { mode == .fastScalper ? 8 * 60 : 55 * 60 }
    private var dailyCap: Int { mode == .fastScalper ? 14 : 4 }

    private func cooldownPassed() -> Bool {
        guard let lastSignalAt else { return true }
        return Date().timeIntervalSince(lastSignalAt) >= cooldownInterval
    }

    private func waitingSnapshot(reason: String) -> SignalSnapshot {
        let edge = min(0.32, max(0, lastScore / 250.0))
        return SignalSnapshot(
            side: .wait,
            buyProbability: (0.5 - edge) / 2,
            waitProbability: 0.5 + edge,
            sellProbability: (0.5 - edge) / 2,
            directionalConfidence: min(0.49, lastScore / 100),
            executionConfidence: min(0.49, lastScore / 100),
            entry: nil,
            stopLoss: nil,
            takeProfit: nil,
            riskReward: nil,
            lifecycle: "SCANNING • \(mode.rawValue)",
            reason: reason
        )
    }

    private func resetToWaiting(reason: String) {
        snapshot = SignalSnapshot(
            side: .wait,
            buyProbability: 0,
            waitProbability: 1,
            sellProbability: 0,
            directionalConfidence: 0,
            executionConfidence: 0,
            entry: nil,
            stopLoss: nil,
            takeProfit: nil,
            riskReward: nil,
            lifecycle: enabled ? "SCANNING" : "ENGINE PAUSED",
            reason: reason
        )
        syncSnapshot()
    }

    private func syncSnapshot() { appState?.signal = snapshot }

    private func normalizeProbabilities() {
        let total = snapshot.buyProbability + snapshot.waitProbability + snapshot.sellProbability
        guard total > 0 else { return }
        snapshot.buyProbability /= total
        snapshot.waitProbability /= total
        snapshot.sellProbability /= total
    }

    private func rewardRisk(_ trade: PaperSignalTrade) -> Double? {
        let risk = abs(trade.entry - trade.stopLoss)
        guard risk > 0 else { return nil }
        return abs(trade.takeProfit - trade.entry) / risk
    }

    private func rollTradingDayIfNeeded() {
        let today = Calendar.current.startOfDay(for: Date())
        if today != currentTradingDay {
            currentTradingDay = today
            todayTradeCount = 0
        }
    }

    private func recalcTodayCount() {
        let start = Calendar.current.startOfDay(for: Date())
        currentTradingDay = start
        todayTradeCount = recentTrades.filter { $0.openedAt >= start }.count
        lastSignalAt = recentTrades.map(\.openedAt).max()
        activeTrade = recentTrades.first(where: { $0.isOpen })
        if let activeTrade { snapshotFromPersisted(activeTrade) }
    }

    private func snapshotFromPersisted(_ trade: PaperSignalTrade) {
        snapshot = SignalSnapshot(
            side: trade.side,
            buyProbability: trade.side == .buy ? trade.confidence : 0.05,
            waitProbability: max(0.06, 1 - trade.confidence),
            sellProbability: trade.side == .sell ? trade.confidence : 0.05,
            directionalConfidence: trade.confidence,
            executionConfidence: trade.confidence,
            entry: trade.entry,
            stopLoss: trade.stopLoss,
            takeProfit: trade.takeProfit,
            riskReward: rewardRisk(trade),
            lifecycle: "PAPER OPEN • \(trade.mode.rawValue)",
            reason: trade.reason
        )
        normalizeProbabilities()
    }

    private func persistTrades() {
        if let data = try? JSONEncoder().encode(recentTrades) {
            UserDefaults.standard.set(data, forKey: "zk.signal.paperTrades.v1")
        }
    }

    private func loadTrades() {
        guard let data = UserDefaults.standard.data(forKey: "zk.signal.paperTrades.v1"),
              let decoded = try? JSONDecoder().decode([PaperSignalTrade].self, from: data) else { return }
        recentTrades = decoded.sorted { $0.openedAt > $1.openedAt }
    }

    private func resetCandidateClock() {
        lastProcessedMinute = nil
        lastEvaluationPrice = nil
        forceEvaluate()
    }

    private func floorMinute(_ date: Date) -> Date {
        Date(timeIntervalSince1970: floor(date.timeIntervalSince1970 / 60) * 60)
    }

    private func atr14(_ candles: [ChartCandle]) -> Double? {
        guard candles.count >= 15 else { return nil }
        let recent = Array(candles.suffix(15))
        var values: [Double] = []
        for i in 1..<recent.count {
            let c = recent[i], p = recent[i - 1]
            values.append(max(c.high - c.low, abs(c.high - p.close), abs(c.low - p.close)))
        }
        return values.isEmpty ? nil : values.reduce(0, +) / Double(values.count)
    }

    private func ema(_ values: [Double], length: Int) -> Double? {
        guard let first = values.first, length > 0 else { return nil }
        let alpha = 2.0 / Double(length + 1)
        var result = first
        for value in values.dropFirst() { result = alpha * value + (1 - alpha) * result }
        return result
    }

    private func rsi14(_ values: [Double]) -> Double? {
        guard values.count >= 15 else { return nil }
        let recent = Array(values.suffix(15))
        var gains = 0.0, losses = 0.0
        for i in 1..<recent.count {
            let delta = recent[i] - recent[i - 1]
            if delta >= 0 { gains += delta } else { losses += -delta }
        }
        if losses == 0 { return 100 }
        let rs = (gains / 14.0) / (losses / 14.0)
        return 100 - (100 / (1 + rs))
    }
}

private struct SetupScore {
    let side: SignalSide?
    let absoluteScore: Double
    let rawScore: Double
    let atr: Double
    let explanation: String

    static func none(_ reason: String) -> SetupScore {
        .init(side: nil, absoluteScore: 0, rawScore: 0, atr: 0, explanation: reason)
    }
}
