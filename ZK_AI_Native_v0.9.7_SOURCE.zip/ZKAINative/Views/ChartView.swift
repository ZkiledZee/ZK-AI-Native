import SwiftUI

struct ChartView: View {
    @EnvironmentObject private var state: AppState
    @Environment(\.zkScale) private var scale

    var body: some View {
        VStack(spacing: 8 * scale) {
            ZKPageHeader(
                micro: "CTRADER WEB",
                title: "cTrader",
                pill: "LIVE WEB",
                pillColor: ZKTheme.green
            )

            HStack(spacing: 7 * scale) {
                Image(systemName: "rectangle.connected.to.line.below")
                    .font(.system(size: 10 * scale, weight: .bold))
                    .foregroundStyle(ZKTheme.purpleLight)
                VStack(alignment: .leading, spacing: 1 * scale) {
                    Text("Browser terminal")
                        .font(.system(size: 9 * scale, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                    Text("Log in to cTrader here — your password stays on cTrader's website")
                        .font(.system(size: 7.2 * scale, weight: .medium))
                        .foregroundStyle(ZKTheme.textMuted)
                        .lineLimit(1)
                }
                Spacer()
            }
            .padding(.horizontal, 10 * scale)
            .frame(height: 40 * scale)
            .background(ZKTheme.card.opacity(0.72))
            .overlay(RoundedRectangle(cornerRadius: 12 * scale).stroke(ZKTheme.border.opacity(0.75)))
            .clipShape(RoundedRectangle(cornerRadius: 12 * scale))

            CTraderBrowserWindow()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .padding(.horizontal, 12 * scale)
        .padding(.top, 8 * scale)
        .padding(.bottom, 8 * scale)
        .background(ZKTheme.background)
    }
}
