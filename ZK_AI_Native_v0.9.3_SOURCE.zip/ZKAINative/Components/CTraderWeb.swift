import SwiftUI
import WebKit

struct CTraderMarketChart: View {
    @Environment(\.zkScale) private var scale
    let symbol: String

    @State private var loading = true
    @State private var failed = false
    @State private var reloadToken = UUID()

    var body: some View {
        ZStack {
            CTraderWidgetWebView(kind: .marketChart(symbol: symbol), loading: $loading, failed: $failed)
                .id("\(symbol)-\(reloadToken.uuidString)")

            if loading {
                VStack(spacing: 8 * scale) {
                    ProgressView().tint(ZKTheme.purple)
                    Text("Loading cTrader • \(symbol)")
                        .font(.system(size: 9 * scale, weight: .bold))
                        .foregroundStyle(ZKTheme.textMuted)
                }
                .padding(13 * scale)
                .background(ZKTheme.card.opacity(0.94))
                .clipShape(RoundedRectangle(cornerRadius: 13 * scale))
            }

            if failed {
                VStack(spacing: 9 * scale) {
                    Image(systemName: "wifi.exclamationmark")
                        .font(.system(size: 24 * scale, weight: .semibold))
                        .foregroundStyle(ZKTheme.gold)
                    Text("cTrader chart unavailable")
                        .font(.system(size: 12 * scale, weight: .bold))
                    Button("Retry") {
                        loading = true
                        failed = false
                        reloadToken = UUID()
                    }
                    .font(.system(size: 9 * scale, weight: .black))
                    .buttonStyle(.bordered)
                    .tint(ZKTheme.purple)
                }
                .padding(16 * scale)
                .background(ZKTheme.card.opacity(0.97))
                .overlay(RoundedRectangle(cornerRadius: 14 * scale).stroke(ZKTheme.border))
                .clipShape(RoundedRectangle(cornerRadius: 14 * scale))
            }
        }
        .background(Color.black)
        .clipShape(RoundedRectangle(cornerRadius: 16 * scale))
        .onChange(of: symbol) { _, _ in
            loading = true
            failed = false
            reloadToken = UUID()
        }
    }
}

struct CTraderTerminalView: View {
    @Environment(\.zkScale) private var scale
    @State private var loading = true
    @State private var failed = false
    @State private var reloadToken = UUID()

    var body: some View {
        ZStack {
            CTraderWidgetWebView(kind: .terminal, loading: $loading, failed: $failed)
                .id(reloadToken)

            if loading {
                VStack(spacing: 8 * scale) {
                    ProgressView().tint(ZKTheme.green)
                    Text("Opening cTrader")
                        .font(.system(size: 9 * scale, weight: .bold))
                        .foregroundStyle(ZKTheme.textMuted)
                }
                .padding(13 * scale)
                .background(ZKTheme.card.opacity(0.94))
                .clipShape(RoundedRectangle(cornerRadius: 13 * scale))
            }

            if failed {
                VStack(spacing: 9 * scale) {
                    Image(systemName: "rectangle.connected.to.line.below")
                        .font(.system(size: 24 * scale, weight: .semibold))
                        .foregroundStyle(ZKTheme.gold)
                    Text("cTrader terminal could not load")
                        .font(.system(size: 12 * scale, weight: .bold))
                    Button("Reload") {
                        loading = true
                        failed = false
                        reloadToken = UUID()
                    }
                    .font(.system(size: 9 * scale, weight: .black))
                    .buttonStyle(.bordered)
                    .tint(ZKTheme.purple)
                }
                .padding(16 * scale)
                .background(ZKTheme.card.opacity(0.97))
                .overlay(RoundedRectangle(cornerRadius: 14 * scale).stroke(ZKTheme.border))
                .clipShape(RoundedRectangle(cornerRadius: 14 * scale))
            }
        }
        .background(Color.black)
        .clipShape(RoundedRectangle(cornerRadius: 16 * scale))
    }
}

private enum CTraderWidgetKind: Equatable {
    case marketChart(symbol: String)
    case terminal

    var key: String {
        switch self {
        case .marketChart(let symbol): return "chart-\(symbol)"
        case .terminal: return "terminal"
        }
    }

    var html: String {
        switch self {
        case .marketChart(let symbol):
            let clean = symbol.replacingOccurrences(of: "\"", with: "")
            return """
            <!doctype html>
            <html>
            <head>
              <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
              <style>
                html,body,#ctrader-plugin-root { margin:0; padding:0; width:100%; height:100%; overflow:hidden; background:#050508; }
                #ctrader-plugin-root { position:relative; display:block; }
              </style>
            </head>
            <body>
              <div id="ctrader-plugin-root"></div>
              <script id="init" type="text/javascript" src="https://ct.spotware.com/widget.js"></script>
              <script type="text/javascript">
                const script = document.getElementById('init');
                script.onload = () => {
                  putInitScript('runPlugin');
                  runPlugin('ctrader-plugin-root', {"route":"/market-chart/?s=\(clean)&period=M1&charttype=candlestick&palettename=dark&lang=en&w=900&h=900"});
                };
              </script>
            </body>
            </html>
            """

        case .terminal:
            return """
            <!doctype html>
            <html>
            <head>
              <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
              <style>
                html,body,#ctrader-plugin-root { margin:0; padding:0; width:100%; height:100%; overflow:hidden; background:#050508; }
                #ctrader-plugin-root { position:relative; display:block; }
              </style>
            </head>
            <body>
              <div id="ctrader-plugin-root"></div>
              <script id="init" type="text/javascript" src="https://app.ctrader.com/widget.js"></script>
              <script type="text/javascript">
                const script = document.getElementById('init');
                script.onload = () => {
                  putInitScript('runPlugin');
                  runPlugin('ctrader-plugin-root', {"route":"/?lang=en&theme=dark","appConfig":{"chart":{"initialChartLayout":"Single"}}});
                };
              </script>
            </body>
            </html>
            """
        }
    }
}

private struct CTraderWidgetWebView: UIViewRepresentable {
    let kind: CTraderWidgetKind
    @Binding var loading: Bool
    @Binding var failed: Bool

    func makeCoordinator() -> Coordinator { Coordinator(parent: self) }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = true

        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = .black
        webView.scrollView.backgroundColor = .black
        webView.scrollView.bounces = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.allowsLinkPreview = false
        webView.allowsBackForwardNavigationGestures = true
        context.coordinator.loadedKey = kind.key
        webView.loadHTMLString(kind.html, baseURL: URL(string: "https://app.ctrader.com"))
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        guard context.coordinator.loadedKey != kind.key else { return }
        context.coordinator.loadedKey = kind.key
        DispatchQueue.main.async {
            loading = true
            failed = false
        }
        webView.loadHTMLString(kind.html, baseURL: URL(string: "https://app.ctrader.com"))
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        var parent: CTraderWidgetWebView
        var loadedKey = ""

        init(parent: CTraderWidgetWebView) { self.parent = parent }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                self.parent.failed = false
                self.parent.loading = false
            }
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            DispatchQueue.main.async {
                self.parent.loading = false
                self.parent.failed = true
            }
        }

        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            DispatchQueue.main.async {
                self.parent.loading = false
                self.parent.failed = true
            }
        }

        func webView(
            _ webView: WKWebView,
            createWebViewWith configuration: WKWebViewConfiguration,
            for navigationAction: WKNavigationAction,
            windowFeatures: WKWindowFeatures
        ) -> WKWebView? {
            if navigationAction.targetFrame == nil, let url = navigationAction.request.url {
                webView.load(URLRequest(url: url))
            }
            return nil
        }
    }
}
