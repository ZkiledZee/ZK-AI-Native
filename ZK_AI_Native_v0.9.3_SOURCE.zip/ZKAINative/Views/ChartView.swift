import SwiftUI

struct ChartView: View {
    @EnvironmentObject private var state: AppState
    @Environment(\.zkScale) private var scale
    @AppStorage("zk.ctrader.viewMode") private var viewMode = 0

    var body: some View {
        VStack(spacing: 8 * scale) {
            ZKPageHeader(
                micro: "CTRADER • \(state.selectedMarket.symbol)",
                title: viewMode == 0 ? "Chart" : "Trade",
                pill: viewMode == 0 ? "M1" : "WEB",
                pillColor: ZKTheme.green
            )

            controls

            Group {
                if viewMode == 0 {
                    CTraderMarketChart(symbol: state.selectedMarket.symbol)
                } else {
                    CTraderTerminalView()
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .overlay(RoundedRectangle(cornerRadius: 16 * scale).stroke(ZKTheme.borderStrong.opacity(0.70)))
            .clipShape(RoundedRectangle(cornerRadius: 16 * scale))
        }
        .padding(.horizontal, 12 * scale)
        .padding(.top, 8 * scale)
        .padding(.bottom, 8 * scale)
        .background(ZKTheme.background)
    }

    private var controls: some View {
        VStack(spacing: 7 * scale) {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 6 * scale) {
                    ForEach(TradeMarket.watchlist) { market in
                        marketButton(market)
                    }
                }
            }

            HStack(spacing: 4 * scale) {
                modeButton("CHART", icon: "chart.xyaxis.line", value: 0)
                modeButton("TRADE", icon: "rectangle.connected.to.line.below", value: 1)
            }
            .padding(3 * scale)
            .background(ZKTheme.card.opacity(0.88))
            .clipShape(Capsule())
        }
    }

    private func marketButton(_ market: TradeMarket) -> some View {
        let selected = state.selectedMarketSymbol == market.symbol
        return Button {
            state.selectMarket(market)
            viewMode = 0
        } label: {
            HStack(spacing: 5 * scale) {
                Circle()
                    .fill(market.weekendFriendly ? ZKTheme.green : ZKTheme.purple)
                    .frame(width: 5 * scale, height: 5 * scale)
                Text(market.symbol)
                    .font(.system(size: 8 * scale, weight: .black, design: .rounded))
            }
            .foregroundStyle(selected ? .white : ZKTheme.textSoft)
            .padding(.horizontal, 10 * scale)
            .frame(height: 30 * scale)
            .background(selected ? ZKTheme.purple.opacity(0.24) : ZKTheme.card.opacity(0.72))
            .overlay(Capsule().stroke(selected ? ZKTheme.borderStrong : ZKTheme.border.opacity(0.65)))
            .clipShape(Capsule())
        }
        .buttonStyle(ZKPressStyle())
    }

    private func modeButton(_ title: String, icon: String, value: Int) -> some View {
        Button { viewMode = value } label: {
            HStack(spacing: 6 * scale) {
                Image(systemName: icon)
                    .font(.system(size: 9 * scale, weight: .bold))
                Text(title)
                    .font(.system(size: 8 * scale, weight: .black, design: .rounded))
            }
            .foregroundStyle(viewMode == value ? .white : ZKTheme.textMuted)
            .frame(maxWidth: .infinity)
            .frame(height: 31 * scale)
            .background(viewMode == value ? ZKTheme.purple.opacity(0.30) : .clear)
            .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }
}
