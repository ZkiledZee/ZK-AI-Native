# ZK AI Native v0.3.0 — iPhone UI polish build

This build deliberately focuses on getting the native iPhone app itself right before adding live-data or AI systems.

## v0.3 changes
- New gold/black ZK app icon and matching in-app brand mark
- Responsive UI scale based on iPhone width
- Rebalanced typography: smaller oversized headings, larger tiny labels/body text
- More native iOS spacing, safe-area behavior, button press feedback and tab haptics
- Cleaner bottom navigation using SF Symbols
- Home, Signal, Chart, AI Lab and Chat all rescaled for iPhone
- Chat keyboard dismissal and more readable bubbles/chips/composer
- AI Lab changed from cramped three-column micro cards to readable native rows
- Interactive native candlestick chart:
  - pinch to zoom
  - drag horizontally to pan
  - tap a candle for OHLC crosshair
  - right-side price scale
  - latest-price guide
  - FIT reset
  - persistent support/resistance/zone drawings
- Both Chart modes now work: Agent Chart and Clean View
- No live market feed or trained AI is claimed in this build

Bundle ID remains `com.zk.goldai.native` so SideStore updates the existing app.
