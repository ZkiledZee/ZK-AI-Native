import SwiftUI

struct HomeLogo: View {
    @Environment(\.zkScale) private var scale
    @State private var pulseA = false
    @State private var pulseB = false
    @State private var float = false

    var body: some View {
        ZStack {
            Circle()
                .stroke(ZKTheme.goldLogo.opacity(0.18), lineWidth: 1)
                .frame(width: 112 * scale, height: 112 * scale)
                .scaleEffect(pulseA ? 1.08 : 0.78)
                .opacity(pulseA ? 0 : 0.45)

            Circle()
                .stroke(ZKTheme.purple.opacity(0.20), lineWidth: 1)
                .frame(width: 124 * scale, height: 124 * scale)
                .scaleEffect(pulseB ? 1.08 : 0.78)
                .opacity(pulseB ? 0 : 0.35)

            Image("ZKBrandIcon")
                .resizable()
                .scaledToFit()
                .frame(width: 88 * scale, height: 88 * scale)
                .clipShape(RoundedRectangle(cornerRadius: 21 * scale, style: .continuous))
                .shadow(color: ZKTheme.goldLogo.opacity(0.18), radius: 16)
        }
        .frame(width: 128 * scale, height: 128 * scale)
        .offset(y: float ? -2 : 2)
        .onAppear {
            withAnimation(.easeOut(duration: 3).repeatForever(autoreverses: false)) { pulseA = true }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.4) {
                withAnimation(.easeOut(duration: 3).repeatForever(autoreverses: false)) { pulseB = true }
            }
            withAnimation(.easeInOut(duration: 4).repeatForever(autoreverses: true)) { float = true }
        }
    }
}

struct HomeActionButton: View {
    @Environment(\.zkScale) private var scale
    let icon: String
    let title: String
    let subtitle: String
    var primary: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 12 * scale) {
                Image(systemName: icon)
                    .font(.system(size: 18 * scale, weight: .bold))
                    .foregroundStyle(Color(red: 0.82, green: 0.47, blue: 0.90))
                    .frame(width: 46 * scale, height: 46 * scale)
                    .background(Color(red: 0.086, green: 0.059, blue: 0.106))
                    .overlay(RoundedRectangle(cornerRadius: 14 * scale).stroke(Color(red: 0.286, green: 0.196, blue: 0.322)))
                    .clipShape(RoundedRectangle(cornerRadius: 14 * scale))

                VStack(alignment: .leading, spacing: 4 * scale) {
                    Text(title)
                        .font(.system(size: 16 * scale, weight: .bold))
                        .foregroundStyle(.white)
                    Text(subtitle)
                        .font(.system(size: 11 * scale, weight: .medium))
                        .foregroundStyle(ZKTheme.textMuted)
                        .lineLimit(2)
                        .fixedSize(horizontal: false, vertical: true)
                }

                Spacer(minLength: 4)
                Image(systemName: "chevron.right")
                    .font(.system(size: 14 * scale, weight: .bold))
                    .foregroundStyle(Color(red: 0.68, green: 0.46, blue: 0.73))
            }
            .padding(.horizontal, 14 * scale)
            .padding(.vertical, 12 * scale)
            .background(
                LinearGradient(
                    colors: [Color(red: 0.055, green: 0.039, blue: 0.071), Color(red: 0.031, green: 0.024, blue: 0.043)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .overlay(RoundedRectangle(cornerRadius: 20 * scale).stroke(primary ? ZKTheme.borderStrong : ZKTheme.border, lineWidth: 1))
            .clipShape(RoundedRectangle(cornerRadius: 20 * scale))
        }
        .buttonStyle(ZKPressStyle())
    }
}

struct BottomNav: View {
    @EnvironmentObject private var state: AppState
    @Environment(\.zkScale) private var scale

    var body: some View {
        HStack(spacing: 4 * scale) {
            ForEach(ZKPage.allCases) { item in
                Button {
                    state.go(item)
                } label: {
                    VStack(spacing: 4 * scale) {
                        Image(systemName: item.systemImage)
                            .font(.system(size: 16 * scale, weight: .semibold))
                        Text(item.title)
                            .font(.system(size: 9 * scale, weight: .bold, design: .rounded))
                    }
                    .foregroundStyle(state.page == item ? Color(red: 0.84, green: 0.48, blue: 0.91) : Color(red: 0.53, green: 0.49, blue: 0.56))
                    .frame(maxWidth: .infinity, minHeight: 54 * scale)
                    .background(state.page == item ? ZKTheme.purple.opacity(0.09) : .clear)
                    .clipShape(RoundedRectangle(cornerRadius: 14 * scale))
                }
                .buttonStyle(ZKPressStyle())
                .accessibilityLabel(item.title)
            }
        }
        .padding(.horizontal, 8 * scale)
        .padding(.top, 6 * scale)
        .padding(.bottom, 2 * scale)
        .background(.ultraThinMaterial.opacity(0.92))
        .background(ZKTheme.navBackground.opacity(0.96))
        .overlay(alignment: .top) {
            Rectangle().fill(ZKTheme.border.opacity(0.65)).frame(height: 1)
        }
    }
}

struct MetricCell: View {
    @Environment(\.zkScale) private var scale
    let label: String
    let value: String
    var color: Color = .white

    var body: some View {
        VStack(spacing: 4 * scale) {
            Text(label.uppercased())
                .font(.system(size: 8 * scale, weight: .black, design: .rounded))
                .foregroundStyle(ZKTheme.textMuted)
            Text(value)
                .font(.system(size: 11 * scale, weight: .black, design: .monospaced))
                .foregroundStyle(color)
                .lineLimit(1)
                .minimumScaleFactor(0.75)
        }
        .frame(maxWidth: .infinity)
    }
}

struct ProbabilityCell: View {
    @Environment(\.zkScale) private var scale
    let label: String
    let value: Double
    let color: Color

    var body: some View {
        VStack(spacing: 3 * scale) {
            Text(label)
                .font(.system(size: 8 * scale, weight: .black))
                .foregroundStyle(ZKTheme.textMuted)
            Text("\(Int(value * 100))%")
                .font(.system(size: 13 * scale, weight: .black, design: .monospaced))
                .foregroundStyle(color)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 8 * scale)
        .background(Color.black.opacity(0.22))
        .overlay(RoundedRectangle(cornerRadius: 10 * scale).stroke(ZKTheme.border.opacity(0.85)))
        .clipShape(RoundedRectangle(cornerRadius: 10 * scale))
    }
}

struct SignalOrb: View {
    @Environment(\.zkScale) private var scale
    let color: Color
    @State private var pulse1 = false
    @State private var pulse2 = false

    var body: some View {
        ZStack {
            Circle().stroke(color.opacity(0.50), lineWidth: 1).frame(width: 46 * scale, height: 46 * scale).scaleEffect(pulse1 ? 1.18 : 0.65).opacity(pulse1 ? 0 : 0.55)
            Circle().stroke(color.opacity(0.25), lineWidth: 1).frame(width: 56 * scale, height: 56 * scale).scaleEffect(pulse2 ? 1.18 : 0.65).opacity(pulse2 ? 0 : 0.35)
            Circle().fill(color).frame(width: 18 * scale, height: 18 * scale).shadow(color: color.opacity(0.9), radius: 10)
        }
        .frame(width: 58 * scale, height: 58 * scale)
        .onAppear {
            withAnimation(.easeOut(duration: 2.4).repeatForever(autoreverses: false)) { pulse1 = true }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.15) {
                withAnimation(.easeOut(duration: 2.4).repeatForever(autoreverses: false)) { pulse2 = true }
            }
        }
    }
}

struct ConfidenceRing: View {
    @Environment(\.zkScale) private var scale
    let value: Double
    let color: Color
    let label: String

    var body: some View {
        ZStack {
            Circle().stroke(Color(red: 0.145, green: 0.110, blue: 0.169), lineWidth: 7 * scale)
            Circle()
                .trim(from: 0, to: max(0, min(value, 1)))
                .stroke(color, style: StrokeStyle(lineWidth: 7 * scale, lineCap: .round))
                .rotationEffect(.degrees(-90))
                .shadow(color: color.opacity(0.18), radius: 8)
            VStack(spacing: 1) {
                Text("\(Int(value * 100))%")
                    .font(.system(size: 12 * scale, weight: .black))
                Text(label.uppercased())
                    .font(.system(size: 7 * scale, weight: .black))
                    .foregroundStyle(ZKTheme.textMuted)
            }
        }
        .frame(width: 64 * scale, height: 64 * scale)
    }
}
