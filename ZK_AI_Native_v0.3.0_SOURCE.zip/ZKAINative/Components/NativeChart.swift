import SwiftUI

struct NativeAgentChart: View {
    @Environment(\.zkScale) private var scale
    let candles: [ChartCandle]
    let drawings: [ChartDrawing]

    @State private var visibleCount = 34
    @State private var panOffset = 0
    @State private var pinchBaseCount: Int?
    @State private var selectedIndex: Int?

    var body: some View {
        GeometryReader { geo in
            let layout = makeLayout(size: geo.size)

            ZStack(alignment: .topTrailing) {
                Canvas { context, size in
                    drawGrid(context: context, layout: layout)
                    drawCandles(context: context, layout: layout)
                    drawDrawings(context: context, layout: layout)
                    drawLatestPrice(context: context, layout: layout)
                    drawSelection(context: context, layout: layout)
                    drawAxes(context: context, layout: layout)
                }
                .contentShape(Rectangle())
                .gesture(panGesture(step: layout.step))
                .simultaneousGesture(zoomGesture)
                .simultaneousGesture(tapGesture(layout: layout))

                HStack(spacing: 6 * scale) {
                    if let selected = selectedCandle(in: layout.visible) {
                        Text(String(format: "#%d  O %.2f  H %.2f  L %.2f  C %.2f", selected.index, selected.open, selected.high, selected.low, selected.close))
                            .font(.system(size: 8 * scale, weight: .semibold, design: .monospaced))
                            .foregroundStyle(.white.opacity(0.86))
                            .padding(.horizontal, 8 * scale)
                            .frame(height: 25 * scale)
                            .background(ZKTheme.navBackground.opacity(0.92))
                            .overlay(Capsule().stroke(ZKTheme.border.opacity(0.8)))
                            .clipShape(Capsule())
                            .lineLimit(1)
                            .minimumScaleFactor(0.75)
                    }

                    Button("FIT") {
                        visibleCount = min(34, max(candles.count, 16))
                        panOffset = 0
                        selectedIndex = nil
                    }
                    .font(.system(size: 8 * scale, weight: .black))
                    .foregroundStyle(Color(red: 0.84, green: 0.48, blue: 0.91))
                    .padding(.horizontal, 8 * scale)
                    .frame(height: 25 * scale)
                    .background(ZKTheme.card.opacity(0.92))
                    .overlay(Capsule().stroke(ZKTheme.borderStrong))
                    .clipShape(Capsule())
                    .buttonStyle(ZKPressStyle())
                }
                .padding(7 * scale)
            }
        }
        .accessibilityLabel("Interactive XAUUSD candlestick chart")
        .accessibilityHint("Pinch to zoom, drag to move through candles, and tap a candle to inspect OHLC values")
    }

    private struct Layout {
        let size: CGSize
        let visible: [ChartCandle]
        let start: Int
        let chartWidth: CGFloat
        let top: CGFloat
        let bottom: CGFloat
        let high: Double
        let low: Double
        let span: Double
        let step: CGFloat
        let candleWidth: CGFloat

        func x(for localIndex: Int) -> CGFloat {
            (CGFloat(localIndex) + 0.5) * step
        }

        func y(_ value: Double) -> CGFloat {
            top + CGFloat((high - value) / span) * (size.height - top - bottom)
        }
    }

    private func makeLayout(size: CGSize) -> Layout {
        let total = candles.count
        let count = min(max(visibleCount, 16), max(total, 16))
        let maxOffset = max(0, total - min(count, total))
        let offset = min(max(panOffset, 0), maxOffset)
        let end = max(0, total - offset)
        let start = max(0, end - min(count, total))
        let visible = start < end ? Array(candles[start..<end]) : candles

        var allPrices = visible.flatMap { [$0.high, $0.low] }
        for d in drawings {
            allPrices.append(d.price)
            if let p = d.secondaryPrice { allPrices.append(p) }
        }

        let rawHigh = allPrices.max() ?? 1
        let rawLow = allPrices.min() ?? 0
        let rawSpan = max(rawHigh - rawLow, 0.001)
        let high = rawHigh + rawSpan * 0.08
        let low = rawLow - rawSpan * 0.08
        let span = max(high - low, 0.001)
        let chartWidth = max(size.width - (49 * scale), 60)
        let step = chartWidth / CGFloat(max(visible.count, 1))
        let candleWidth = min(max(step * 0.58, 2.2), 11 * scale)

        return Layout(size: size, visible: visible, start: start, chartWidth: chartWidth, top: 18 * scale, bottom: 20 * scale, high: high, low: low, span: span, step: step, candleWidth: candleWidth)
    }

    private func drawGrid(context: GraphicsContext, layout: Layout) {
        for row in 0...5 {
            let y = layout.top + (layout.size.height - layout.top - layout.bottom) * CGFloat(row) / 5
            var path = Path()
            path.move(to: CGPoint(x: 0, y: y))
            path.addLine(to: CGPoint(x: layout.chartWidth, y: y))
            context.stroke(path, with: .color(ZKTheme.border.opacity(0.38)), lineWidth: 0.6)
        }

        for col in 0...4 {
            let x = layout.chartWidth * CGFloat(col) / 4
            var path = Path()
            path.move(to: CGPoint(x: x, y: layout.top))
            path.addLine(to: CGPoint(x: x, y: layout.size.height - layout.bottom))
            context.stroke(path, with: .color(ZKTheme.border.opacity(0.18)), lineWidth: 0.5)
        }
    }

    private func drawCandles(context: GraphicsContext, layout: Layout) {
        for (i, c) in layout.visible.enumerated() {
            let x = layout.x(for: i)
            let color = c.isUp ? ZKTheme.green : ZKTheme.red

            var wick = Path()
            wick.move(to: CGPoint(x: x, y: layout.y(c.high)))
            wick.addLine(to: CGPoint(x: x, y: layout.y(c.low)))
            context.stroke(wick, with: .color(color.opacity(0.95)), lineWidth: max(1, scale))

            let top = min(layout.y(c.open), layout.y(c.close))
            let bottom = max(layout.y(c.open), layout.y(c.close))
            let rect = CGRect(x: x - layout.candleWidth / 2, y: top, width: layout.candleWidth, height: max(2 * scale, bottom - top))
            context.fill(Path(roundedRect: rect, cornerRadius: 1.0 * scale), with: .color(color))
        }
    }

    private func drawDrawings(context: GraphicsContext, layout: Layout) {
        for drawing in drawings {
            guard drawing.price >= layout.low && drawing.price <= layout.high else { continue }
            let y1 = layout.y(drawing.price)
            let color = color(for: drawing.kind)

            if drawing.kind == .zone, let second = drawing.secondaryPrice {
                let y2 = layout.y(second)
                let rect = CGRect(x: 0, y: min(y1, y2), width: layout.chartWidth, height: abs(y2 - y1))
                context.fill(Path(rect), with: .color(color.opacity(0.08)))
                context.stroke(Path(rect), with: .color(color.opacity(0.55)), lineWidth: 0.9)
            } else {
                var path = Path()
                path.move(to: CGPoint(x: 0, y: y1))
                path.addLine(to: CGPoint(x: layout.chartWidth, y: y1))
                context.stroke(path, with: .color(color.opacity(0.92)), style: StrokeStyle(lineWidth: 1, dash: [5, 4]))
            }

            let label = Text(drawing.label)
                .font(.system(size: 7 * scale, weight: .black))
                .foregroundColor(color)
            context.draw(label, at: CGPoint(x: layout.chartWidth - 4, y: y1 - 7 * scale), anchor: .trailing)
        }
    }

    private func drawLatestPrice(context: GraphicsContext, layout: Layout) {
        guard let latest = layout.visible.last else { return }
        let y = layout.y(latest.close)
        let color = latest.isUp ? ZKTheme.green : ZKTheme.red
        var line = Path()
        line.move(to: CGPoint(x: 0, y: y))
        line.addLine(to: CGPoint(x: layout.chartWidth, y: y))
        context.stroke(line, with: .color(color.opacity(0.30)), style: StrokeStyle(lineWidth: 0.8, dash: [2, 3]))
    }

    private func drawSelection(context: GraphicsContext, layout: Layout) {
        guard let selectedIndex,
              let local = layout.visible.firstIndex(where: { $0.index == selectedIndex }) else { return }
        let c = layout.visible[local]
        let x = layout.x(for: local)
        let y = layout.y(c.close)

        var vertical = Path()
        vertical.move(to: CGPoint(x: x, y: layout.top))
        vertical.addLine(to: CGPoint(x: x, y: layout.size.height - layout.bottom))
        context.stroke(vertical, with: .color(.white.opacity(0.25)), style: StrokeStyle(lineWidth: 0.7, dash: [3, 3]))

        var horizontal = Path()
        horizontal.move(to: CGPoint(x: 0, y: y))
        horizontal.addLine(to: CGPoint(x: layout.chartWidth, y: y))
        context.stroke(horizontal, with: .color(.white.opacity(0.22)), style: StrokeStyle(lineWidth: 0.7, dash: [3, 3]))

        context.fill(Path(ellipseIn: CGRect(x: x - 3 * scale, y: y - 3 * scale, width: 6 * scale, height: 6 * scale)), with: .color(.white))
    }

    private func drawAxes(context: GraphicsContext, layout: Layout) {
        for row in 0...5 {
            let fraction = Double(row) / 5.0
            let price = layout.high - layout.span * fraction
            let y = layout.top + (layout.size.height - layout.top - layout.bottom) * CGFloat(row) / 5
            let text = Text(String(format: "%.2f", price))
                .font(.system(size: 7.5 * scale, weight: .semibold, design: .monospaced))
                .foregroundColor(ZKTheme.textMuted)
            context.draw(text, at: CGPoint(x: layout.size.width - 2, y: y), anchor: .trailing)
        }

        if let first = layout.visible.first, let last = layout.visible.last {
            let left = Text("#\(first.index)").font(.system(size: 7 * scale, weight: .medium, design: .monospaced)).foregroundColor(ZKTheme.textMuted)
            let right = Text("#\(last.index)").font(.system(size: 7 * scale, weight: .medium, design: .monospaced)).foregroundColor(ZKTheme.textMuted)
            context.draw(left, at: CGPoint(x: 2, y: layout.size.height - 3), anchor: .bottomLeading)
            context.draw(right, at: CGPoint(x: layout.chartWidth - 2, y: layout.size.height - 3), anchor: .bottomTrailing)
        }
    }

    private func selectedCandle(in visible: [ChartCandle]) -> ChartCandle? {
        guard let selectedIndex else { return nil }
        return visible.first(where: { $0.index == selectedIndex })
    }

    private func panGesture(step: CGFloat) -> some Gesture {
        DragGesture(minimumDistance: 8)
            .onEnded { value in
                guard step > 0 else { return }
                let candlesMoved = Int((value.translation.width / step).rounded())
                let maxOffset = max(0, candles.count - min(visibleCount, candles.count))
                panOffset = min(max(panOffset + candlesMoved, 0), maxOffset)
                selectedIndex = nil
            }
    }

    private var zoomGesture: some Gesture {
        MagnificationGesture()
            .onChanged { value in
                if pinchBaseCount == nil { pinchBaseCount = visibleCount }
                guard let base = pinchBaseCount else { return }
                let maxCount = max(16, min(72, candles.count))
                let next = Int((CGFloat(base) / max(value, 0.25)).rounded())
                visibleCount = min(max(next, 16), maxCount)
                panOffset = min(panOffset, max(0, candles.count - min(visibleCount, candles.count)))
            }
            .onEnded { _ in pinchBaseCount = nil }
    }

    private func tapGesture(layout: Layout) -> some Gesture {
        SpatialTapGesture()
            .onEnded { value in
                guard value.location.x >= 0, value.location.x <= layout.chartWidth, !layout.visible.isEmpty else { return }
                let local = min(max(Int(value.location.x / max(layout.step, 1)), 0), layout.visible.count - 1)
                selectedIndex = layout.visible[local].index
            }
    }

    private func color(for kind: DrawingKind) -> Color {
        switch kind {
        case .support: return ZKTheme.green
        case .resistance: return ZKTheme.red
        case .zone: return ZKTheme.purple
        case .entry: return ZKTheme.blue
        case .stopLoss: return ZKTheme.red
        case .takeProfit: return ZKTheme.green
        case .note: return ZKTheme.gold
        }
    }
}
