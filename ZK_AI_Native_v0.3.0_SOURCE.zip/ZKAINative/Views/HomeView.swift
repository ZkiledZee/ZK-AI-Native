import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var state: AppState
    @Environment(\.zkScale) private var scale
    @State private var drift = false

    var body: some View {
        ZStack {
            ambient

            VStack(spacing: 13 * scale) {
                Spacer(minLength: 8 * scale)

                VStack(spacing: 6 * scale) {
                    HomeLogo()

                    ZKMicroLabel(text: "XAUUSD • NATIVE AI")

                    Text("AI Scalper")
                        .font(.system(size: 39 * scale, weight: .black, design: .rounded))
                        .tracking(-1.6 * scale)
                        .foregroundStyle(
                            LinearGradient(
                                colors: [.white, Color(red: 0.843, green: 0.788, blue: 0.867), Color(red: 0.655, green: 0.416, blue: 0.741)],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .lineLimit(1)
                        .minimumScaleFactor(0.86)

                    Text("Learn the market. Test it. Then predict.")
                        .font(.system(size: 13 * scale, weight: .medium))
                        .foregroundStyle(ZKTheme.textMuted)

                    ZKDataPill(text: "NATIVE FOUNDATION", color: ZKTheme.green)
                        .padding(.top, 2 * scale)
                }

                VStack(spacing: 10 * scale) {
                    HomeActionButton(
                        icon: "diamond.fill",
                        title: "AI Signal",
                        subtitle: "Probability → ideal entry → structure SL / 2R+ TP",
                        primary: true
                    ) { state.go(.signal) }

                    HomeActionButton(
                        icon: "sparkles",
                        title: "AI Lab",
                        subtitle: "Model Vault, Macro AI, diagnostics and evidence"
                    ) { state.go(.lab) }

                    HomeActionButton(
                        icon: "bubble.left.and.bubble.right.fill",
                        title: "Talk to ZK AI",
                        subtitle: "Explain model state and manage chart drawings"
                    ) { state.go(.chat) }
                }

                Spacer(minLength: 8 * scale)
            }
            .padding(.horizontal, 16 * scale)
            .padding(.top, 4 * scale)
        }
        .background(ZKTheme.background)
    }

    private var ambient: some View {
        ZStack {
            Circle()
                .fill(ZKTheme.purple.opacity(0.11))
                .frame(width: 260 * scale, height: 260 * scale)
                .blur(radius: 32)
                .offset(x: drift ? -75 : -145, y: drift ? -180 : -235)

            Circle()
                .fill(ZKTheme.pink.opacity(0.06))
                .frame(width: 240 * scale, height: 240 * scale)
                .blur(radius: 32)
                .offset(x: drift ? 115 : 175, y: drift ? 260 : 310)

            ForEach(0..<6, id: \.self) { i in
                Circle()
                    .fill(ZKTheme.purple.opacity(0.25))
                    .frame(width: 3, height: 3)
                    .shadow(color: ZKTheme.purple, radius: 4)
                    .offset(
                        x: CGFloat([-130, 110, 150, -85, 15, 80][i]) * scale,
                        y: (CGFloat([180, 210, -70, -20, 270, -180][i]) + (drift ? -35 : 30)) * scale
                    )
            }
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 9).repeatForever(autoreverses: true)) { drift = true }
        }
    }
}
