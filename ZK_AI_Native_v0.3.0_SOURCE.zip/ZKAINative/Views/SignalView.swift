import SwiftUI

struct SignalView: View {
    @EnvironmentObject private var state: AppState
    @Environment(\.zkScale) private var scale
    @StateObject private var notifications = NotificationManager.shared

    private let demoCandles: [ChartCandle] = {
        var result: [ChartCandle] = []
        var price = 4642.0
        for i in 0..<64 {
            let wave = sin(Double(i) * 0.48) * 0.9 + cos(Double(i) * 0.19) * 0.4
            let open = price
            let close = open + wave * 0.27 + (i > 34 ? 0.12 : -0.02)
            let high = max(open, close) + 0.35 + abs(sin(Double(i))) * 0.28
            let low = min(open, close) - 0.32 - abs(cos(Double(i) * 0.7)) * 0.25
            result.append(.init(index: i, open: open, high: high, low: low, close: close))
            price = close
        }
        return result
    }()

    var body: some View {
        VStack(spacing: 8 * scale) {
            ZKPageHeader(micro: "AI SIGNAL • 1M", title: "Live model", pill: "NO FEED", pillColor: ZKTheme.gold)
            modelStrip
            macroStrip
            signalCore
            chart.frame(maxHeight: .infinity)
            levels
            lifecycle
        }
        .padding(.horizontal, 16 * scale)
        .padding(.top, 8 * scale)
        .padding(.bottom, 8 * scale)
        .background(ZKTheme.background)
        .task { state.notificationPermission = await notifications.refresh() }
    }

    private var modelStrip: some View {
        HStack {
            VStack(alignment: .leading, spacing: 3 * scale) {
                Text("ACTIVE MODEL").font(.system(size: 8 * scale, weight: .black)).tracking(0.8).foregroundStyle(ZKTheme.textMuted)
                Text(state.selectedModel?.name ?? "UNTRAINED").font(.system(size: 12 * scale, weight: .bold)).lineLimit(1)
            }
            Spacer()
            Text(state.selectedModel?.evidence ?? "EXPERIMENTAL")
                .font(.system(size: 8 * scale, weight: .black)).tracking(0.5)
                .foregroundStyle(Color(red: 0.831, green: 0.580, blue: 0.898))
                .padding(.horizontal, 9 * scale).padding(.vertical, 6 * scale)
                .background(Color(red: 0.086, green: 0.051, blue: 0.110))
                .overlay(Capsule().stroke(ZKTheme.borderStrong)).clipShape(Capsule())
        }
        .padding(.horizontal, 11 * scale).padding(.vertical, 9 * scale)
        .background(LinearGradient(colors: [Color(red: 0.063, green: 0.043, blue: 0.078), Color(red: 0.031, green: 0.024, blue: 0.043)], startPoint: .topLeading, endPoint: .bottomTrailing))
        .overlay(RoundedRectangle(cornerRadius: 14 * scale).stroke(ZKTheme.borderStrong)).clipShape(RoundedRectangle(cornerRadius: 14 * scale))
    }

    private var macroStrip: some View {
        HStack(spacing: 5 * scale) {
            stripCell("GOLD REGIME", state.macroRegime)
            stripCell("USD", "—")
            stripCell("YIELDS", "—")
            stripCell("COT", "—")
        }
    }

    private func stripCell(_ title: String, _ value: String) -> some View {
        VStack(spacing: 3 * scale) {
            Text(title).font(.system(size: 7 * scale, weight: .black)).foregroundStyle(ZKTheme.textMuted).lineLimit(1).minimumScaleFactor(0.7)
            Text(value).font(.system(size: 9 * scale, weight: .black)).foregroundStyle(.white.opacity(0.88)).lineLimit(1).minimumScaleFactor(0.65)
        }
        .frame(maxWidth: .infinity).padding(.vertical, 7 * scale)
        .background(Color(red: 0.035, green: 0.027, blue: 0.051))
        .overlay(RoundedRectangle(cornerRadius: 10 * scale).stroke(ZKTheme.border.opacity(0.85))).clipShape(RoundedRectangle(cornerRadius: 10 * scale))
    }

    private var signalCore: some View {
        let sideColor: Color = state.signal.side == .buy ? ZKTheme.green : (state.signal.side == .sell ? ZKTheme.red : ZKTheme.gold)
        return VStack(spacing: 8 * scale) {
            HStack(alignment: .top) {
                HStack(spacing: 10 * scale) {
                    SignalOrb(color: sideColor)
                    VStack(alignment: .leading, spacing: 4 * scale) {
                        Text("AI BIAS").font(.system(size: 8 * scale, weight: .black)).tracking(0.8).foregroundStyle(ZKTheme.textSoft)
                        Text(state.signal.side.rawValue).font(.system(size: 27 * scale, weight: .black, design: .rounded)).tracking(-0.8).foregroundStyle(sideColor)
                        ZKDataPill(text: "LEARNING MODE", color: sideColor)
                    }
                }
                Spacer()
                VStack(spacing: 4 * scale) {
                    ConfidenceRing(value: state.signal.executionConfidence, color: sideColor, label: "EXEC")
                    Text("UNTRAINED").font(.system(size: 7 * scale, weight: .bold)).foregroundStyle(ZKTheme.textSoft)
                }
            }

            HStack(spacing: 6 * scale) {
                ProbabilityCell(label: "BUY", value: state.signal.buyProbability, color: ZKTheme.green)
                ProbabilityCell(label: "WAIT", value: state.signal.waitProbability, color: ZKTheme.gold)
                ProbabilityCell(label: "SELL", value: state.signal.sellProbability, color: ZKTheme.red)
            }

            HStack(spacing: 5 * scale) {
                confidenceMini("DIRECTIONAL", state.signal.directionalConfidence)
                confidenceMini("WAIT", state.signal.waitProbability)
                confidenceMini("EXECUTION", state.signal.executionConfidence)
            }

            Text(state.signal.reason)
                .font(.system(size: 10 * scale, weight: .medium))
                .foregroundStyle(ZKTheme.textMuted)
                .frame(maxWidth: .infinity, alignment: .leading)
                .lineLimit(2)
        }
        .padding(12 * scale)
        .background(RadialGradient(colors: [sideColor.opacity(0.10), Color(red: 0.051, green: 0.035, blue: 0.067)], center: .topTrailing, startRadius: 0, endRadius: 180))
        .overlay(RoundedRectangle(cornerRadius: 18 * scale).stroke(sideColor.opacity(0.26))).clipShape(RoundedRectangle(cornerRadius: 18 * scale))
    }

    private func confidenceMini(_ title: String, _ value: Double) -> some View {
        VStack(spacing: 2 * scale) {
            Text(title).font(.system(size: 7 * scale, weight: .black)).foregroundStyle(ZKTheme.textMuted)
            Text("\(Int(value * 100))%").font(.system(size: 10 * scale, weight: .black, design: .monospaced))
        }.frame(maxWidth: .infinity)
    }

    private var chart: some View {
        ZStack(alignment: .top) {
            NativeAgentChart(candles: demoCandles, drawings: state.drawings).padding(.top, 31 * scale)
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 2 * scale) {
                    Text("XAUUSD").font(.system(size: 12 * scale, weight: .black))
                    Text("Demo candles • pinch / drag / tap enabled").font(.system(size: 8 * scale)).foregroundStyle(ZKTheme.textMuted)
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 2 * scale) {
                    Text("SOURCE").font(.system(size: 7 * scale, weight: .black)).foregroundStyle(ZKTheme.textMuted)
                    Text("DEMO").font(.system(size: 11 * scale, weight: .black))
                }
            }.padding(10 * scale)
        }
        .frame(minHeight: 180 * scale)
        .background(RadialGradient(colors: [ZKTheme.purple.opacity(0.07), Color(red: 0.031, green: 0.024, blue: 0.043)], center: .topTrailing, startRadius: 0, endRadius: 220))
        .overlay(RoundedRectangle(cornerRadius: 18 * scale).stroke(ZKTheme.borderStrong)).clipShape(RoundedRectangle(cornerRadius: 18 * scale))
    }

    private var levels: some View {
        HStack(spacing: 5 * scale) {
            level("VALID AT", state.signal.entry)
            level("SL", state.signal.stopLoss)
            level("TP", state.signal.takeProfit)
            levelText("R:R", state.signal.riskReward.map { String(format: "%.1fR", $0) } ?? "—", Color(red: 0.831, green: 0.478, blue: 0.894))
        }
    }

    private func level(_ title: String, _ value: Double?) -> some View { levelText(title, value.map { String(format: "%.2f", $0) } ?? "HIDDEN", .white.opacity(0.90)) }

    private func levelText(_ title: String, _ text: String, _ color: Color) -> some View {
        VStack(spacing: 3 * scale) {
            Text(title).font(.system(size: 7 * scale, weight: .black)).foregroundStyle(ZKTheme.textMuted)
            Text(text).font(.system(size: 9 * scale, weight: .black, design: .monospaced)).foregroundStyle(color).minimumScaleFactor(0.65).lineLimit(1)
        }
        .frame(maxWidth: .infinity).padding(.vertical, 8 * scale)
        .background(Color(red: 0.035, green: 0.027, blue: 0.051))
        .overlay(RoundedRectangle(cornerRadius: 11 * scale).stroke(ZKTheme.border)).clipShape(RoundedRectangle(cornerRadius: 11 * scale))
    }

    private var lifecycle: some View {
        HStack(spacing: 7 * scale) {
            Circle().fill(ZKTheme.gold).frame(width: 7 * scale, height: 7 * scale)
            Text(state.signal.lifecycle).font(.system(size: 8 * scale, weight: .black)).foregroundStyle(.white.opacity(0.86))
            Spacer()
            Button {
                Task {
                    if !state.notificationPermission { state.notificationPermission = await notifications.request() }
                    if state.notificationPermission { await notifications.sendDemo() }
                }
            } label: {
                Text(state.notificationPermission ? "TEST ALERT" : "ENABLE ALERTS")
                    .font(.system(size: 8 * scale, weight: .black)).foregroundStyle(Color(red: 0.831, green: 0.478, blue: 0.894))
            }.buttonStyle(ZKPressStyle())
        }
        .padding(.horizontal, 10 * scale).frame(height: 34 * scale)
        .background(Color(red: 0.035, green: 0.027, blue: 0.051))
        .overlay(RoundedRectangle(cornerRadius: 10 * scale).stroke(ZKTheme.border)).clipShape(RoundedRectangle(cornerRadius: 10 * scale))
    }
}
