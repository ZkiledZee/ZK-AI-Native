import SwiftUI

struct ChartView: View {
    @EnvironmentObject private var state: AppState
    @Environment(\.zkScale) private var scale

    private let candles: [ChartCandle] = {
        var result: [ChartCandle] = []
        var price = 4638.0
        for i in 0..<96 {
            let impulse = sin(Double(i) * 0.43) * 1.1 + cos(Double(i) * 0.16) * 0.5
            let open = price
            let close = open + impulse * 0.29 + (i > 52 ? 0.15 : 0.02)
            let high = max(open, close) + 0.38 + abs(sin(Double(i) * 0.78)) * 0.32
            let low = min(open, close) - 0.34 - abs(cos(Double(i) * 0.65)) * 0.27
            result.append(.init(index: i, open: open, high: high, low: low, close: close))
            price = close
        }
        return result
    }()

    var body: some View {
        VStack(spacing: 8 * scale) {
            ZKPageHeader(micro: "AI + NATIVE CHART", title: "XAUUSD • 1M", pill: "DEMO", pillColor: ZKTheme.gold)
            modeTabs
            if state.chartMode == 0 { agentChart } else { referenceChart }
        }
        .padding(.horizontal, 16 * scale).padding(.top, 8 * scale).padding(.bottom, 8 * scale)
        .background(ZKTheme.background)
    }

    private var modeTabs: some View {
        HStack(spacing: 6 * scale) { tab("AGENT CHART", 0); tab("CLEAN VIEW", 1) }
    }

    private func tab(_ title: String, _ index: Int) -> some View {
        Button { state.chartMode = index } label: {
            Text(title).font(.system(size: 9 * scale, weight: .black)).tracking(0.5)
                .foregroundStyle(state.chartMode == index ? .white : ZKTheme.textMuted)
                .frame(maxWidth: .infinity, minHeight: 38 * scale)
                .background(state.chartMode == index ? Color(red: 0.086, green: 0.051, blue: 0.110) : ZKTheme.card)
                .overlay(RoundedRectangle(cornerRadius: 11 * scale).stroke(state.chartMode == index ? ZKTheme.borderStrong : ZKTheme.border))
                .clipShape(RoundedRectangle(cornerRadius: 11 * scale))
        }.buttonStyle(ZKPressStyle())
    }

    private var agentChart: some View {
        VStack(spacing: 0) {
            chartHeader(title: "AI-READABLE CHART", subtitle: "Pinch to zoom • drag to pan • tap candle", trailing: "\(state.drawings.count) DRAWINGS")
            NativeAgentChart(candles: candles, drawings: state.drawings).frame(maxWidth: .infinity, maxHeight: .infinity).padding(.vertical, 4 * scale)
            drawingToolbar
            footer("Drawing state is persistent and shared with the ZK AI shell. Live broker candles will replace demo data later.")
        }
        .frame(maxHeight: .infinity).background(Color(red: 0.031, green: 0.024, blue: 0.043))
        .overlay(RoundedRectangle(cornerRadius: 18 * scale).stroke(ZKTheme.border)).clipShape(RoundedRectangle(cornerRadius: 18 * scale))
    }

    private var referenceChart: some View {
        VStack(spacing: 0) {
            chartHeader(title: "CLEAN REFERENCE", subtitle: "Same native candle engine • drawings hidden", trailing: "INTERACTIVE")
            NativeAgentChart(candles: candles, drawings: []).frame(maxWidth: .infinity, maxHeight: .infinity).padding(.vertical, 4 * scale)
            footer("This clean view uses the same chart engine and gestures without agent drawings.")
        }
        .frame(maxHeight: .infinity).background(Color(red: 0.031, green: 0.024, blue: 0.043))
        .overlay(RoundedRectangle(cornerRadius: 18 * scale).stroke(ZKTheme.border)).clipShape(RoundedRectangle(cornerRadius: 18 * scale))
    }

    private func chartHeader(title: String, subtitle: String, trailing: String) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 3 * scale) {
                Text(title).font(.system(size: 8 * scale, weight: .black)).tracking(0.7).foregroundStyle(ZKTheme.textMuted)
                Text(subtitle).font(.system(size: 10 * scale, weight: .bold)).foregroundStyle(.white.opacity(0.9))
            }
            Spacer()
            Text(trailing).font(.system(size: 8 * scale, weight: .bold)).foregroundStyle(ZKTheme.textSoft)
        }
        .padding(.horizontal, 11 * scale).frame(height: 48 * scale).background(Color(red: 0.039, green: 0.027, blue: 0.063))
    }

    private var drawingToolbar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 6 * scale) {
                tool("S/R") { state.replaceSupportResistance() }
                tool("ZONE") { state.addDemoZone() }
                tool("UNDO") { state.removeLastDrawing() }
                tool("NO SUP") { state.removeSupport() }
                tool("NO RES") { state.removeResistance() }
                tool("CLEAR") { state.clearAllDrawings() }
            }.padding(.horizontal, 9 * scale)
        }
        .frame(height: 46 * scale).background(Color(red: 0.039, green: 0.027, blue: 0.063))
        .overlay(alignment: .top) { Rectangle().fill(ZKTheme.border.opacity(0.7)).frame(height: 1) }
    }

    private func tool(_ name: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(name).font(.system(size: 8 * scale, weight: .black)).foregroundStyle(Color(red: 0.831, green: 0.478, blue: 0.894))
                .padding(.horizontal, 10 * scale).frame(height: 30 * scale)
                .background(Color(red: 0.086, green: 0.051, blue: 0.110)).overlay(Capsule().stroke(ZKTheme.borderStrong)).clipShape(Capsule())
        }.buttonStyle(ZKPressStyle())
    }

    private func footer(_ text: String) -> some View {
        Text(text).font(.system(size: 8 * scale, weight: .medium)).foregroundStyle(Color(red: 0.46, green: 0.42, blue: 0.48))
            .multilineTextAlignment(.center).padding(.horizontal, 10 * scale).frame(minHeight: 34 * scale).background(ZKTheme.navBackground)
    }
}
