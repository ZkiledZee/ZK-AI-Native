import Foundation

enum ZKPage: Int, CaseIterable, Identifiable {
    case home, signal, chart, lab, chat
    var id: Int { rawValue }

    var title: String {
        switch self {
        case .home: return "Home"
        case .signal: return "Signal"
        case .chart: return "Chart"
        case .lab: return "AI Lab"
        case .chat: return "Chat"
        }
    }

    var systemImage: String {
        switch self {
        case .home: return "house.fill"
        case .signal: return "diamond.fill"
        case .chart: return "chart.xyaxis.line"
        case .lab: return "sparkles"
        case .chat: return "bubble.left.and.bubble.right.fill"
        }
    }
}

enum SignalSide: String, Codable { case buy = "BUY", wait = "WAIT", sell = "SELL" }

struct SignalSnapshot: Codable, Equatable {
    var side: SignalSide
    var buyProbability: Double
    var waitProbability: Double
    var sellProbability: Double
    var directionalConfidence: Double
    var executionConfidence: Double
    var entry: Double?
    var stopLoss: Double?
    var takeProfit: Double?
    var riskReward: Double?
    var lifecycle: String
    var reason: String

    static let disconnected = SignalSnapshot(
        side: .wait, buyProbability: 0, waitProbability: 1, sellProbability: 0,
        directionalConfidence: 0, executionConfidence: 0,
        entry: nil, stopLoss: nil, takeProfit: nil, riskReward: nil,
        lifecycle: "WAITING FOR DATA",
        reason: "Broker-quality XAUUSD data is not connected yet. ZK AI will not invent a live setup."
    )
}

struct ModelRecord: Identifiable, Codable, Equatable {
    var id: UUID
    var name: String
    var status: String
    var evidence: String
    var trainRange: String
    var unseenRange: String
    var resolvedTrades: Int
    var profitFactor: Double?
    var expectancyR: Double?
    var drawdownR: Double?
    var averageHold: String

    static let seed: [ModelRecord] = [
        .init(id: UUID(), name: "ZK Market AI v0", status: "ACTIVE", evidence: "EXPERIMENTAL", trainRange: "Not trained", unseenRange: "Not tested", resolvedTrades: 0, profitFactor: nil, expectancyR: nil, drawdownR: nil, averageHold: "—"),
        .init(id: UUID(), name: "Challenger slot", status: "CHALLENGER", evidence: "EMPTY", trainRange: "—", unseenRange: "—", resolvedTrades: 0, profitFactor: nil, expectancyR: nil, drawdownR: nil, averageHold: "—")
    ]
}

enum MacroState { case bullish, bearish, neutral, unavailable }

struct MacroItem: Identifiable {
    let id = UUID()
    let name: String
    let value: String
    let subtitle: String
    let state: MacroState
}

enum DrawingKind: String, Codable { case support, resistance, zone, entry, stopLoss, takeProfit, note }

struct ChartDrawing: Identifiable, Codable, Equatable {
    var id = UUID()
    var kind: DrawingKind
    var price: Double
    var secondaryPrice: Double?
    var label: String
}

struct TradeJournalEntry: Identifiable, Codable, Equatable {
    var id = UUID()
    var createdAt: Date
    var side: SignalSide
    var executionConfidence: Double
    var macroCoverage: Double
    var session: String
    var spread: Double?
    var outcome: String
}

struct ChartCandle: Identifiable {
    let id = UUID()
    let index: Int
    let open: Double
    let high: Double
    let low: Double
    let close: Double
    var isUp: Bool { close >= open }
}

struct ChatMessage: Identifiable, Equatable {
    enum Role { case user, assistant }
    let id = UUID()
    let role: Role
    let text: String
}
