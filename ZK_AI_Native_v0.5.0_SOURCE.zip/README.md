# ZK AI Native v0.5.0

Native iPhone polish / chart / navigation build before the AI stage.

## What changed

- Added a direct TradingView Advanced Chart widget configured for `ICMARKETS:XAUUSD` at 1 minute.
- Chart screen now defaults to **IC Markets TV** and can switch to **ZK Native**.
- Signal page can use the same IC Markets TradingView chart; Settings can switch it back to the native chart.
- The TradingView view is the visual source itself, so its visible candles/price action match the TradingView IC Markets chart. TradingView does not expose those bars to the native app data layer.
- The ZK native chart remains separate for future AI overlays and uses the XAUS reference feed until an authorised broker feed is connected.
- Rebuilt native chart panning to update continuously while the finger moves, plus optional momentum/inertial settling and smoother pinch zoom.
- Added native-chart Grid and Latest Price Line settings.
- Added a 7-tab iPhone navigation bar with **Signal fixed in the exact centre**.
- Signal uses a raised animated rotating/pulsing ZK diamond icon.
- Added **Backtest** tab with a real data-integrity check and no fake strategy results.
- Added **Settings** tab with:
  - default chart source
  - Signal chart source
  - native chart momentum
  - grid toggle
  - current-price-line toggle
  - navigation haptics
  - reduce animations
  - native fallback refresh interval (15 / 30 / 60 seconds)
  - refresh now
  - clear drawings
  - restore defaults
- Home now links to Backtest and Settings and clearly shows the dual chart/data architecture.
- Existing forced `ZKAppIconV4` asset-catalog fix is retained.

## Important market-data distinction

TradingView's embedded Advanced Chart can display `ICMARKETS:XAUUSD` directly, so the **visual TradingView chart** is the IC Markets chart. TradingView's chart library/widget does not provide its candle data to native Swift code. App-native price cards and the ZK-native chart therefore continue to use the XAUS reference feed for now. Exact native candle parity requires an authorised IC Markets/cTrader/MT5 feed later.

No AI trading model, backtest performance claims, entries, SLs, or TPs are generated in this build.

## GitHub build

Upload this archive to the repository as:

`ZK_AI_Native_v0.5.0_SOURCE.zip`

The existing workflow should detect version `0.5.0`, build the unsigned iPhone app, validate the bundle, package `ZK-AI-v0.5.0.ipa`, and publish it as a GitHub Release.
