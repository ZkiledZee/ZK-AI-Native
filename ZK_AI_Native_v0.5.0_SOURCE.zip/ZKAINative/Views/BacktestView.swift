import SwiftUI

struct BacktestView: View {
    @EnvironmentObject private var market: MarketDataService
    @Environment(\.zkScale) private var scale
    @State private var integrityResult = "Not checked"
    @State private var detail = "Run a data check on the currently loaded 1-minute candles. Strategy backtesting stays disabled until a real strategy/model exists."

    var body: some View {
        ScrollView {
            VStack(spacing: 10 * scale) {
                ZKPageHeader(
                    micro: "REPLAY + VALIDATION",
                    title: "Backtest",
                    pill: "FOUNDATION",
                    pillColor: ZKTheme.gold
                )

                statusHero
                coverageCard
                integrityCard
                futureCard
            }
            .padding(.horizontal, 16 * scale)
            .padding(.top, 8 * scale)
            .padding(.bottom, 18 * scale)
        }
        .scrollIndicators(.hidden)
        .background(ZKTheme.background)
    }

    private var statusHero: some View {
        ZKCard(strongBorder: true) {
            HStack(spacing: 12 * scale) {
                Image(systemName: "clock.arrow.circlepath")
                    .font(.system(size: 23 * scale, weight: .bold))
                    .foregroundStyle(ZKTheme.gold)
                    .frame(width: 48 * scale, height: 48 * scale)
                    .background(ZKTheme.gold.opacity(0.07))
                    .overlay(RoundedRectangle(cornerRadius: 14 * scale).stroke(ZKTheme.gold.opacity(0.30)))
                    .clipShape(RoundedRectangle(cornerRadius: 14 * scale))

                VStack(alignment: .leading, spacing: 3 * scale) {
                    Text("BACKTEST ENGINE")
                        .font(.system(size: 8 * scale, weight: .black))
                        .tracking(0.7)
                        .foregroundStyle(ZKTheme.textSoft)
                    Text("No strategy connected")
                        .font(.system(size: 14 * scale, weight: .bold))
                    Text("We will not create fake performance numbers before the AI/strategy layer exists.")
                        .font(.system(size: 9 * scale, weight: .medium))
                        .foregroundStyle(ZKTheme.textMuted)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Spacer()
            }
        }
    }

    private var coverageCard: some View {
        ZKCard {
            VStack(alignment: .leading, spacing: 9 * scale) {
                sectionTitle("CURRENT DATA COVERAGE", "What is available to validate right now")
                HStack(spacing: 6 * scale) {
                    stat("CANDLES", "\(market.candles.count)", ZKTheme.purple)
                    stat("TIMEFRAME", "1M", ZKTheme.gold)
                    stat("SOURCE", "XAUS", ZKTheme.green)
                }

                if let first = market.candles.first?.timestamp, let last = market.candles.last?.timestamp {
                    Text("Loaded window: \(format(first)) → \(format(last))")
                        .font(.system(size: 8 * scale, weight: .medium, design: .monospaced))
                        .foregroundStyle(ZKTheme.textMuted)
                } else {
                    Text("No candle window loaded yet.")
                        .font(.system(size: 8 * scale, weight: .medium))
                        .foregroundStyle(ZKTheme.textMuted)
                }
            }
        }
    }

    private var integrityCard: some View {
        ZKCard {
            VStack(alignment: .leading, spacing: 10 * scale) {
                sectionTitle("DATA INTEGRITY CHECK", "Useful before any backtest or model training")

                HStack {
                    VStack(alignment: .leading, spacing: 2 * scale) {
                        Text(integrityResult)
                            .font(.system(size: 12 * scale, weight: .bold))
                        Text(detail)
                            .font(.system(size: 8 * scale, weight: .medium))
                            .foregroundStyle(ZKTheme.textMuted)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    Spacer(minLength: 8)
                }

                Button {
                    runIntegrityCheck()
                } label: {
                    Label("RUN DATA CHECK", systemImage: "checkmark.shield.fill")
                        .font(.system(size: 9 * scale, weight: .black))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity, minHeight: 38 * scale)
                        .background(ZKTheme.accentGradient)
                        .clipShape(RoundedRectangle(cornerRadius: 11 * scale))
                }
                .buttonStyle(ZKPressStyle())
            }
        }
    }

    private var futureCard: some View {
        ZKCard {
            VStack(alignment: .leading, spacing: 7 * scale) {
                sectionTitle("NEXT BACKTEST LAYER", "Ready for the model stage later")
                feature("Historical IC Markets/broker candles", "Database-backed M1 history instead of only the current live window")
                feature("Chronological walk-forward", "Train → validation → unseen testing with no future leakage")
                feature("Trade lifecycle parity", "The same entry/SL/TP rules in replay and live mode")
                feature("Model Vault comparison", "Active vs challenger metrics with rollback")
            }
        }
    }

    private func runIntegrityCheck() {
        let candles = market.candles.sorted { $0.timestamp < $1.timestamp }
        guard candles.count >= 2 else {
            integrityResult = "Not enough data"
            detail = "Load at least two 1-minute candles first."
            return
        }

        var gaps = 0
        var duplicates = 0
        var invalidOHLC = 0
        var previous = candles[0]

        for candle in candles {
            if candle.high < max(candle.open, candle.close) || candle.low > min(candle.open, candle.close) || candle.high < candle.low {
                invalidOHLC += 1
            }
        }

        for candle in candles.dropFirst() {
            let delta = candle.timestamp.timeIntervalSince(previous.timestamp)
            if delta < 1 { duplicates += 1 }
            if delta > 90 { gaps += 1 }
            previous = candle
        }

        if invalidOHLC == 0 && duplicates == 0 && gaps == 0 {
            integrityResult = "PASS"
            detail = "\(candles.count) candles checked: chronological sequence, no large >90s gaps, and OHLC relationships are valid."
        } else {
            integrityResult = "REVIEW"
            detail = "Found \(gaps) large gaps, \(duplicates) duplicate timestamps and \(invalidOHLC) invalid OHLC records. Session closures can legitimately create gaps."
        }
    }

    private func sectionTitle(_ title: String, _ subtitle: String) -> some View {
        VStack(alignment: .leading, spacing: 2 * scale) {
            Text(title)
                .font(.system(size: 8 * scale, weight: .black))
                .tracking(0.7)
                .foregroundStyle(ZKTheme.textSoft)
            Text(subtitle)
                .font(.system(size: 9 * scale, weight: .medium))
                .foregroundStyle(ZKTheme.textMuted)
        }
    }

    private func stat(_ title: String, _ value: String, _ color: Color) -> some View {
        VStack(spacing: 3 * scale) {
            Text(title)
                .font(.system(size: 7 * scale, weight: .black))
                .foregroundStyle(ZKTheme.textMuted)
            Text(value)
                .font(.system(size: 12 * scale, weight: .black, design: .monospaced))
                .foregroundStyle(color)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 9 * scale)
        .background(Color.black.opacity(0.16))
        .overlay(RoundedRectangle(cornerRadius: 10 * scale).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 10 * scale))
    }

    private func feature(_ title: String, _ subtitle: String) -> some View {
        HStack(alignment: .top, spacing: 8 * scale) {
            Circle().fill(ZKTheme.purple).frame(width: 5 * scale, height: 5 * scale).padding(.top, 5 * scale)
            VStack(alignment: .leading, spacing: 1 * scale) {
                Text(title).font(.system(size: 9 * scale, weight: .bold))
                Text(subtitle).font(.system(size: 8 * scale, weight: .medium)).foregroundStyle(ZKTheme.textMuted)
            }
        }
    }

    private func format(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "dd MMM HH:mm"
        return f.string(from: date)
    }
}
