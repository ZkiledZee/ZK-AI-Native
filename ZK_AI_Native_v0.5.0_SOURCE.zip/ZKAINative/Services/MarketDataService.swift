import Foundation
import Combine

@MainActor
final class MarketDataService: ObservableObject {
    @Published private(set) var candles: [ChartCandle] = []
    @Published private(set) var spotPrice: Double?
    @Published private(set) var silverPrice: Double?
    @Published private(set) var feedStatus: MarketFeedStatus = .connecting
    @Published private(set) var lastUpdated: Date?
    @Published private(set) var priceTimestamp: Date?
    @Published private(set) var lastError: String?
    @Published private(set) var isRefreshing = false

    private var refreshTask: Task<Void, Never>?
    private var chartRefreshCounter = 0

    let sourceName = "XAUS"
    let sourceDetail = "Native fallback data • TradingView IC Markets is the visual reference"

    var currentPrice: Double? {
        spotPrice ?? candles.last?.close
    }

    var openPrice: Double? { candles.first?.open }
    var dayHigh: Double? { candles.map(\.high).max() }
    var dayLow: Double? { candles.map(\.low).min() }

    var change: Double? {
        guard let currentPrice, let openPrice else { return nil }
        return currentPrice - openPrice
    }

    var changePercent: Double? {
        guard let openPrice, openPrice != 0, let change else { return nil }
        return (change / openPrice) * 100
    }

    var range: Double? {
        guard let dayHigh, let dayLow else { return nil }
        return dayHigh - dayLow
    }

    var isLive: Bool { feedStatus == .live }

    var freshnessText: String {
        guard let priceTimestamp else { return feedStatus.rawValue }
        let seconds = max(0, Int(Date().timeIntervalSince(priceTimestamp)))
        if seconds < 60 { return "\(seconds)s ago" }
        if seconds < 3600 { return "\(seconds / 60)m ago" }
        return "\(seconds / 3600)h ago"
    }

    var sessionName: String {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT: 0)!
        let hour = calendar.component(.hour, from: Date())
        switch hour {
        case 7..<12: return "London"
        case 12..<16: return "London / NY overlap"
        case 16..<21: return "New York"
        case 0..<7: return "Asia"
        default: return "Off-hours"
        }
    }

    func start() {
        guard refreshTask == nil else { return }
        refreshTask = Task { [weak self] in
            guard let self else { return }
            await self.refreshAll()
            while !Task.isCancelled {
                let configured = UserDefaults.standard.integer(forKey: "zk.settings.refreshSeconds")
                let seconds = configured == 0 ? 30 : min(max(configured, 15), 60)
                try? await Task.sleep(nanoseconds: UInt64(seconds) * 1_000_000_000)
                self.chartRefreshCounter += 1
                if self.chartRefreshCounter % max(1, 60 / seconds) == 0 {
                    await self.refreshAll()
                } else {
                    await self.refreshSpot()
                }
            }
        }
    }

    func stop() {
        refreshTask?.cancel()
        refreshTask = nil
    }

    func refreshAll() async {
        isRefreshing = true
        defer { isRefreshing = false }

        await refreshChart()
        await refreshSpot()
    }

    func refreshSpot() async {
        do {
            let stamp = Int(Date().timeIntervalSince1970)
            guard let url = URL(string: "https://xaus.com/api/v1/spot?compact=1&fresh=\(stamp)") else { return }
            let data = try await fetch(url)
            try parseSpot(data)
            lastError = nil
        } catch {
            lastError = error.localizedDescription
            if spotPrice == nil && candles.isEmpty {
                feedStatus = .offline
            } else if feedStatus == .live {
                feedStatus = .stale
            }
        }
    }

    func refreshChart() async {
        do {
            let stamp = Int(Date().timeIntervalSince1970)
            guard let url = URL(string: "https://xaus.com/api/v1/chart?symbol=xau&range=1d&interval=1m&fresh=\(stamp)") else { return }
            let data = try await fetch(url)
            let parsed = try parseChart(data)
            if !parsed.isEmpty {
                candles = parsed
            }
            lastError = nil
        } catch {
            lastError = error.localizedDescription
            if candles.isEmpty && spotPrice == nil {
                feedStatus = .offline
            }
        }
    }

    private func fetch(_ url: URL) async throws -> Data {
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 15)
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("ZK-AI-iOS/0.5", forHTTPHeaderField: "User-Agent")

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw URLError(.badServerResponse)
        }
        return data
    }

    private func parseSpot(_ data: Data) throws {
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw URLError(.cannotParseResponse)
        }

        let price = number(root["spot_usd_oz"]) ?? number((root["xau"] as? [String: Any])?["price"])
        guard let price else { throw URLError(.cannotParseResponse) }

        spotPrice = price
        silverPrice = number(root["silver_usd_oz"])
        lastUpdated = parseISO(root["updated_at"] as? String) ?? Date()
        priceTimestamp = parseISO(root["price_as_of"] as? String) ?? parseDataStateDate(root) ?? lastUpdated

        if let state = root["data_state"] as? [String: Any], let status = state["status"] as? String {
            feedStatus = status.lowercased() == "fresh" ? .live : (status.lowercased() == "stale" ? .stale : .offline)
        } else if let stale = root["stale"] as? Bool, stale {
            feedStatus = .stale
        } else {
            feedStatus = .live
        }

        UserDefaults.standard.set(price, forKey: "zk.lastMarketPrice")
    }

    private func parseChart(_ data: Data) throws -> [ChartCandle] {
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw URLError(.cannotParseResponse)
        }

        if let points = root["points"] as? [[String: Any]] {
            let parsed = parsePointArray(points)
            if !parsed.isEmpty { return parsed }
        }

        if let dataPoints = root["data"] as? [[String: Any]] {
            let parsed = parsePointArray(dataPoints)
            if !parsed.isEmpty { return parsed }
        }

        if let series = root["series"] as? [[String: Any]] {
            let parsed = parsePointArray(series)
            if !parsed.isEmpty { return parsed }
        }

        if let chart = root["chart"] as? [String: Any],
           let results = chart["result"] as? [[String: Any]],
           let first = results.first,
           let timestamps = first["timestamp"] as? [Any],
           let indicators = first["indicators"] as? [String: Any],
           let quotes = indicators["quote"] as? [[String: Any]],
           let quote = quotes.first {
            return parseYahooArrays(timestamps: timestamps, quote: quote)
        }

        throw URLError(.cannotParseResponse)
    }

    private func parsePointArray(_ points: [[String: Any]]) -> [ChartCandle] {
        let sorted = points.compactMap { point -> (Date, Double, Double, Double, Double, Double?)? in
            guard let timestamp = timestamp(point["t"] ?? point["timestamp"] ?? point["time"]),
                  let close = number(point["c"] ?? point["close"] ?? point["p"] ?? point["price"]) else { return nil }

            let open = number(point["o"] ?? point["open"]) ?? close
            let high = number(point["h"] ?? point["high"]) ?? max(open, close)
            let low = number(point["l"] ?? point["low"]) ?? min(open, close)
            let volume = number(point["v"] ?? point["volume"])
            return (timestamp, open, high, low, close, volume)
        }
        .sorted { $0.0 < $1.0 }

        return sorted.enumerated().map { index, row in
            ChartCandle(index: index, timestamp: row.0, open: row.1, high: row.2, low: row.3, close: row.4, volume: row.5)
        }
    }

    private func parseYahooArrays(timestamps: [Any], quote: [String: Any]) -> [ChartCandle] {
        let opens = quote["open"] as? [Any] ?? []
        let highs = quote["high"] as? [Any] ?? []
        let lows = quote["low"] as? [Any] ?? []
        let closes = quote["close"] as? [Any] ?? []
        let volumes = quote["volume"] as? [Any] ?? []

        var result: [ChartCandle] = []
        for i in 0..<timestamps.count {
            guard i < closes.count,
                  let date = timestamp(timestamps[i]),
                  let close = number(closes[i]) else { continue }
            let open = i < opens.count ? (number(opens[i]) ?? close) : close
            let high = i < highs.count ? (number(highs[i]) ?? max(open, close)) : max(open, close)
            let low = i < lows.count ? (number(lows[i]) ?? min(open, close)) : min(open, close)
            let volume = i < volumes.count ? number(volumes[i]) : nil
            result.append(.init(index: result.count, timestamp: date, open: open, high: high, low: low, close: close, volume: volume))
        }
        return result
    }

    private func number(_ value: Any?) -> Double? {
        if value is NSNull || value == nil { return nil }
        if let n = value as? NSNumber { return n.doubleValue }
        if let s = value as? String { return Double(s) }
        return nil
    }

    private func timestamp(_ value: Any?) -> Date? {
        if let n = value as? NSNumber {
            let raw = n.doubleValue
            let seconds = raw > 10_000_000_000 ? raw / 1000 : raw
            return Date(timeIntervalSince1970: seconds)
        }
        if let s = value as? String {
            if let raw = Double(s) {
                let seconds = raw > 10_000_000_000 ? raw / 1000 : raw
                return Date(timeIntervalSince1970: seconds)
            }
            return parseISO(s)
        }
        return nil
    }

    private func parseISO(_ raw: String?) -> Date? {
        guard let raw else { return nil }
        let fractional = ISO8601DateFormatter()
        fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = fractional.date(from: raw) { return date }
        let normal = ISO8601DateFormatter()
        normal.formatOptions = [.withInternetDateTime]
        return normal.date(from: raw)
    }

    private func parseDataStateDate(_ root: [String: Any]) -> Date? {
        guard let state = root["data_state"] as? [String: Any] else { return nil }
        return parseISO(state["as_of"] as? String)
    }
}
