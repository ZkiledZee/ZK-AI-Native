import Foundation

enum ZKPage: Int, CaseIterable, Identifiable {
    case home, chart, lab, signal, backtest, chat, settings
    var id: Int { rawValue }

    var title: String {
        switch self {
        case .home: return "Home"
        case .chart: return "Chart"
        case .lab: return "AI Lab"
        case .signal: return "Signal"
        case .backtest: return "Backtest"
        case .chat: return "Chat"
        case .settings: return "Settings"
        }
    }

    var systemImage: String {
        switch self {
        case .home: return "house.fill"
        case .chart: return "chart.xyaxis.line"
        case .lab: return "sparkles"
        case .signal: return "diamond.fill"
        case .backtest: return "clock.arrow.circlepath"
        case .chat: return "bubble.left.and.bubble.right.fill"
        case .settings: return "gearshape.fill"
        }
    }
}

enum SignalSide: String, Codable { case buy = "BUY", wait = "WAIT", sell = "SELL" }

struct SignalSnapshot: Codable, Equatable {
    var side: SignalSide
    var buyProbability: Double
    var waitProbability: Double
    var sellProbability: Double
    var directionalConfidence: Double
    var executionConfidence: Double
    var entry: Double?
    var stopLoss: Double?
    var takeProfit: Double?
    var riskReward: Double?
    var lifecycle: String
    var reason: String

    static let dataOnly = SignalSnapshot(
        side: .wait,
        buyProbability: 0,
        waitProbability: 1,
        sellProbability: 0,
        directionalConfidence: 0,
        executionConfidence: 0,
        entry: nil,
        stopLoss: nil,
        takeProfit: nil,
        riskReward: nil,
        lifecycle: "LIVE DATA • AI OFF",
        reason: "Live market data can be connected, but the AI signal engine is intentionally disabled until the model stage."
    )
}

struct ModelRecord: Identifiable, Codable, Equatable {
    var id: UUID
    var name: String
    var status: String
    var evidence: String
    var trainRange: String
    var unseenRange: String
    var resolvedTrades: Int
    var profitFactor: Double?
    var expectancyR: Double?
    var drawdownR: Double?
    var averageHold: String

    static let seed: [ModelRecord] = [
        .init(id: UUID(), name: "ZK Market AI v0", status: "ACTIVE", evidence: "EXPERIMENTAL", trainRange: "Not trained", unseenRange: "Not tested", resolvedTrades: 0, profitFactor: nil, expectancyR: nil, drawdownR: nil, averageHold: "—"),
        .init(id: UUID(), name: "Challenger slot", status: "CHALLENGER", evidence: "EMPTY", trainRange: "—", unseenRange: "—", resolvedTrades: 0, profitFactor: nil, expectancyR: nil, drawdownR: nil, averageHold: "—")
    ]
}

enum MacroState { case bullish, bearish, neutral, unavailable }

struct MacroItem: Identifiable {
    let id = UUID()
    let name: String
    let value: String
    let subtitle: String
    let state: MacroState
}

enum DrawingKind: String, Codable { case support, resistance, zone, entry, stopLoss, takeProfit, note }

struct ChartDrawing: Identifiable, Codable, Equatable {
    var id = UUID()
    var kind: DrawingKind
    var price: Double
    var secondaryPrice: Double?
    var label: String
}

struct TradeJournalEntry: Identifiable, Codable, Equatable {
    var id = UUID()
    var createdAt: Date
    var side: SignalSide
    var executionConfidence: Double
    var macroCoverage: Double
    var session: String
    var spread: Double?
    var outcome: String
}

struct ChartCandle: Identifiable, Equatable {
    let id: UUID
    let index: Int
    let timestamp: Date
    let open: Double
    let high: Double
    let low: Double
    let close: Double
    var volume: Double?

    init(
        id: UUID = UUID(),
        index: Int,
        timestamp: Date = Date(),
        open: Double,
        high: Double,
        low: Double,
        close: Double,
        volume: Double? = nil
    ) {
        self.id = id
        self.index = index
        self.timestamp = timestamp
        self.open = open
        self.high = high
        self.low = low
        self.close = close
        self.volume = volume
    }

    var isUp: Bool { close >= open }
}

enum MarketFeedStatus: String {
    case connecting = "CONNECTING"
    case live = "LIVE"
    case stale = "STALE"
    case offline = "OFFLINE"
}

struct ChatMessage: Identifiable, Equatable {
    enum Role { case user, assistant }
    let id = UUID()
    let role: Role
    let text: String
}
