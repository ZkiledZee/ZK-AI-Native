import SwiftUI
import Foundation

@MainActor
final class AppState: ObservableObject {
    @Published var page: ZKPage = .home
    @Published var signal: SignalSnapshot = .dataOnly
    @Published var models: [ModelRecord] = ModelRecord.seed
    @Published var selectedModelID: UUID?
    @Published var drawings: [ChartDrawing] = []
    @Published var journal: [TradeJournalEntry] = []
    @Published var macroCoverage: Double = 0
    @Published var macroRegime: String = "NO MACRO DATA"
    @Published var agentLoaded = false
    @Published var chartMode: Int = UserDefaults.standard.integer(forKey: "zk.settings.chartMode")
    @Published var notificationPermission = false
    @Published var chatMessages: [ChatMessage] = [
        .init(
            role: .assistant,
            text: "The live market layer is separate from the AI layer. I can explain app state and manage chart drawings, but trading decisions remain disabled until a numerical model is trained and connected."
        )
    ]

    private(set) var installID: String = ""
    private(set) var launchCount: Int = 0

    init() {
        let defaults = UserDefaults.standard
        let existing = defaults.string(forKey: "zk.installID")
        let id = existing ?? UUID().uuidString
        if existing == nil { defaults.set(id, forKey: "zk.installID") }

        let nextCount = defaults.integer(forKey: "zk.launchCount") + 1
        defaults.set(nextCount, forKey: "zk.launchCount")

        installID = id
        launchCount = nextCount
        selectedModelID = models.first?.id
        loadDrawings()
    }

    var selectedModel: ModelRecord? {
        models.first(where: { $0.id == selectedModelID })
    }

    func go(_ destination: ZKPage) {
        if destination == .chart {
            chartMode = UserDefaults.standard.integer(forKey: "zk.settings.chartMode")
        }
        withAnimation(.easeOut(duration: 0.18)) {
            page = destination
        }
    }

    func replaceSupportResistance(around passedPrice: Double? = nil) {
        guard let price = referencePrice(passedPrice) else { return }
        let distance = max(price * 0.0012, 4.0)
        drawings.removeAll { $0.kind == .support || $0.kind == .resistance }
        drawings.append(.init(kind: .support, price: price - distance, label: "SUPPORT"))
        drawings.append(.init(kind: .resistance, price: price + distance, label: "RESISTANCE"))
        persistDrawings()
    }

    func addZone(around passedPrice: Double? = nil) {
        guard let price = referencePrice(passedPrice) else { return }
        let half = max(price * 0.00035, 1.25)
        drawings.removeAll { $0.kind == .zone }
        drawings.append(.init(kind: .zone, price: price - half, secondaryPrice: price + half, label: "MARKET ZONE"))
        persistDrawings()
    }

    func removeLastDrawing() {
        guard !drawings.isEmpty else { return }
        drawings.removeLast()
        persistDrawings()
    }

    func clearAllDrawings() {
        drawings.removeAll()
        persistDrawings()
    }

    func removeSupport() {
        drawings.removeAll { $0.kind == .support }
        persistDrawings()
    }

    func removeResistance() {
        drawings.removeAll { $0.kind == .resistance }
        persistDrawings()
    }

    private func referencePrice(_ passedPrice: Double?) -> Double? {
        if let passedPrice, passedPrice > 0 { return passedPrice }
        let saved = UserDefaults.standard.double(forKey: "zk.lastMarketPrice")
        return saved > 0 ? saved : nil
    }

    private func persistDrawings() {
        if let data = try? JSONEncoder().encode(drawings) {
            UserDefaults.standard.set(data, forKey: "zk.drawings")
        }
    }

    private func loadDrawings() {
        guard
            let data = UserDefaults.standard.data(forKey: "zk.drawings"),
            let decoded = try? JSONDecoder().decode([ChartDrawing].self, from: data)
        else { return }
        drawings = decoded.filter { !$0.label.uppercased().contains("DEMO") }
    }

    func sendChat(_ raw: String) {
        let q = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return }
        chatMessages.append(.init(role: .user, text: q))
        chatMessages.append(.init(role: .assistant, text: respond(to: q)))
    }

    private func respond(to query: String) -> String {
        let q = query.lowercased()

        if q.contains("support") || q.contains("resistance") {
            replaceSupportResistance()
            if referencePrice(nil) != nil {
                return "I replaced the previous support/resistance set around the latest saved live market price. These are manual chart tools, not AI-generated trade levels."
            }
            return "I need a live market price before I can place support/resistance around the chart."
        }

        if q.contains("clear") && q.contains("drawing") {
            clearAllDrawings()
            return "All chart drawings are cleared."
        }

        if q.contains("macro") || q.contains("cot") || q.contains("yield") || q.contains("dxy") {
            return "Macro AI is still disabled. The current build focuses on the IC Markets TradingView reference, native chart and app foundations before any AI logic is added."
        }

        if q.contains("model") || q.contains("performance") {
            let m = selectedModel
            return "The selected model is \(m?.name ?? "none"). Evidence status: \(m?.evidence ?? "unknown"). No trading model has been trained yet."
        }

        if q.contains("why") && q.contains("wait") {
            return "WAIT is intentional. The app can display live market data now, but the numerical trading model and execution gate are not enabled yet."
        }

        if q.contains("see") || q.contains("chart") {
            return "The Chart and Signal screens can display ICMARKETS:XAUUSD directly through TradingView. The separate ZK native chart uses the fallback feed and now has smooth continuous pan, momentum, pinch zoom, tap inspection and persistent drawings."
        }

        return "I can explain the app, feed status and chart tools. The next stage is the actual AI/model layer; I will not invent trading signals before that exists."
    }
}
