import SwiftUI
import UIKit

@MainActor
final class CTraderConnectionService: ObservableObject {
    enum Phase: String {
        case waitingApproval
        case readyToConnect
        case connected
    }

    @Published private(set) var phase: Phase
    @Published private(set) var accountLabel: String
    @Published private(set) var environmentLabel: String

    private let defaults = UserDefaults.standard

    init() {
        phase = defaults.bool(forKey: "zk.ctrader.connected") ? .connected : .waitingApproval
        accountLabel = defaults.string(forKey: "zk.ctrader.accountLabel") ?? ""
        environmentLabel = defaults.string(forKey: "zk.ctrader.environment") ?? "LIVE"
    }

    var isConnected: Bool { phase == .connected }

    func markReadyForOAuth() {
        guard phase != .connected else { return }
        phase = .readyToConnect
    }

    func completeConnection(account: String, environment: String = "LIVE") {
        accountLabel = account
        environmentLabel = environment
        phase = .connected
        defaults.set(true, forKey: "zk.ctrader.connected")
        defaults.set(account, forKey: "zk.ctrader.accountLabel")
        defaults.set(environment, forKey: "zk.ctrader.environment")
    }

    func disconnect() {
        phase = .waitingApproval
        accountLabel = ""
        defaults.removeObject(forKey: "zk.ctrader.connected")
        defaults.removeObject(forKey: "zk.ctrader.accountLabel")
    }

    func openOpenAPIPortal() {
        guard let url = URL(string: "https://openapi.ctrader.com/") else { return }
        UIApplication.shared.open(url)
    }
}
