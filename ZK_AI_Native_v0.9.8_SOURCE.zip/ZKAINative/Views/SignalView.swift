import SwiftUI

struct SignalView: View {
    @EnvironmentObject private var state: AppState
    @EnvironmentObject private var engine: SignalEngine
    @EnvironmentObject private var cTrader: CTraderConnectionService
    @Environment(\.zkScale) private var scale

    private var hasMachineFeed: Bool { cTrader.isConnected && state.selectedMarket.symbol == "XAUUSD" }

    var body: some View {
        VStack(spacing: 8 * scale) {
            ZKPageHeader(
                micro: "5 MARKET SIGNAL ENGINE",
                title: "Signal",
                pill: engine.enabled ? engine.mode.rawValue : "PAUSED",
                pillColor: engine.enabled ? modeColor : ZKTheme.textMuted
            )

            marketStrip
            engineControls

            signalChartArea

            statusStrip

            if hasMachineFeed, engine.activeTrade != nil {
                tradeStrip
            }
        }
        .padding(.horizontal, 12 * scale)
        .padding(.top, 8 * scale)
        .padding(.bottom, 8 * scale)
        .background(ZKTheme.background)
    }

    private var signalChartArea: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 16 * scale)
                .fill(Color.black)
            RoundedRectangle(cornerRadius: 16 * scale)
                .stroke(ZKTheme.borderStrong.opacity(0.72))

            if cTrader.isConnected {
                VStack(spacing: 9 * scale) {
                    Image(systemName: "chart.xyaxis.line")
                        .font(.system(size: 30 * scale, weight: .semibold))
                        .foregroundStyle(ZKTheme.purple)
                    Text("LIVE CTRADER CHART")
                        .font(.system(size: 11 * scale, weight: .black, design: .rounded))
                    Text("Native tick/M1 renderer activates with the Open API feed.")
                        .font(.system(size: 7.5 * scale, weight: .medium))
                        .foregroundStyle(ZKTheme.textMuted)
                }
            } else {
                VStack(spacing: 10 * scale) {
                    Image(systemName: "lock.fill")
                        .font(.system(size: 24 * scale, weight: .semibold))
                        .foregroundStyle(ZKTheme.gold)
                    Text("CONNECT CTRADER FIRST")
                        .font(.system(size: 11 * scale, weight: .black, design: .rounded))
                    Button("GO TO LOGIN") { state.go(.chart) }
                        .font(.system(size: 8 * scale, weight: .black, design: .rounded))
                        .buttonStyle(.borderedProminent)
                        .tint(ZKTheme.purple)
                }
            }
        }
        .frame(minHeight: 360 * scale, maxHeight: .infinity)
    }

    private var marketStrip: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 6 * scale) {
                ForEach(TradeMarket.watchlist) { market in
                    marketButton(market)
                }
            }
        }
    }

    private func marketButton(_ market: TradeMarket) -> some View {
        let selected = state.selectedMarketSymbol == market.symbol
        return Button {
            state.selectMarket(market)
        } label: {
            VStack(alignment: .leading, spacing: 1 * scale) {
                Text(market.symbol)
                    .font(.system(size: 8.5 * scale, weight: .black, design: .rounded))
                Text(market.weekendFriendly ? "7D" : "WK")
                    .font(.system(size: 6.3 * scale, weight: .black, design: .rounded))
                    .foregroundStyle(selected ? .white.opacity(0.65) : ZKTheme.textMuted)
            }
            .foregroundStyle(selected ? .white : ZKTheme.textSoft)
            .frame(width: 64 * scale, height: 34 * scale, alignment: .leading)
            .padding(.horizontal, 9 * scale)
            .background(selected ? ZKTheme.purple.opacity(0.25) : ZKTheme.card.opacity(0.72))
            .overlay(RoundedRectangle(cornerRadius: 11 * scale).stroke(selected ? ZKTheme.borderStrong : ZKTheme.border.opacity(0.65)))
            .clipShape(RoundedRectangle(cornerRadius: 11 * scale))
        }
        .buttonStyle(ZKPressStyle())
    }

    private var engineControls: some View {
        HStack(spacing: 8 * scale) {
            Toggle("", isOn: Binding(get: { engine.enabled }, set: { engine.setEnabled($0) }))
                .labelsHidden()
                .tint(ZKTheme.green)
                .scaleEffect(0.80)

            Picker("Signal mode", selection: Binding(get: { engine.mode }, set: { engine.setMode($0) })) {
                Text("SELECTIVE").tag(SignalEngineMode.selective)
                Text("FAST").tag(SignalEngineMode.fastScalper)
            }
            .pickerStyle(.segmented)
            .disabled(!engine.enabled)

            Button { engine.forceEvaluate() } label: {
                Image(systemName: "arrow.clockwise")
                    .font(.system(size: 10 * scale, weight: .bold))
                    .foregroundStyle(ZKTheme.textSoft)
                    .frame(width: 31 * scale, height: 31 * scale)
                    .background(ZKTheme.card)
                    .clipShape(Circle())
            }
            .buttonStyle(ZKPressStyle())
        }
        .padding(.horizontal, 8 * scale)
        .frame(height: 42 * scale)
        .background(ZKTheme.card.opacity(0.72))
        .overlay(RoundedRectangle(cornerRadius: 13 * scale).stroke(ZKTheme.border.opacity(0.70)))
        .clipShape(RoundedRectangle(cornerRadius: 13 * scale))
    }

    private var statusStrip: some View {
        HStack(spacing: 9 * scale) {
            Circle()
                .fill(displayColor)
                .frame(width: 8 * scale, height: 8 * scale)
                .shadow(color: displayColor.opacity(0.45), radius: 5)

            VStack(alignment: .leading, spacing: 2 * scale) {
                HStack(spacing: 7 * scale) {
                    Text(displaySide)
                        .font(.system(size: 15 * scale, weight: .black, design: .rounded))
                        .foregroundStyle(displayColor)
                    Text(state.selectedMarket.symbol)
                        .font(.system(size: 7.5 * scale, weight: .black, design: .monospaced))
                        .foregroundStyle(ZKTheme.textMuted)
                }
                Text(displayReason)
                    .font(.system(size: 7.5 * scale, weight: .medium))
                    .foregroundStyle(ZKTheme.textMuted)
                    .lineLimit(1)
            }

            Spacer(minLength: 4)

            VStack(alignment: .trailing, spacing: 2 * scale) {
                Text(hasMachineFeed ? "PREVIEW" : "API WAIT")
                    .font(.system(size: 7 * scale, weight: .black, design: .rounded))
                    .foregroundStyle(hasMachineFeed ? ZKTheme.gold : ZKTheme.purple)
                if hasMachineFeed {
                    Text("SCORE \(Int(engine.lastScore))")
                        .font(.system(size: 7 * scale, weight: .black, design: .monospaced))
                        .foregroundStyle(ZKTheme.textSoft)
                }
            }
        }
        .padding(.horizontal, 12 * scale)
        .frame(height: 52 * scale)
        .background(ZKTheme.card.opacity(0.72))
        .overlay(RoundedRectangle(cornerRadius: 13 * scale).stroke(displayColor.opacity(0.14)))
        .clipShape(RoundedRectangle(cornerRadius: 13 * scale))
    }

    private var tradeStrip: some View {
        guard let trade = engine.activeTrade else { return AnyView(EmptyView()) }
        return AnyView(
            HStack(spacing: 6 * scale) {
                compactLevel("ENTRY", trade.entry, displayColor)
                compactLevel("SL", trade.stopLoss, ZKTheme.red)
                compactLevel("TP", trade.takeProfit, ZKTheme.green)
                compactLevel("R:R", rewardRisk(trade), ZKTheme.purple)
            }
            .padding(.horizontal, 8 * scale)
            .frame(height: 45 * scale)
            .background(ZKTheme.card.opacity(0.72))
            .overlay(RoundedRectangle(cornerRadius: 12 * scale).stroke(ZKTheme.border.opacity(0.75)))
            .clipShape(RoundedRectangle(cornerRadius: 12 * scale))
        )
    }

    private func compactLevel(_ title: String, _ value: Double, _ color: Color) -> some View {
        VStack(spacing: 2 * scale) {
            Text(title)
                .font(.system(size: 6.3 * scale, weight: .black))
                .foregroundStyle(ZKTheme.textMuted)
            Text(title == "R:R" ? String(format: "%.2f", value) : String(format: "%.2f", value))
                .font(.system(size: 8.2 * scale, weight: .black, design: .monospaced))
                .foregroundStyle(color)
                .lineLimit(1)
                .minimumScaleFactor(0.70)
        }
        .frame(maxWidth: .infinity)
    }

    private func rewardRisk(_ trade: PaperSignalTrade) -> Double {
        let risk = max(abs(trade.entry - trade.stopLoss), 0.000001)
        return abs(trade.takeProfit - trade.entry) / risk
    }

    private var displaySide: String {
        hasMachineFeed ? engine.snapshot.side.rawValue : "WAIT"
    }

    private var displayReason: String {
        if !hasMachineFeed {
            return cTrader.isConnected ? "cTrader connection ready • waiting for raw Open API stream" : "Connect cTrader before enabling broker-data signals"
        }
        let reason = engine.snapshot.reason
            .replacingOccurrences(of: "Selective scan: ", with: "")
            .replacingOccurrences(of: "Fast scalper scan: ", with: "")
        return reason.isEmpty ? "Reference-feed preview until cTrader API connects." : reason
    }

    private var displayColor: Color {
        if !hasMachineFeed { return ZKTheme.gold }
        switch engine.snapshot.side {
        case .buy: return ZKTheme.green
        case .sell: return ZKTheme.red
        case .wait: return ZKTheme.gold
        }
    }

    private var modeColor: Color { engine.mode == .fastScalper ? ZKTheme.pink : ZKTheme.purple }
}
