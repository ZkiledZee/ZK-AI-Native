import SwiftUI

struct ChartView: View {
    @EnvironmentObject private var state: AppState
    @EnvironmentObject private var cTrader: CTraderConnectionService
    @Environment(\.zkScale) private var scale

    var body: some View {
        ZStack {
            ZKTheme.background.ignoresSafeArea()

            if cTrader.isConnected {
                connectedView
            } else {
                loginGate
            }
        }
        .padding(.horizontal, 14 * scale)
        .padding(.top, 10 * scale)
        .padding(.bottom, 10 * scale)
    }

    private var loginGate: some View {
        VStack(spacing: 22 * scale) {
            Spacer(minLength: 8 * scale)

            ZStack {
                Circle()
                    .fill(ZKTheme.purple.opacity(0.10))
                    .frame(width: 110 * scale, height: 110 * scale)
                Circle()
                    .stroke(ZKTheme.borderStrong.opacity(0.8), lineWidth: 1)
                    .frame(width: 110 * scale, height: 110 * scale)
                Image(systemName: "link.circle.fill")
                    .font(.system(size: 48 * scale, weight: .semibold))
                    .foregroundStyle(ZKTheme.purple)
            }

            VStack(spacing: 7 * scale) {
                Text("Connect cTrader")
                    .font(.system(size: 26 * scale, weight: .black, design: .rounded))
                    .foregroundStyle(.white)

                Text("One login. Native charts, signals and trading data after connection.")
                    .font(.system(size: 9 * scale, weight: .medium))
                    .foregroundStyle(ZKTheme.textMuted)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 26 * scale)
            }

            VStack(spacing: 10 * scale) {
                HStack(spacing: 8 * scale) {
                    statusDot
                    Text(statusTitle)
                        .font(.system(size: 8 * scale, weight: .black, design: .rounded))
                        .foregroundStyle(statusColor)
                    Spacer()
                }

                Button {
                    if cTrader.phase == .readyToConnect {
                        // OAuth button is intentionally staged until the approved Open API
                        // redirect/backend is configured. Do not collect cTrader passwords here.
                    } else {
                        cTrader.openOpenAPIPortal()
                    }
                } label: {
                    HStack(spacing: 8 * scale) {
                        Image(systemName: cTrader.phase == .readyToConnect ? "person.crop.circle.badge.checkmark" : "checkmark.shield")
                        Text(cTrader.phase == .readyToConnect ? "CONNECT CTRADER" : "CHECK API STATUS")
                    }
                    .font(.system(size: 10 * scale, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 48 * scale)
                    .background(ZKTheme.purple)
                    .clipShape(RoundedRectangle(cornerRadius: 15 * scale))
                }
                .buttonStyle(ZKPressStyle())

                Text(cTrader.phase == .waitingApproval ? "Your Open API app must become Active before secure in-app OAuth can be completed." : "Secure cTrader OAuth will open and return directly to ZK AI.")
                    .font(.system(size: 7.5 * scale, weight: .medium))
                    .foregroundStyle(ZKTheme.textMuted)
                    .multilineTextAlignment(.center)
            }
            .padding(16 * scale)
            .background(ZKTheme.card.opacity(0.78))
            .overlay(RoundedRectangle(cornerRadius: 18 * scale).stroke(ZKTheme.border.opacity(0.8)))
            .clipShape(RoundedRectangle(cornerRadius: 18 * scale))

            Spacer()
        }
    }

    private var connectedView: some View {
        VStack(spacing: 10 * scale) {
            ZKPageHeader(
                micro: "CTRADER • \(state.selectedMarket.symbol)",
                title: "Chart",
                pill: cTrader.environmentLabel,
                pillColor: ZKTheme.green
            )

            marketStrip

            ZStack {
                RoundedRectangle(cornerRadius: 18 * scale)
                    .fill(Color.black)
                RoundedRectangle(cornerRadius: 18 * scale)
                    .stroke(ZKTheme.borderStrong.opacity(0.75))

                VStack(spacing: 10 * scale) {
                    Image(systemName: "chart.xyaxis.line")
                        .font(.system(size: 34 * scale, weight: .semibold))
                        .foregroundStyle(ZKTheme.purple)
                    Text("cTrader live chart")
                        .font(.system(size: 15 * scale, weight: .black, design: .rounded))
                    Text("The native chart renderer will consume Open API bars and ticks from the connected account.")
                        .font(.system(size: 8 * scale, weight: .medium))
                        .foregroundStyle(ZKTheme.textMuted)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 28 * scale)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)

            HStack {
                Circle().fill(ZKTheme.green).frame(width: 7 * scale, height: 7 * scale)
                Text(cTrader.accountLabel.isEmpty ? "CTRADER CONNECTED" : cTrader.accountLabel)
                    .font(.system(size: 7.5 * scale, weight: .black, design: .rounded))
                    .foregroundStyle(ZKTheme.textSoft)
                Spacer()
                Button("DISCONNECT") { cTrader.disconnect() }
                    .font(.system(size: 7 * scale, weight: .black, design: .rounded))
                    .foregroundStyle(ZKTheme.red)
                    .buttonStyle(.plain)
            }
            .padding(.horizontal, 4 * scale)
        }
    }

    private var marketStrip: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 7 * scale) {
                ForEach(TradeMarket.watchlist) { market in
                    let selected = state.selectedMarketSymbol == market.symbol
                    Button { state.selectMarket(market) } label: {
                        Text(market.symbol)
                            .font(.system(size: 8 * scale, weight: .black, design: .rounded))
                            .foregroundStyle(selected ? .white : ZKTheme.textSoft)
                            .padding(.horizontal, 12 * scale)
                            .frame(height: 34 * scale)
                            .background(selected ? ZKTheme.purple.opacity(0.24) : ZKTheme.card.opacity(0.72))
                            .overlay(RoundedRectangle(cornerRadius: 11 * scale).stroke(selected ? ZKTheme.borderStrong : ZKTheme.border.opacity(0.65)))
                            .clipShape(RoundedRectangle(cornerRadius: 11 * scale))
                    }
                    .buttonStyle(ZKPressStyle())
                }
            }
        }
    }

    private var statusTitle: String {
        switch cTrader.phase {
        case .waitingApproval: return "OPEN API APPROVAL PENDING"
        case .readyToConnect: return "READY TO CONNECT"
        case .connected: return "CONNECTED"
        }
    }

    private var statusColor: Color {
        cTrader.phase == .waitingApproval ? ZKTheme.gold : ZKTheme.green
    }

    private var statusDot: some View {
        Circle().fill(statusColor).frame(width: 7 * scale, height: 7 * scale)
    }
}
