# ZK AI Native v0.9.3 — Minimal Home + 5 Markets + cTrader Preview

## v1.0.1 — WebSocket connection fix

- Waits for iOS `URLSessionWebSocketDelegate` to confirm that the secure cTrader socket is open before sending application authentication.
- Prevents the false `Socket is not connected` failure seen immediately after pressing Save & Connect.
- Distinguishes deliberate disconnects from unexpected cTrader socket closures.

## v1.0.0 — Real cTrader demo connection

- Replaces the simulated connected flag with cTrader Open API JSON over secure WebSocket.
- Adds Keychain-only storage for client ID, client secret, access token and optional refresh token. No credential is stored in source control or bundled into the IPA.
- Discovers accounts authorised by the token, selects the correct demo/live endpoint, authenticates the selected account and displays broker, login, balance, equity, currency, leverage, positions and pending-order count.
- Shows `Raw Trading Ltd` as the legal broker identity used by IC Markets Global.
- Refreshes account state and position P&L while connected and sends the required cTrader heartbeat.
- Adds a guarded AI demo-execution switch and broker-derived lot conversion. Each new ZK signal can be sent once as a market order with relative stop-loss and take-profit protection.
- Automatic live trading is deliberately locked until demo fills, protection levels, reconnects and token renewal are verified on-device.
- Access tokens expire after roughly 30 days; adding the refresh token allows ZK AI to renew credentials when cTrader invalidates the access token.

This build keeps the app simple and prepares the UI for the cTrader transition without pretending the pending Open API connection already exists.

## Minimal Home
- Rebuilt Home around one animated ZK mark near the top.
- Reduced Home actions to Signal, cTrader and Agent.
- Added one compact five-market selector instead of market-stat/dashboard cards.
- Global selected market now persists across Home, Chart and Signal.

## Five-market watchlist
- XAUUSD — weekday metal market.
- EURUSD — weekday FX.
- GBPUSD — weekday FX.
- BTCUSD — crypto CFD / 7-day watchlist slot.
- ETHUSD — crypto CFD / 7-day watchlist slot.
- IC Markets Global states that cryptocurrency CFDs are available seven days a week, while noting that some individual symbols can have weekend availability differences. Final tradability/session metadata will be taken from the connected cTrader account once Open API is active.

## cTrader inside ZK
- Chart now uses the official cTrader Market Chart widget in M1 candlestick mode.
- Added a CHART / TRADE switch. TRADE embeds the full official cTrader Web widget inside the app and keeps WKWebView cookies/session data so cTrader login can persist.
- cTrader Web is the manual-trading surface; no cTrader password is stored by ZK code.
- The five watchlist symbols can be switched directly above the cTrader chart.

## Signal boundary before Open API activation
- The embedded cTrader chart is a visual cTrader widget; the local Signal Engine and Agent cannot read hidden widget candles.
- The old XAU reference feed remains available only as an explicitly labelled preview input for the existing paper engine.
- EURUSD, GBPUSD, BTCUSD and ETHUSD do not fabricate signals. They show API WAIT until the approved cTrader Open API connection provides machine-readable broker bars/ticks.
- Once the application becomes Active, this watchlist becomes the target for the real multi-market scanner and the five UI slots do not need another redesign.

# ZK AI Native v0.9.2 — Focus UI

This update is a UI simplification pass. HomeView is intentionally unchanged.

## Focus UI changes
- Bottom navigation reduced from seven visible tabs to five: Home, Chart, Signal, Chat, More.
- More contains AI Lab, Backtest and Settings so advanced tools remain available without crowding the main navigation.
- Chart is now chart-first: compact source switcher, price, AI action and the chart itself. Verbose source/explanation cards were removed.
- Native chart drawings moved into one overflow menu.
- Signal is cleaner: larger chart, one compact state strip and one compact trade-level strip when a paper trade is active.
- AI Lab now shows only Agent, Trading Model and Model Vault by default; secondary diagnostics live under Advanced.
- Backtest now focuses on data coverage and one Run Data Check action; future/technical items live under More.
- Settings now has four compact groups: Signals, ZK Agent, Chart and Advanced.
- Chat keeps the ChatGPT-style layout and hides agent diagnostics when the agent is idle.

No signal-engine rules, model inference logic, chat persistence, market-data endpoints or Home page layout were changed in this pass.

# ZK AI Native v0.9.0 — Clean Chat + Signal Engine Alpha

This build cleans the local-agent chat into a minimal ChatGPT-style conversation screen and starts the first forward-running XAUUSD signal engine on the same custom 1-minute candle array used by the chart and ZK Agent.

## Clean local-agent chat
- Minimal top bar with chat history, current local model state and New Chat.
- Assistant replies render as clean edge-to-edge text with a small ZK avatar; user messages use a compact right-aligned bubble.
- Rounded composer with a working `+` tool menu and circular send button.
- Heavy status/model cards and permanent suggestion rows were removed from the conversation surface.
- Agent progress is reduced to one compact working/status line.
- Persistent local conversations from v0.8 remain intact.
- Fast 0.5B and Smart 1.5B model download/selection remain supported.

## ZK Signal Engine Alpha
- Enabled by default after update unless the user pauses it.
- Runs locally on the same machine-readable 1M `ChartCandle` array shown on Signal and read by ZK Agent.
- Uses confluence from EMA8/21, RSI14, ATR14, 1M breakout/impulse, 5M/15M context, BOS/CHOCH, liquidity sweeps and nearby S/R.
- Maintains one paper setup at a time until TP or SL is reached.
- Draws active Entry / SL / TP directly onto the custom Signal chart.
- Persists recent paper setups across app relaunches.
- Can send local iOS alerts when a new qualifying paper setup opens (if notifications are enabled).

### SELECTIVE mode
- Higher confluence threshold.
- ~55 minute cooldown between paper signals.
- Daily cap 4.
- Intended to target a few cleaner qualifying setups on an active day. Trade count is not guaranteed; WAIT is valid when no setup qualifies.

### FAST SCALPER mode
- Lower confluence threshold.
- ~8 minute cooldown.
- Daily cap 14.
- Shorter ATR-based stop/target distances and lower R:R than Selective.
- Intended to surface more short-lived 1M paper opportunities.

## Safety / evidence boundary
The v0.9 Signal Engine is an **alpha heuristic/confluence engine**, not a trained predictive ML model, not a profitability claim and not broker order execution. Signals are explicitly paper signals. The conversational model is not allowed to invent a separate trade; it reads the actual engine state.

The current chart still uses the existing reference feed. Exact candle-for-candle `ICMARKETS:XAUUSD` parity still requires an authorized IC Markets/cTrader or other broker-quality stream.

## v0.9.1 — Signal UI cleanup
- Rebuilt Signal into a much cleaner chart-first layout.
- Removed the large engine card, probability boxes, confidence ring and empty level cards while no paper setup is open.
- Combined price, feed state, engine toggle and mode into one compact control surface.
- Enlarged the custom 1M chart and simplified its header/actions.
- Signal chart now shows only active Entry/SL/TP overlays; saved AI support/resistance drawings stay on the full Chart tab.
- Native chart defaults to a tighter recent 34-candle view, has a dedicated right price axis, cleaner grid/labels and protects candle scaling from distant drawings.
- Open-trade level cards only appear when a paper signal is actually active.

## v0.9.4 — cTrader browser fix
- Replaced the blank Trade surface with a real browser-style WKWebView that navigates directly to official `https://app.ctrader.com/`.
- Requests desktop cTrader Web layout, keeps the normal persistent WebKit cookie store, supports back/forward/reload/home, new-window navigation, and an external-browser fallback.
- Added an IC Markets cTrader-ID login shortcut inside the browser chrome.
- Fixed the official cTrader Market Chart embed by applying the mandatory width/height directly to the plugin root element and waiting for the widget itself to report/render before removing the loading state.
- Added explicit widget timeout/script-error handling so a failed widget can no longer look like an empty black rectangle.
- cTrader/Open API market data for ZK signals is still gated until the Open API application is Active; this web terminal is for visual/manual cTrader use and login.


## v0.9.5 build fix
- Restores the missing `ZKTheme.purpleLight` color used by the new cTrader browser UI.
- Fixes the Xcode compile failure in `CTraderWeb.swift` and `ChartView.swift`.


## v0.9.6 — cTrader freeze fix
- Fixed a SwiftUI/WKWebView state feedback loop that could lock the main thread when opening Chart.
- Browser state is now attached once instead of on every `updateUIView` pass.
- Navigation state only publishes when back/forward/host values actually change.
- No `@Published` mutations are performed from `updateUIView`, preventing recursive render invalidation.


## v0.9.7 — cTrader phone scaling
- Automatically measures and fits the desktop cTrader Web document to the iPhone browser width.
- Re-fits after SPA/login panels finish laying out, preventing the login dialog from being clipped.
- Adds − / FIT / + browser zoom controls for manual adjustment.
- Keeps the v0.9.6 no-freeze WKWebView state handling.


## v0.9.8 — Native cTrader flow
- Removed the browser-style cTrader terminal from the main Chart experience.
- Chart now opens on a native cTrader connection gate before any charts are shown.
- No cTrader password is collected or stored by ZK AI.
- Signal chart is locked until cTrader connection is established.
- Native chart/data shell is ready for cTrader Open API bars/ticks after the application becomes Active and OAuth/backend callback is configured.
- Keeps v0.9.6 main-thread freeze fix by no longer mounting cTrader Web in the active app flow.
