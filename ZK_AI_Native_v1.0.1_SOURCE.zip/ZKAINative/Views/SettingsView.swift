import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var state: AppState
    @EnvironmentObject private var market: MarketDataService
    @EnvironmentObject private var ai: LocalAIService
    @EnvironmentObject private var signalEngine: SignalEngine
    @EnvironmentObject private var cTrader: CTraderConnectionService
    @Environment(\.zkScale) private var scale

    @AppStorage("zk.settings.chartMode") private var chartMode = 0
    @AppStorage("zk.settings.chartGrid") private var chartGrid = true
    @AppStorage("zk.settings.priceLine") private var priceLine = true
    @AppStorage("zk.settings.chartMomentum") private var chartMomentum = true
    @AppStorage("zk.settings.haptics") private var haptics = true
    @AppStorage("zk.settings.reduceMotion") private var reduceMotion = false
    @AppStorage("zk.settings.refreshSeconds") private var refreshSeconds = 30
    @State private var showAdvanced = false

    var body: some View {
        ScrollView {
            VStack(spacing: 10 * scale) {
                ZKPageHeader(micro: "CONTROLS", title: "Settings", pill: "v1.0.1", pillColor: ZKTheme.purple)
                tradingCard
                aiCard
                chartCard
                advancedCard
            }
            .padding(.horizontal, 16 * scale)
            .padding(.top, 8 * scale)
            .padding(.bottom, 18 * scale)
        }
        .scrollIndicators(.hidden)
        .background(ZKTheme.background)
        .onChange(of: chartMode) { _, newValue in state.chartMode = newValue }
    }

    private var tradingCard: some View {
        ZKCard(strongBorder: true) {
            VStack(spacing: 10 * scale) {
                cardTitle("SIGNALS")

                Toggle(isOn: Binding(get: { signalEngine.enabled }, set: { signalEngine.setEnabled($0) })) {
                    Text("Signal engine")
                        .font(.system(size: 10 * scale, weight: .bold))
                }
                .tint(ZKTheme.green)

                Picker("Mode", selection: Binding(get: { signalEngine.mode }, set: { signalEngine.setMode($0) })) {
                    Text("SELECTIVE").tag(SignalEngineMode.selective)
                    Text("FAST SCALPER").tag(SignalEngineMode.fastScalper)
                }
                .pickerStyle(.segmented)
                .disabled(!signalEngine.enabled)

                HStack {
                    Label(market.feedStatus.rawValue, systemImage: "circle.fill")
                        .font(.system(size: 8 * scale, weight: .black))
                        .foregroundStyle(feedColor)
                    Spacer()
                    Text(cTrader.aiExecutionEnabled ? "CTRADER DEMO AUTO" : "SIGNALS ONLY")
                        .font(.system(size: 8 * scale, weight: .black))
                        .foregroundStyle(cTrader.aiExecutionEnabled ? ZKTheme.green : ZKTheme.textMuted)
                }
            }
        }
    }

    private var aiCard: some View {
        ZKCard {
            VStack(spacing: 10 * scale) {
                cardTitle("ZK AGENT")

                Picker("Agent model", selection: Binding(
                    get: { ai.selectedTier.rawValue },
                    set: { raw in if let tier = LocalAIService.ModelTier(rawValue: raw) { ai.selectTier(tier) } }
                )) {
                    Text("FAST 0.5B").tag(LocalAIService.ModelTier.fast.rawValue)
                    Text("SMART 1.5B").tag(LocalAIService.ModelTier.smart.rawValue)
                }
                .pickerStyle(.segmented)
                .disabled(ai.isBusy)

                HStack(spacing: 8 * scale) {
                    Circle().fill(aiSettingsColor).frame(width: 7 * scale, height: 7 * scale)
                    VStack(alignment: .leading, spacing: 1 * scale) {
                        Text(ai.modelName)
                            .font(.system(size: 10 * scale, weight: .bold))
                            .lineLimit(1)
                        Text(ai.statusDetail)
                            .font(.system(size: 8 * scale, weight: .medium))
                            .foregroundStyle(ZKTheme.textMuted)
                            .lineLimit(1)
                    }
                    Spacer()
                }

                if case .downloading = ai.state {
                    ProgressView(value: ai.downloadProgress).tint(ZKTheme.purple)
                } else if !ai.isInstalled {
                    Button { ai.downloadModel() } label: {
                        Text(ai.selectedTier == .smart ? "DOWNLOAD SMART" : "DOWNLOAD FAST")
                            .font(.system(size: 8.5 * scale, weight: .black))
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity, minHeight: 34 * scale)
                            .background(ZKTheme.accentGradient)
                            .clipShape(RoundedRectangle(cornerRadius: 10 * scale))
                    }
                    .buttonStyle(ZKPressStyle())
                } else if !ai.isReady {
                    Button { Task { await ai.loadModel() } } label: {
                        Text("LOAD MODEL")
                            .font(.system(size: 8.5 * scale, weight: .black))
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity, minHeight: 34 * scale)
                            .background(ZKTheme.card2)
                            .overlay(RoundedRectangle(cornerRadius: 10 * scale).stroke(ZKTheme.borderStrong))
                            .clipShape(RoundedRectangle(cornerRadius: 10 * scale))
                    }
                    .buttonStyle(ZKPressStyle())
                    .disabled(ai.isBusy)
                }
            }
        }
    }

    private var chartCard: some View {
        ZKCard {
            VStack(spacing: 10 * scale) {
                cardTitle("CHART")

                Picker("Default chart", selection: $chartMode) {
                    Text("ICM TV").tag(0)
                    Text("ZK CUSTOM").tag(1)
                }
                .pickerStyle(.segmented)

                Toggle("Momentum scrolling", isOn: $chartMomentum).tint(ZKTheme.purple)
                Toggle("Grid", isOn: $chartGrid).tint(ZKTheme.purple)
                Toggle("Price line", isOn: $priceLine).tint(ZKTheme.purple)
            }
            .font(.system(size: 10 * scale, weight: .semibold))
        }
    }

    private var advancedCard: some View {
        ZKCard {
            DisclosureGroup(isExpanded: $showAdvanced) {
                VStack(spacing: 11 * scale) {
                    Divider().overlay(ZKTheme.border)

                    Toggle("Navigation haptics", isOn: $haptics).tint(ZKTheme.purple)
                    Toggle("Reduce motion", isOn: $reduceMotion).tint(ZKTheme.purple)

                    Picker("Refresh", selection: $refreshSeconds) {
                        Text("15s").tag(15)
                        Text("30s").tag(30)
                        Text("60s").tag(60)
                    }
                    .pickerStyle(.segmented)

                    HStack(spacing: 8 * scale) {
                        Button("Refresh data") { Task { await market.refreshAll() } }
                            .frame(maxWidth: .infinity)
                        Button("Clear drawings", role: .destructive) { state.clearAllDrawings() }
                            .frame(maxWidth: .infinity)
                    }
                    .font(.system(size: 8.5 * scale, weight: .bold))
                    .buttonStyle(.bordered)
                    .tint(ZKTheme.purple)
                }
                .padding(.top, 6 * scale)
            } label: {
                HStack {
                    Text("ADVANCED")
                        .font(.system(size: 8 * scale, weight: .black))
                        .foregroundStyle(ZKTheme.textMuted)
                    Spacer()
                    Text(showAdvanced ? "HIDE" : "SHOW")
                        .font(.system(size: 7 * scale, weight: .black))
                        .foregroundStyle(ZKTheme.purple)
                }
            }
            .tint(ZKTheme.purple)
        }
    }

    private func cardTitle(_ title: String) -> some View {
        HStack {
            Text(title)
                .font(.system(size: 8 * scale, weight: .black))
                .tracking(0.6)
                .foregroundStyle(ZKTheme.textMuted)
            Spacer()
        }
    }

    private var aiSettingsColor: Color {
        switch ai.state {
        case .ready, .generating: return ZKTheme.green
        case .downloading, .verifying, .loading, .downloaded: return ZKTheme.gold
        case .failed: return ZKTheme.red
        case .notDownloaded: return ZKTheme.purple
        }
    }

    private var feedColor: Color {
        switch market.feedStatus {
        case .live: return ZKTheme.green
        case .stale, .connecting: return ZKTheme.gold
        case .offline: return ZKTheme.red
        }
    }
}
