import Foundation
import Security
import SwiftUI
import UIKit

struct CTraderAccountSummary: Identifiable, Hashable {
    let id: Int64
    let login: Int64
    let broker: String
    let isLive: Bool

    var label: String { "\(broker) • \(isLive ? "Live" : "Demo") • \(login)" }
}

struct CTraderPositionSummary: Identifiable, Hashable {
    let id: Int64
    let symbolID: Int64
    var symbol: String
    let side: String
    let volume: Double
    let entryPrice: Double
    let stopLoss: Double?
    let takeProfit: Double?
    var netProfit: Double?
}

struct CTraderSymbolInfo: Hashable {
    let id: Int64
    let name: String
    var minVolume: Int64?
    var stepVolume: Int64?
    var lotSize: Int64?
}

@MainActor
final class CTraderConnectionService: ObservableObject {
    enum Phase: String {
        case disconnected
        case readyToConnect
        case connecting
        case authorizing
        case connected
        case failed
    }

    enum Environment: String, CaseIterable, Identifiable {
        case demo = "DEMO"
        case live = "LIVE"
        var id: String { rawValue }
        var host: String { self == .demo ? "demo.ctraderapi.com" : "live.ctraderapi.com" }
    }

    @Published private(set) var phase: Phase = .disconnected
    @Published private(set) var accountLabel = ""
    @Published private(set) var environmentLabel = "DEMO"
    @Published private(set) var accounts: [CTraderAccountSummary] = []
    @Published private(set) var selectedAccountID: Int64?
    @Published private(set) var balance: Double?
    @Published private(set) var equity: Double?
    @Published private(set) var currency = "USD"
    @Published private(set) var leverage: Int?
    @Published private(set) var positions: [CTraderPositionSummary] = []
    @Published private(set) var pendingOrderCount = 0
    @Published private(set) var permissionCanTrade = false
    @Published private(set) var errorMessage = ""
    @Published private(set) var lastTradeStatus = "AI execution is off"
    @Published var aiExecutionEnabled: Bool {
        didSet { UserDefaults.standard.set(aiExecutionEnabled, forKey: "zk.ctrader.aiExecution") }
    }
    @Published var lotSize: Double {
        didSet {
            let safe = min(max(lotSize, 0.01), 1.0)
            if safe != lotSize { lotSize = safe; return }
            UserDefaults.standard.set(lotSize, forKey: "zk.ctrader.lotSize")
        }
    }

    private let defaults = UserDefaults.standard
    private let keychain = CTraderKeychain()
    private var webSocket: URLSessionWebSocketTask?
    private var webSocketSession: URLSession?
    private var webSocketDelegate: CTraderWebSocketDelegate?
    private var socketIsOpen = false
    private var isStoppingConnection = false
    private var receiveTask: Task<Void, Never>?
    private var heartbeatTask: Task<Void, Never>?
    private var pollTask: Task<Void, Never>?
    private var connectTimeoutTask: Task<Void, Never>?
    private var activeEnvironment: Environment = .demo
    private var pendingClientID = ""
    private var pendingClientSecret = ""
    private var activeToken = ""
    private var refreshToken = ""
    private var symbolsByID: [Int64: CTraderSymbolInfo] = [:]
    private var assetsByID: [Int64: String] = [:]
    private var depositAssetID: Int64?
    private var balanceMoneyDigits = 2
    private var pendingSignalIDs = Set<UUID>()
    private var executedSignalIDs = Set<UUID>()

    init() {
        let savedLot = defaults.double(forKey: "zk.ctrader.lotSize")
        lotSize = savedLot >= 0.01 ? min(savedLot, 1.0) : 0.01
        aiExecutionEnabled = defaults.bool(forKey: "zk.ctrader.aiExecution")
        activeEnvironment = Environment(rawValue: defaults.string(forKey: "zk.ctrader.environment") ?? "") ?? .demo
        environmentLabel = activeEnvironment.rawValue
        phase = hasSavedCredentials ? .readyToConnect : .disconnected
    }

    var isConnected: Bool { phase == .connected }
    var hasSavedCredentials: Bool {
        keychain.string(for: .clientID) != nil &&
        keychain.string(for: .clientSecret) != nil &&
        keychain.string(for: .accessToken) != nil
    }

    var selectedAccount: CTraderAccountSummary? {
        guard let selectedAccountID else { return nil }
        return accounts.first(where: { $0.id == selectedAccountID })
    }

    var canEnableAIExecution: Bool {
        isConnected && activeEnvironment == .demo && permissionCanTrade
    }

    func connect(
        clientID: String,
        clientSecret: String,
        accessToken: String,
        refreshToken: String,
        environment: Environment
    ) {
        let id = clientID.trimmingCharacters(in: .whitespacesAndNewlines)
        let secret = clientSecret.trimmingCharacters(in: .whitespacesAndNewlines)
        let token = accessToken.trimmingCharacters(in: .whitespacesAndNewlines)
        let refresh = refreshToken.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !id.isEmpty, !secret.isEmpty, !token.isEmpty else {
            fail("Client ID, client secret and access token are required.")
            return
        }

        keychain.set(id, for: .clientID)
        keychain.set(secret, for: .clientSecret)
        keychain.set(token, for: .accessToken)
        if refresh.isEmpty { keychain.delete(.refreshToken) } else { keychain.set(refresh, for: .refreshToken) }
        defaults.set(environment.rawValue, forKey: "zk.ctrader.environment")
        startConnection(clientID: id, clientSecret: secret, accessToken: token, refreshToken: refresh, environment: environment)
    }

    func connectStored() {
        guard let id = keychain.string(for: .clientID),
              let secret = keychain.string(for: .clientSecret),
              let token = keychain.string(for: .accessToken) else {
            phase = .disconnected
            errorMessage = "Enter the cTrader API credentials first."
            return
        }
        let environment = Environment(rawValue: defaults.string(forKey: "zk.ctrader.environment") ?? "") ?? .demo
        startConnection(
            clientID: id,
            clientSecret: secret,
            accessToken: token,
            refreshToken: keychain.string(for: .refreshToken) ?? "",
            environment: environment
        )
    }

    func selectAccount(_ account: CTraderAccountSummary) {
        guard account.isLive == (activeEnvironment == .live) else { return }
        selectedAccountID = account.id
        defaults.set(String(account.id), forKey: "zk.ctrader.accountID.\(activeEnvironment.rawValue)")
        accountLabel = account.label
        phase = .authorizing
        send(payloadType: 2102, payload: [
            "ctidTraderAccountId": String(account.id),
            "accessToken": activeToken
        ])
    }

    func disconnect(forgetCredentials: Bool = false) {
        stopConnection()
        clearAccountState()
        aiExecutionEnabled = false
        lastTradeStatus = "AI execution is off"
        errorMessage = ""
        if forgetCredentials {
            CTraderKeychain.Key.allCases.forEach(keychain.delete)
            phase = .disconnected
        } else {
            phase = hasSavedCredentials ? .readyToConnect : .disconnected
        }
    }

    func setAIExecution(_ enabled: Bool) {
        if enabled {
            guard canEnableAIExecution else {
                aiExecutionEnabled = false
                lastTradeStatus = activeEnvironment == .live
                    ? "Live auto-trading is locked in this build"
                    : "Demo trading permission is required"
                return
            }
            aiExecutionEnabled = true
            lastTradeStatus = "Watching for the next new ZK signal"
        } else {
            aiExecutionEnabled = false
            lastTradeStatus = "AI execution is off"
        }
    }

    func executeSignal(_ signal: PaperSignalTrade, marketSymbol: String) {
        guard aiExecutionEnabled, canEnableAIExecution,
              !pendingSignalIDs.contains(signal.id), !executedSignalIDs.contains(signal.id),
              let accountID = selectedAccountID else { return }
        guard signal.side == .buy || signal.side == .sell else { return }

        let normalized = normalizeSymbol(marketSymbol)
        guard let symbol = symbolsByID.values.first(where: { normalizeSymbol($0.name) == normalized }) else {
            lastTradeStatus = "No broker symbol found for \(marketSymbol)"
            return
        }
        guard let brokerLotSize = symbol.lotSize, brokerLotSize > 0,
              let minVolume = symbol.minVolume, let stepVolume = symbol.stepVolume, stepVolume > 0 else {
            lastTradeStatus = "Waiting for \(symbol.name) contract details"
            requestSymbolDetails(ids: [symbol.id])
            return
        }

        let requested = Int64((Double(brokerLotSize) * lotSize).rounded())
        let volume = max(minVolume, (requested / stepVolume) * stepVolume)
        let relativeSL = Int64((abs(signal.entry - signal.stopLoss) * 100_000).rounded())
        let relativeTP = Int64((abs(signal.takeProfit - signal.entry) * 100_000).rounded())
        guard relativeSL > 0, relativeTP > 0 else {
            lastTradeStatus = "Signal has invalid protection levels"
            return
        }

        pendingSignalIDs.insert(signal.id)
        lastTradeStatus = "Sending demo \(signal.side.rawValue) • \(symbol.name) • \(String(format: "%.2f", lotSize)) lot"
        send(payloadType: 2106, payload: [
            "ctidTraderAccountId": String(accountID),
            "symbolId": String(symbol.id),
            "orderType": 1,
            "tradeSide": signal.side == .buy ? 1 : 2,
            "volume": String(volume),
            "relativeStopLoss": String(relativeSL),
            "relativeTakeProfit": String(relativeTP),
            "label": "ZK AI DEMO",
            "comment": "Signal \(signal.id.uuidString.prefix(8))",
            "clientOrderId": String(signal.id.uuidString.replacingOccurrences(of: "-", with: "").prefix(32))
        ], clientMsgID: "signal:\(signal.id.uuidString)")
    }

    func refreshAccount() {
        guard isConnected, let accountID = selectedAccountID else { return }
        send(payloadType: 2121, payload: ["ctidTraderAccountId": String(accountID)])
        send(payloadType: 2124, payload: ["ctidTraderAccountId": String(accountID)])
        send(payloadType: 2187, payload: ["ctidTraderAccountId": String(accountID)])
    }

    func openOpenAPIPortal() {
        guard let url = URL(string: "https://openapi.ctrader.com/apps") else { return }
        UIApplication.shared.open(url)
    }

    private func startConnection(clientID: String, clientSecret: String, accessToken: String, refreshToken: String, environment: Environment) {
        stopConnection()
        isStoppingConnection = false
        clearAccountState()
        activeEnvironment = environment
        environmentLabel = environment.rawValue
        activeToken = accessToken
        self.refreshToken = refreshToken
        pendingClientID = clientID
        pendingClientSecret = clientSecret
        errorMessage = ""
        phase = .connecting

        guard let url = URL(string: "wss://\(environment.host):5036") else {
            fail("Invalid cTrader endpoint.")
            return
        }
        let delegate = CTraderWebSocketDelegate(owner: self)
        let session = URLSession(configuration: .default, delegate: delegate, delegateQueue: nil)
        let socket = session.webSocketTask(with: url)
        webSocketDelegate = delegate
        webSocketSession = session
        webSocket = socket
        socket.resume()

        receiveTask = Task { [weak self] in await self?.receiveLoop() }
        heartbeatTask = Task { [weak self] in await self?.heartbeatLoop() }
        connectTimeoutTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 15_000_000_000)
            guard !Task.isCancelled, let self, self.phase != .connected else { return }
            self.fail("cTrader did not finish connecting. Check the environment and credentials.")
        }

    }

    fileprivate func webSocketDidOpen() {
        guard phase == .connecting else { return }
        socketIsOpen = true
        send(payloadType: 2100, payload: [
            "clientId": pendingClientID,
            "clientSecret": pendingClientSecret
        ])
    }

    fileprivate func webSocketDidClose(reason: String?) {
        socketIsOpen = false
        guard !isStoppingConnection, phase != .disconnected, phase != .readyToConnect else { return }
        fail(reason.map { "cTrader closed the connection: \($0)" } ?? "cTrader closed the connection.")
    }

    private func receiveLoop() async {
        while !Task.isCancelled, let socket = webSocket {
            do {
                let message = try await socket.receive()
                let text: String
                switch message {
                case .string(let value): text = value
                case .data(let data): text = String(data: data, encoding: .utf8) ?? ""
                @unknown default: text = ""
                }
                if !text.isEmpty { handle(text) }
            } catch {
                if !Task.isCancelled { fail("cTrader connection closed: \(error.localizedDescription)") }
                break
            }
        }
    }

    private func heartbeatLoop() async {
        while !Task.isCancelled {
            try? await Task.sleep(nanoseconds: 10_000_000_000)
            if Task.isCancelled { return }
            send(payloadType: 51, payload: [:])
        }
    }

    private func pollLoop() async {
        while !Task.isCancelled {
            try? await Task.sleep(nanoseconds: 5_000_000_000)
            if Task.isCancelled { return }
            refreshAccount()
        }
    }

    private func handle(_ text: String) {
        guard let data = text.data(using: .utf8),
              let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let type = int(root["payloadType"]) else { return }
        let payload = root["payload"] as? [String: Any] ?? [:]

        switch type {
        case 2101:
            phase = .authorizing
            send(payloadType: 2149, payload: ["accessToken": activeToken])
        case 2150: handleAccountList(payload)
        case 2103: handleAccountAuthorized(payload)
        case 2122, 2123: handleTrader(payload)
        case 2113: handleAssets(payload)
        case 2115: handleSymbols(payload)
        case 2117: handleSymbolDetails(payload)
        case 2125: handleReconcile(payload)
        case 2188: handleUnrealizedPnL(payload)
        case 2126: handleExecution(payload, clientMsgID: root["clientMsgId"] as? String)
        case 2132: handleOrderError(payload, clientMsgID: root["clientMsgId"] as? String)
        case 2142:
            let code = string(payload["errorCode"]) ?? "API error"
            let description = string(payload["description"]) ?? ""
            fail(description.isEmpty ? code : "\(code): \(description)")
        case 2147:
            if !refreshToken.isEmpty {
                lastTradeStatus = "Refreshing cTrader access token"
                send(payloadType: 2173, payload: ["refreshToken": refreshToken])
            } else {
                fail("The access token expired. Generate a new token or add the refresh token.")
            }
        case 2174:
            if let token = string(payload["accessToken"]), let refresh = string(payload["refreshToken"]) {
                activeToken = token
                refreshToken = refresh
                keychain.set(token, for: .accessToken)
                keychain.set(refresh, for: .refreshToken)
                send(payloadType: 2149, payload: ["accessToken": token])
            }
        default: break
        }
    }

    private func handleAccountList(_ payload: [String: Any]) {
        permissionCanTrade = int(payload["permissionScope"]) == 1
        let values = payload["ctidTraderAccount"] as? [[String: Any]] ?? []
        accounts = values.compactMap { item in
            guard let id = int64(item["ctidTraderAccountId"]) else { return nil }
            return CTraderAccountSummary(
                id: id,
                login: int64(item["traderLogin"]) ?? id,
                broker: string(item["brokerTitleShort"]) ?? "cTrader",
                isLive: bool(item["isLive"]) ?? false
            )
        }
        let matching = accounts.filter { $0.isLive == (activeEnvironment == .live) }
        guard !matching.isEmpty else {
            fail("This token has no authorised \(activeEnvironment.rawValue.lowercased()) account. Re-authorise the correct account in cTrader.")
            return
        }
        let savedID = Int64(defaults.string(forKey: "zk.ctrader.accountID.\(activeEnvironment.rawValue)") ?? "")
        selectAccount(matching.first(where: { $0.id == savedID }) ?? matching[0])
    }

    private func handleAccountAuthorized(_ payload: [String: Any]) {
        guard let id = int64(payload["ctidTraderAccountId"]), id == selectedAccountID else { return }
        phase = .connected
        connectTimeoutTask?.cancel()
        lastTradeStatus = aiExecutionEnabled ? "Watching for the next new ZK signal" : "AI execution is off"
        send(payloadType: 2121, payload: ["ctidTraderAccountId": String(id)])
        send(payloadType: 2112, payload: ["ctidTraderAccountId": String(id)])
        send(payloadType: 2114, payload: ["ctidTraderAccountId": String(id), "includeArchivedSymbols": false])
        send(payloadType: 2124, payload: ["ctidTraderAccountId": String(id)])
        send(payloadType: 2187, payload: ["ctidTraderAccountId": String(id)])
        pollTask?.cancel()
        pollTask = Task { [weak self] in await self?.pollLoop() }
    }

    private func handleTrader(_ payload: [String: Any]) {
        guard let trader = payload["trader"] as? [String: Any] else { return }
        balanceMoneyDigits = int(trader["moneyDigits"]) ?? 2
        if let raw = int64(trader["balance"]) { balance = money(raw, digits: balanceMoneyDigits) }
        if let leverageCents = int(trader["leverageInCents"]) { leverage = leverageCents / 100 }
        if let assetID = int64(trader["depositAssetId"]) {
            depositAssetID = assetID
            currency = assetsByID[assetID] ?? currency
        }
        if let broker = string(trader["brokerName"]), let account = selectedAccount {
            accountLabel = "\(broker) • \(account.isLive ? "Live" : "Demo") • \(account.login)"
        }
    }

    private func handleAssets(_ payload: [String: Any]) {
        let values = payload["asset"] as? [[String: Any]] ?? []
        for item in values {
            if let id = int64(item["assetId"]), let name = string(item["displayName"]) ?? string(item["name"]) {
                assetsByID[id] = name
            }
        }
        if let depositAssetID, let name = assetsByID[depositAssetID] { currency = name }
    }

    private func handleSymbols(_ payload: [String: Any]) {
        let values = payload["symbol"] as? [[String: Any]] ?? []
        for item in values {
            guard let id = int64(item["symbolId"]), let name = string(item["symbolName"]) else { continue }
            symbolsByID[id] = CTraderSymbolInfo(id: id, name: name, minVolume: nil, stepVolume: nil, lotSize: nil)
        }
        positions = positions.map { position in
            var updated = position
            updated.symbol = symbolsByID[position.symbolID]?.name ?? position.symbol
            return updated
        }
        let watchlist = Set(TradeMarket.watchlist.map { normalizeSymbol($0.symbol) })
        let ids = symbolsByID.values.filter { watchlist.contains(normalizeSymbol($0.name)) }.map(\.id)
        requestSymbolDetails(ids: ids)
    }

    private func requestSymbolDetails(ids: [Int64]) {
        guard let accountID = selectedAccountID, !ids.isEmpty else { return }
        send(payloadType: 2116, payload: [
            "ctidTraderAccountId": String(accountID),
            "symbolId": ids.map(String.init)
        ])
    }

    private func handleSymbolDetails(_ payload: [String: Any]) {
        let values = payload["symbol"] as? [[String: Any]] ?? []
        for item in values {
            guard let id = int64(item["symbolId"]), var existing = symbolsByID[id] else { continue }
            existing.minVolume = int64(item["minVolume"])
            existing.stepVolume = int64(item["stepVolume"])
            existing.lotSize = int64(item["lotSize"])
            symbolsByID[id] = existing
        }
    }

    private func handleReconcile(_ payload: [String: Any]) {
        let values = payload["position"] as? [[String: Any]] ?? []
        let pnl = Dictionary(uniqueKeysWithValues: positions.compactMap { item in item.netProfit.map { (item.id, $0) } })
        positions = values.compactMap { item in
            guard let id = int64(item["positionId"]),
                  let trade = item["tradeData"] as? [String: Any],
                  let symbolID = int64(trade["symbolId"]) else { return nil }
            return CTraderPositionSummary(
                id: id,
                symbolID: symbolID,
                symbol: symbolsByID[symbolID]?.name ?? "#\(symbolID)",
                side: int(trade["tradeSide"]) == 1 ? "BUY" : "SELL",
                volume: Double(int64(trade["volume"]) ?? 0) / 100.0,
                entryPrice: double(item["price"]) ?? 0,
                stopLoss: double(item["stopLoss"]),
                takeProfit: double(item["takeProfit"]),
                netProfit: pnl[id]
            )
        }
        pendingOrderCount = (payload["order"] as? [[String: Any]] ?? []).count
    }

    private func handleUnrealizedPnL(_ payload: [String: Any]) {
        let digits = int(payload["moneyDigits"]) ?? balanceMoneyDigits
        let values = payload["positionUnrealizedPnL"] as? [[String: Any]] ?? []
        let pnlByID: [Int64: Double] = Dictionary(uniqueKeysWithValues: values.compactMap { item in
            guard let id = int64(item["positionId"]), let raw = int64(item["netUnrealizedPnL"]) else { return nil }
            return (id, money(raw, digits: digits))
        })
        positions = positions.map { item in
            var updated = item
            updated.netProfit = pnlByID[item.id]
            return updated
        }
        if let balance { equity = balance + pnlByID.values.reduce(0, +) }
    }

    private func handleExecution(_ payload: [String: Any], clientMsgID: String?) {
        if let signalID = signalID(from: clientMsgID) {
            pendingSignalIDs.remove(signalID)
            let executionType = int(payload["executionType"]) ?? 0
            if executionType == 3 || executionType == 11 {
                executedSignalIDs.insert(signalID)
                lastTradeStatus = "Demo order filled by cTrader"
            } else if executionType == 7 {
                lastTradeStatus = "Order rejected: \(string(payload["errorCode"]) ?? "unknown reason")"
            } else {
                lastTradeStatus = "Order accepted by cTrader"
            }
        }
        refreshAccount()
    }

    private func handleOrderError(_ payload: [String: Any], clientMsgID: String?) {
        if let signalID = signalID(from: clientMsgID) { pendingSignalIDs.remove(signalID) }
        let code = string(payload["errorCode"]) ?? "ORDER_ERROR"
        let description = string(payload["description"]) ?? ""
        lastTradeStatus = description.isEmpty ? code : "\(code): \(description)"
    }

    private func send(payloadType: Int, payload: [String: Any], clientMsgID: String = UUID().uuidString) {
        guard socketIsOpen, let socket = webSocket else { return }
        let object: [String: Any] = ["clientMsgId": clientMsgID, "payloadType": payloadType, "payload": payload]
        guard let data = try? JSONSerialization.data(withJSONObject: object),
              let text = String(data: data, encoding: .utf8) else { return }
        Task {
            do { try await socket.send(.string(text)) }
            catch { if phase != .disconnected { fail("Could not send to cTrader: \(error.localizedDescription)") } }
        }
    }

    private func stopConnection() {
        isStoppingConnection = true
        socketIsOpen = false
        connectTimeoutTask?.cancel(); connectTimeoutTask = nil
        pollTask?.cancel(); pollTask = nil
        heartbeatTask?.cancel(); heartbeatTask = nil
        receiveTask?.cancel(); receiveTask = nil
        webSocket?.cancel(with: .goingAway, reason: nil)
        webSocket = nil
        webSocketSession?.invalidateAndCancel()
        webSocketSession = nil
        webSocketDelegate?.owner = nil
        webSocketDelegate = nil
    }

    private func clearAccountState() {
        accounts = []
        selectedAccountID = nil
        accountLabel = ""
        balance = nil
        equity = nil
        leverage = nil
        positions = []
        pendingOrderCount = 0
        permissionCanTrade = false
        symbolsByID = [:]
        assetsByID = [:]
        pendingSignalIDs = []
    }

    private func fail(_ message: String) {
        errorMessage = message
        phase = .failed
        aiExecutionEnabled = false
    }

    private func signalID(from clientMsgID: String?) -> UUID? {
        guard let clientMsgID, clientMsgID.hasPrefix("signal:") else { return nil }
        return UUID(uuidString: String(clientMsgID.dropFirst(7)))
    }

    private func normalizeSymbol(_ value: String) -> String { value.uppercased().filter(\.isLetter) }
    private func money(_ raw: Int64, digits: Int) -> Double { Double(raw) / pow(10.0, Double(digits)) }

    private func int(_ value: Any?) -> Int? {
        if let value = value as? Int { return value }
        if let value = value as? NSNumber { return value.intValue }
        if let value = value as? String { return Int(value) }
        return nil
    }

    private func int64(_ value: Any?) -> Int64? {
        if let value = value as? Int64 { return value }
        if let value = value as? NSNumber { return value.int64Value }
        if let value = value as? String { return Int64(value) }
        return nil
    }

    private func double(_ value: Any?) -> Double? {
        if let value = value as? Double { return value }
        if let value = value as? NSNumber { return value.doubleValue }
        if let value = value as? String { return Double(value) }
        return nil
    }

    private func bool(_ value: Any?) -> Bool? {
        if let value = value as? Bool { return value }
        if let value = value as? NSNumber { return value.boolValue }
        if let value = value as? String { return value == "true" || value == "1" }
        return nil
    }

    private func string(_ value: Any?) -> String? {
        if let value = value as? String { return value }
        if let value = value as? NSNumber { return value.stringValue }
        return nil
    }
}

private final class CTraderWebSocketDelegate: NSObject, URLSessionWebSocketDelegate {
    weak var owner: CTraderConnectionService?

    init(owner: CTraderConnectionService) {
        self.owner = owner
    }

    func urlSession(
        _ session: URLSession,
        webSocketTask: URLSessionWebSocketTask,
        didOpenWithProtocol protocol: String?
    ) {
        Task { @MainActor [weak owner] in owner?.webSocketDidOpen() }
    }

    func urlSession(
        _ session: URLSession,
        webSocketTask: URLSessionWebSocketTask,
        didCloseWith closeCode: URLSessionWebSocketTask.CloseCode,
        reason: Data?
    ) {
        let message = reason.flatMap { String(data: $0, encoding: .utf8) }
        Task { @MainActor [weak owner] in owner?.webSocketDidClose(reason: message) }
    }
}

private struct CTraderKeychain {
    enum Key: String, CaseIterable {
        case clientID = "client-id"
        case clientSecret = "client-secret"
        case accessToken = "access-token"
        case refreshToken = "refresh-token"
    }

    private let service = "com.zk.goldai.native.ctrader"

    func set(_ value: String, for key: Key) {
        guard let data = value.data(using: .utf8) else { return }
        let base: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key.rawValue
        ]
        SecItemDelete(base as CFDictionary)
        var insert = base
        insert[kSecValueData as String] = data
        insert[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        SecItemAdd(insert as CFDictionary, nil)
    }

    func string(for key: Key) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key.rawValue,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: AnyObject?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    func delete(_ key: Key) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key.rawValue
        ]
        SecItemDelete(query as CFDictionary)
    }
}
