import SwiftUI

struct ChatView: View {
    @EnvironmentObject private var state: AppState
    @EnvironmentObject private var market: MarketDataService
    @EnvironmentObject private var ai: LocalAIService
    @Environment(\.zkScale) private var scale
    @State private var input = ""
    @State private var showHistory = false
    @FocusState private var composerFocused: Bool

    var body: some View {
        VStack(spacing: 8 * scale) {
            ZKPageHeader(
                micro: "LOCAL AGENT • TOOLS • MEMORY",
                title: "ZK Agent",
                pill: ai.shortStatus,
                pillColor: aiColor
            )

            conversationBar
            aiStatusCard
            agentActivity
            messages.frame(maxHeight: .infinity)
            chips
            composer
        }
        .padding(.horizontal, 16 * scale)
        .padding(.top, 8 * scale)
        .padding(.bottom, 8 * scale)
        .background(ZKTheme.background)
        .contentShape(Rectangle())
        .onTapGesture { composerFocused = false }
        .sheet(isPresented: $showHistory) { ChatHistorySheet().environmentObject(state) }
        .task {
            if ai.isInstalled && !ai.isReady && !ai.isBusy { await ai.loadModel() }
            consumePendingPrompt()
        }
        .onChange(of: state.pendingChatPrompt) { consumePendingPrompt() }
    }

    private var conversationBar: some View {
        HStack(spacing: 7 * scale) {
            VStack(alignment: .leading, spacing: 2 * scale) {
                Text("CURRENT CHAT")
                    .font(.system(size: 6.5 * scale, weight: .black))
                    .foregroundStyle(ZKTheme.textMuted)
                Text(state.currentThread?.title ?? "New analysis")
                    .font(.system(size: 9 * scale, weight: .bold))
                    .lineLimit(1)
            }
            Spacer()
            Button { showHistory = true } label: {
                Label("HISTORY", systemImage: "clock.arrow.circlepath")
                    .font(.system(size: 7.5 * scale, weight: .black))
                    .foregroundStyle(ZKTheme.textSoft)
                    .padding(.horizontal, 9 * scale)
                    .frame(height: 29 * scale)
                    .background(ZKTheme.card)
                    .overlay(Capsule().stroke(ZKTheme.border))
                    .clipShape(Capsule())
            }
            .buttonStyle(ZKPressStyle())

            Button { state.newChat() } label: {
                Image(systemName: "square.and.pencil")
                    .font(.system(size: 11 * scale, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 29 * scale, height: 29 * scale)
                    .background(ZKTheme.accentGradient)
                    .clipShape(Circle())
            }
            .buttonStyle(ZKPressStyle())
        }
        .padding(.horizontal, 10 * scale)
        .frame(height: 39 * scale)
        .background(ZKTheme.card.opacity(0.72))
        .overlay(RoundedRectangle(cornerRadius: 11 * scale).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 11 * scale))
    }

    private var aiStatusCard: some View {
        ZKCard(strongBorder: true) {
            VStack(spacing: 8 * scale) {
                HStack(spacing: 10 * scale) {
                    ZStack {
                        Circle().fill(aiColor.opacity(0.12)).frame(width: 39 * scale, height: 39 * scale)
                        Image(systemName: ai.isReady ? "brain.head.profile.fill" : "arrow.down.circle.fill")
                            .font(.system(size: 18 * scale, weight: .bold)).foregroundStyle(aiColor)
                    }
                    VStack(alignment: .leading, spacing: 2 * scale) {
                        Text(ai.modelName).font(.system(size: 10.5 * scale, weight: .black))
                        Text(ai.statusDetail)
                            .font(.system(size: 8 * scale, weight: .medium))
                            .foregroundStyle(ZKTheme.textMuted)
                            .lineLimit(2)
                    }
                    Spacer(minLength: 4)
                }

                if case .downloading = ai.state {
                    VStack(spacing: 4 * scale) {
                        ProgressView(value: ai.downloadProgress).tint(ZKTheme.purple)
                        HStack { Text("\(Int(ai.downloadProgress * 100))%"); Spacer(); Text("KEEP APP OPEN").foregroundStyle(ZKTheme.textMuted) }
                            .font(.system(size: 7.5 * scale, weight: .black))
                    }
                } else if case .verifying = ai.state {
                    HStack(spacing: 7 * scale) {
                        ProgressView().tint(ZKTheme.gold)
                        Text("VERIFYING MODEL").font(.system(size: 8 * scale, weight: .black)).foregroundStyle(ZKTheme.gold)
                        Spacer()
                    }
                } else if !ai.isInstalled {
                    Button { ai.downloadModel() } label: {
                        Label("DOWNLOAD \(ai.modelShortName) • \(downloadSizeText)", systemImage: "arrow.down.circle.fill")
                            .font(.system(size: 8.5 * scale, weight: .black))
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity, minHeight: 37 * scale)
                            .background(ZKTheme.accentGradient)
                            .clipShape(RoundedRectangle(cornerRadius: 11 * scale))
                    }
                    .buttonStyle(ZKPressStyle())
                } else if !ai.isReady && !ai.isBusy {
                    Button { Task { await ai.loadModel() } } label: {
                        Label("LOAD \(ai.modelShortName)", systemImage: "bolt.fill")
                            .font(.system(size: 8.5 * scale, weight: .black))
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity, minHeight: 36 * scale)
                            .background(ZKTheme.accentGradient)
                            .clipShape(RoundedRectangle(cornerRadius: 11 * scale))
                    }
                    .buttonStyle(ZKPressStyle())
                }

                HStack(spacing: 6 * scale) {
                    contextBadge("CHART", market.candles.isEmpty ? "WAIT" : "1M LIVE", market.candles.isEmpty ? ZKTheme.gold : ZKTheme.green)
                    contextBadge("TOOLS", "AGENT", ZKTheme.purple)
                    contextBadge("MEMORY", "LOCAL", ZKTheme.green)
                    contextBadge("MODEL", ai.selectedTier == .smart ? "SMART" : "FAST", ai.selectedTier == .smart ? ZKTheme.gold : ZKTheme.textSoft)
                }

                HStack {
                    Text("RUNTIME CHECKPOINT").font(.system(size: 6 * scale, weight: .black)).foregroundStyle(ZKTheme.textMuted)
                    Spacer()
                    Text(ai.lastInferenceCheckpoint).font(.system(size: 6.5 * scale, weight: .black, design: .monospaced)).foregroundStyle(ZKTheme.textSoft).lineLimit(1)
                }
            }
        }
    }

    @ViewBuilder
    private var agentActivity: some View {
        if !state.agentSteps.isEmpty {
            VStack(alignment: .leading, spacing: 5 * scale) {
                HStack {
                    Text(ai.state == .generating ? "AGENT WORKING" : "LAST AGENT RUN")
                        .font(.system(size: 7 * scale, weight: .black)).tracking(0.6).foregroundStyle(ZKTheme.textSoft)
                    Spacer()
                    Text("\(state.agentSteps.filter { $0.status == .complete }.count)/\(state.agentSteps.count)")
                        .font(.system(size: 7 * scale, weight: .black, design: .monospaced)).foregroundStyle(ZKTheme.textMuted)
                }
                ForEach(state.agentSteps) { step in
                    HStack(spacing: 7 * scale) {
                        Image(systemName: icon(for: step.status))
                            .font(.system(size: 8 * scale, weight: .bold))
                            .foregroundStyle(color(for: step.status))
                            .frame(width: 13 * scale)
                        VStack(alignment: .leading, spacing: 1 * scale) {
                            Text(step.title).font(.system(size: 8 * scale, weight: .bold))
                            Text(step.detail).font(.system(size: 6.8 * scale, weight: .medium)).foregroundStyle(ZKTheme.textMuted).lineLimit(1)
                        }
                        Spacer()
                    }
                }
            }
            .padding(9 * scale)
            .background(Color(red: 0.035, green: 0.027, blue: 0.051))
            .overlay(RoundedRectangle(cornerRadius: 12 * scale).stroke(ZKTheme.border))
            .clipShape(RoundedRectangle(cornerRadius: 12 * scale))
        }
    }

    private func contextBadge(_ title: String, _ value: String, _ color: Color) -> some View {
        VStack(spacing: 2 * scale) {
            Text(title).font(.system(size: 6 * scale, weight: .black)).foregroundStyle(ZKTheme.textMuted)
            Text(value).font(.system(size: 7.5 * scale, weight: .black)).foregroundStyle(color).lineLimit(1).minimumScaleFactor(0.7)
        }
        .frame(maxWidth: .infinity).padding(.vertical, 5 * scale)
        .background(Color.black.opacity(0.16))
        .overlay(RoundedRectangle(cornerRadius: 8 * scale).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 8 * scale))
    }

    private var messages: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 9 * scale) {
                    ForEach(state.chatMessages) { message in bubble(message).id(message.id) }
                }
                .padding(.vertical, 3 * scale)
            }
            .scrollDismissesKeyboard(.interactively)
            .scrollIndicators(.hidden)
            .onChange(of: state.chatMessages) {
                if let last = state.chatMessages.last {
                    withAnimation(.easeOut(duration: 0.16)) { proxy.scrollTo(last.id, anchor: .bottom) }
                }
            }
        }
    }

    private func bubble(_ msg: ChatMessage) -> some View {
        HStack {
            if msg.role == .user { Spacer(minLength: 42 * scale) }
            VStack(alignment: .leading, spacing: 5 * scale) {
                HStack(spacing: 5 * scale) {
                    Text(msg.role == .user ? "YOU" : "ZK AGENT")
                        .font(.system(size: 8 * scale, weight: .black)).tracking(0.6)
                    if msg.role == .assistant && ai.state == .generating && msg.id == state.chatMessages.last?.id {
                        ProgressView().controlSize(.mini).tint(ZKTheme.purple)
                    }
                }
                .foregroundStyle(msg.role == .user ? Color(red: 0.831, green: 0.478, blue: 0.894) : ZKTheme.textMuted)

                if msg.text.isEmpty {
                    Text("Reasoning locally…").font(.system(size: 11 * scale, weight: .medium)).foregroundStyle(ZKTheme.textMuted)
                } else {
                    Text(msg.text)
                        .font(.system(size: 12 * scale, weight: .medium))
                        .foregroundStyle(.white.opacity(0.92))
                        .lineSpacing(2.2 * scale)
                        .textSelection(.enabled)
                }
            }
            .padding(12 * scale)
            .background(msg.role == .user ? Color(red: 0.086, green: 0.051, blue: 0.110) : ZKTheme.card)
            .overlay(RoundedRectangle(cornerRadius: 15 * scale).stroke(msg.role == .user ? ZKTheme.borderStrong : ZKTheme.border))
            .clipShape(RoundedRectangle(cornerRadius: 15 * scale))
            if msg.role == .assistant { Spacer(minLength: 42 * scale) }
        }
    }

    private var chips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 7 * scale) {
                chip("Analyse gold like an agent")
                chip("What matters right now?")
                chip("Check 1M 5M 15M structure")
                chip("Mark key levels")
                chip("Explain liquidity")
                chip("Open Signal")
                chip("Backtest status")
            }
            .padding(.horizontal, 1)
        }
        .frame(height: 36 * scale)
    }

    private func chip(_ text: String) -> some View {
        Button { send(text) } label: {
            Text(text).font(.system(size: 9 * scale, weight: .bold)).foregroundStyle(ZKTheme.textSoft)
                .padding(.horizontal, 11 * scale).frame(height: 31 * scale)
                .background(ZKTheme.card).overlay(Capsule().stroke(ZKTheme.border)).clipShape(Capsule())
        }
        .buttonStyle(ZKPressStyle()).disabled(ai.state == .generating)
    }

    private var composer: some View {
        HStack(spacing: 7 * scale) {
            TextField(ai.isInstalled ? "Tell ZK Agent what you want it to investigate…" : "Download a local model to start…", text: $input, axis: .vertical)
                .focused($composerFocused)
                .font(.system(size: 12 * scale, weight: .medium))
                .padding(.horizontal, 12 * scale).padding(.vertical, 8 * scale)
                .frame(minHeight: 46 * scale, maxHeight: 92 * scale)
                .background(ZKTheme.card)
                .overlay(RoundedRectangle(cornerRadius: 14 * scale).stroke(ZKTheme.borderStrong))
                .clipShape(RoundedRectangle(cornerRadius: 14 * scale))
                .submitLabel(.send).onSubmit { send() }.disabled(ai.state == .generating)

            Button(action: send) {
                Image(systemName: ai.state == .generating ? "ellipsis" : "arrow.up")
                    .font(.system(size: 18 * scale, weight: .black)).foregroundStyle(.white)
                    .frame(width: 46 * scale, height: 46 * scale)
                    .background(ai.state == .generating ? AnyShapeStyle(ZKTheme.card2) : AnyShapeStyle(ZKTheme.accentGradient))
                    .clipShape(RoundedRectangle(cornerRadius: 14 * scale))
            }
            .buttonStyle(ZKPressStyle()).disabled(ai.state == .generating)
        }
    }

    private func send() { send(input) }

    private func send(_ supplied: String) {
        let text = supplied.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        input = ""; composerFocused = false

        guard ai.isInstalled else {
            state.appendUserMessage(text)
            state.appendAssistantMessage("Download the selected local model above first. FAST is the proven lightweight model; SMART is the optional stronger 1.5B model in Settings.")
            return
        }
        guard ai.state != .generating else { return }

        Task {
            state.appendUserMessage(text)
            let preparation = await ZKAgentCoordinator.prepare(query: text, state: state, market: market)
            let history = state.chatMessages
            let responseID = state.appendAssistantMessage()
            do {
                try await ai.generate(appContext: preparation.context, conversation: history) { token in
                    state.appendToAssistantMessage(id: responseID, token: token)
                }
                if state.chatMessages.first(where: { $0.id == responseID })?.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == true {
                    state.replaceAssistantMessage(id: responseID, text: "I completed the agent checks but didn't produce a usable local-model response. Try the same request again or switch model tier in Settings.")
                }
            } catch {
                state.replaceAssistantMessage(id: responseID, text: "Local agent error: \(error.localizedDescription)")
            }
        }
    }

    private func consumePendingPrompt() {
        guard let prompt = state.pendingChatPrompt?.trimmingCharacters(in: .whitespacesAndNewlines), !prompt.isEmpty else { return }
        state.pendingChatPrompt = nil
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) { send(prompt) }
    }

    private var downloadSizeText: String { ai.selectedTier == .smart ? "~924 MB" : "~491 MB" }

    private func icon(for status: AgentStep.Status) -> String {
        switch status { case .queued: return "circle"; case .running: return "ellipsis.circle.fill"; case .complete: return "checkmark.circle.fill"; case .skipped: return "minus.circle" }
    }

    private func color(for status: AgentStep.Status) -> Color {
        switch status { case .queued: return ZKTheme.textMuted; case .running: return ZKTheme.gold; case .complete: return ZKTheme.green; case .skipped: return ZKTheme.textMuted }
    }

    private var aiColor: Color {
        switch ai.state {
        case .ready, .generating: return ZKTheme.green
        case .downloading, .verifying, .loading, .downloaded: return ZKTheme.gold
        case .failed: return ZKTheme.red
        case .notDownloaded: return ZKTheme.purple
        }
    }
}

private struct ChatHistorySheet: View {
    @EnvironmentObject private var state: AppState
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                ForEach(state.chatThreads) { thread in
                    Button {
                        state.selectChat(thread.id)
                        dismiss()
                    } label: {
                        VStack(alignment: .leading, spacing: 4) {
                            HStack {
                                Text(thread.title).font(.headline).foregroundStyle(.primary).lineLimit(1)
                                Spacer()
                                if thread.id == state.currentThreadID { Image(systemName: "checkmark.circle.fill").foregroundStyle(.purple) }
                            }
                            Text("\(thread.messages.count) messages • \(thread.updatedAt.formatted(date: .abbreviated, time: .shortened))")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    .swipeActions {
                        Button(role: .destructive) { state.deleteChat(thread.id) } label: { Label("Delete", systemImage: "trash") }
                    }
                }
            }
            .navigationTitle("Agent conversations")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Done") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { state.newChat(); dismiss() } label: { Image(systemName: "square.and.pencil") }
                }
            }
        }
        .preferredColorScheme(.dark)
    }
}
