import Foundation

struct AgentPreparation {
    let context: String
    let toolNote: String?
}

@MainActor
enum ZKAgentCoordinator {
    static func prepare(query: String, state: AppState, market: MarketDataService) async -> AgentPreparation {
        let q = query.lowercased()
        state.setAgentSteps([
            AgentStep(title: "Read live chart", detail: "Inspecting the exact custom 1M candle array shown on Signal.", status: .running),
            AgentStep(title: "Check structure", detail: "Building 1M / 5M / 15M structure, BOS/CHOCH and momentum context.", status: .queued),
            AgentStep(title: "Map levels + liquidity", detail: "Finding chart-derived S/R, sweeps, equal highs/lows and FVG context.", status: .queued),
            AgentStep(title: "Use app tools", detail: "Checking whether the request needs a chart/app action.", status: .queued),
            AgentStep(title: "Verify conclusion", detail: "Reconciling evidence before handing it to the local language model.", status: .queued)
        ])

        if market.candles.isEmpty {
            await market.refreshAll()
        }
        let chart = ChartIntelligenceEngine.snapshot(candles: market.candles, currentPrice: market.currentPrice)
        state.updateAgentStep(index: 0, status: market.candles.isEmpty ? .skipped : .complete, detail: market.candles.isEmpty ? "No machine-readable candles available." : "Read \(market.candles.count) 1M candles and \(market.recentTicks.count) recent quote updates.")

        state.updateAgentStep(index: 1, status: .running)
        await Task.yield()
        state.updateAgentStep(index: 1, status: .complete, detail: "Structure: \(chart.trend1m) 1M • \(chart.trend5m) 5M • \(chart.trend15m) 15M • \(chart.structure).")

        state.updateAgentStep(index: 2, status: .running)
        await Task.yield()
        let supportText = chart.support.map { String(format: "%.2f", $0.price) } ?? "n/a"
        let resistanceText = chart.resistance.map { String(format: "%.2f", $0.price) } ?? "n/a"
        state.updateAgentStep(index: 2, status: .complete, detail: "Nearest chart levels: support \(supportText), resistance \(resistanceText).")

        state.updateAgentStep(index: 3, status: .running)
        let toolNote = await AIToolRouter.execute(query: query, state: state, market: market)
        state.updateAgentStep(index: 3, status: toolNote == nil ? .skipped : .complete, detail: toolNote ?? "No app mutation was needed for this request.")

        state.updateAgentStep(index: 4, status: .running)
        await Task.yield()
        let evidence = verificationEvidence(query: q, chart: chart, market: market)
        state.updateAgentStep(index: 4, status: .complete, detail: evidence)

        let base = AIAppContextBuilder.build(state: state, market: market, query: query, toolNote: toolNote)
        let tickWindow = market.recentTicks.suffix(14).map { tick in
            "\(time(tick.timestamp))=\(String(format: "%.2f", tick.price))"
        }.joined(separator: ", ")
        let candleWindow = market.candles.suffix(10).map { c in
            "\(time(c.timestamp)) O\(fmt(c.open)) H\(fmt(c.high)) L\(fmt(c.low)) C\(fmt(c.close))"
        }.joined(separator: " | ")

        let context = """
        \(base)
        AGENT REQUEST: \(query)
        SIGNAL CHART: custom ZK 1M chart; this exact candle array is what the agent reads. Exact IC Markets/TradingView parity=false until broker-authorized stream is connected.
        RECENT 1M WINDOW: \(candleWindow.isEmpty ? "unavailable" : candleWindow)
        RECENT QUOTE UPDATES: \(tickWindow.isEmpty ? "unavailable" : tickWindow)
        VERIFICATION: \(evidence)
        """
        return AgentPreparation(context: context, toolNote: toolNote)
    }

    private static func verificationEvidence(query: String, chart: ChartIntelligenceSnapshot, market: MarketDataService) -> String {
        guard !market.candles.isEmpty else { return "Evidence incomplete: no candles loaded." }
        var checks: [String] = []
        checks.append("price source \(market.feedStatus.rawValue.lowercased())")
        checks.append("MTF \(chart.trend1m)/\(chart.trend5m)/\(chart.trend15m)")
        checks.append("structure \(chart.structure)")
        if query.contains("trade") || query.contains("buy") || query.contains("sell") || query.contains("entry") {
            checks.append("trading model not trained: no validated signal may be invented")
        }
        return checks.joined(separator: "; ")
    }

    private static func fmt(_ x: Double) -> String { String(format: "%.2f", x) }
    private static func time(_ date: Date) -> String {
        let formatter = DateFormatter(); formatter.dateFormat = "HH:mm:ss"; return formatter.string(from: date)
    }
}
