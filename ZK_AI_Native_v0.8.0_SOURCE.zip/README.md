# ZK AI Native v0.8.0 — Agent + Custom Signal Chart

This build turns the local chat layer into a persistent app-aware agent and makes Signal use a custom machine-readable 1-minute chart that ZK Agent can inspect directly.

## ZK Agent
- Planner → app tools → verification → local language-model response.
- Agent activity strip shows the actual stages being checked.
- Persistent local conversations survive app relaunches.
- New Chat + conversation history + delete/switch chat.
- Every turn receives current app state, the exact custom Signal candle array, recent quote updates, chart-intelligence output, drawings, signal state, model state and app-tool results.
- App tools can draw/remove levels, clear drawings, refresh market data and navigate to Chart/Signal/Backtest/Settings.
- The future numerical trading model remains separate and authoritative; chat does not invent validated BUY/SELL probabilities.

## Local model choices
- FAST: Qwen2.5 0.5B Q4_K_M (~491 MB), the existing proven lightweight model.
- SMART: optional Qwen2.5 1.5B Q3_K_M (~924 MB), a stronger local conversational/reasoning model with conservative iPhone memory settings.
- Both use the proven v0.6.4 stability path: greedy sampling, 64-token physical batches, CPU mode and bounded prompt/context sizes.
- Model files are downloaded by the user after installation and are not included in the IPA.

## Custom Signal 1M chart
- Signal no longer depends on the TradingView iframe for its primary chart.
- The custom chart uses the same `[ChartCandle]` array that ZK Agent analyses.
- Each newly received quote is recorded, and a changed quote updates the active 1-minute OHLC candle immediately.
- Recent quote updates are also passed to the agent as a micro-movement window.
- Pan, pinch, candle inspection, drawings and live-price line remain native SwiftUI/Canvas.
- TradingView `ICMARKETS:XAUUSD` remains available on the Chart tab as the visual reference.

## Important broker-feed boundary
The current machine-readable source is still a reference feed. It is **not** the private TradingView candle stream and is **not** yet an authenticated IC Markets executable quote feed. Therefore the custom chart cannot honestly be guaranteed candle-for-candle identical to `ICMARKETS:XAUUSD` yet.

The chart/agent architecture is now ready for the correct next data step: plug an authorized IC Markets/cTrader live quote + M1 trendbar stream into `MarketDataService`. Once that is connected, Signal, ZK Agent and the custom chart can all consume the same broker stream.
