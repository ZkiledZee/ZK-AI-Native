import SwiftUI

@main
struct ZKAINativeApp: App {
    @StateObject private var state = AppState()
    @StateObject private var market = MarketDataService()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(state)
                .environmentObject(market)
                .preferredColorScheme(.dark)
                .task {
                    market.start()
                }
        }
    }
}
