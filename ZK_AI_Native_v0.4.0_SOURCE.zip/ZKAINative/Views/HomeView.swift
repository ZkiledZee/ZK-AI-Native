import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var state: AppState
    @EnvironmentObject private var market: MarketDataService
    @Environment(\.zkScale) private var scale
    @State private var drift = false

    var body: some View {
        ScrollView {
            VStack(spacing: 12 * scale) {
                topBar
                marketHero
                marketStats
                systemStrip
                quickActions
                dataCard
            }
            .padding(.horizontal, 16 * scale)
            .padding(.top, 10 * scale)
            .padding(.bottom, 18 * scale)
        }
        .scrollIndicators(.hidden)
        .refreshable { await market.refreshAll() }
        .background {
            ZStack {
                ZKTheme.background
                ambient
            }
            .ignoresSafeArea()
        }
    }

    private var topBar: some View {
        HStack(spacing: 11 * scale) {
            HomeLogo()
                .scaleEffect(0.72)
                .frame(width: 56 * scale, height: 56 * scale)

            VStack(alignment: .leading, spacing: 2 * scale) {
                ZKMicroLabel(text: "XAUUSD • MARKET TERMINAL")
                Text("ZK AI")
                    .font(.system(size: 24 * scale, weight: .black, design: .rounded))
                    .tracking(-0.6 * scale)
                Text("Live market layer • AI comes next")
                    .font(.system(size: 10.5 * scale, weight: .medium))
                    .foregroundStyle(ZKTheme.textMuted)
            }

            Spacer(minLength: 6)
            ZKDataPill(text: market.feedStatus.rawValue, color: feedColor)
        }
    }

    private var marketHero: some View {
        VStack(alignment: .leading, spacing: 11 * scale) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 4 * scale) {
                    HStack(spacing: 7 * scale) {
                        Text("XAU / USD")
                            .font(.system(size: 12 * scale, weight: .black, design: .rounded))
                        Text("SPOT")
                            .font(.system(size: 7.5 * scale, weight: .black, design: .rounded))
                            .foregroundStyle(ZKTheme.gold)
                            .padding(.horizontal, 7 * scale)
                            .padding(.vertical, 4 * scale)
                            .background(ZKTheme.gold.opacity(0.08))
                            .overlay(Capsule().stroke(ZKTheme.gold.opacity(0.28)))
                            .clipShape(Capsule())
                    }

                    Text(priceText)
                        .font(.system(size: 34 * scale, weight: .black, design: .rounded))
                        .tracking(-1.2 * scale)
                        .contentTransition(.numericText())
                        .minimumScaleFactor(0.75)
                        .lineLimit(1)

                    HStack(spacing: 8 * scale) {
                        Text(changeText)
                            .font(.system(size: 10.5 * scale, weight: .black, design: .monospaced))
                            .foregroundStyle(changeColor)
                        Text(market.freshnessText)
                            .font(.system(size: 9 * scale, weight: .semibold))
                            .foregroundStyle(ZKTheme.textMuted)
                    }
                }

                Spacer()

                Button {
                    Task { await market.refreshAll() }
                } label: {
                    Image(systemName: market.isRefreshing ? "arrow.triangle.2.circlepath" : "arrow.clockwise")
                        .font(.system(size: 14 * scale, weight: .bold))
                        .foregroundStyle(market.isRefreshing ? ZKTheme.gold : ZKTheme.textSoft)
                        .frame(width: 36 * scale, height: 36 * scale)
                        .background(ZKTheme.card)
                        .overlay(Circle().stroke(ZKTheme.borderStrong))
                        .clipShape(Circle())
                        .rotationEffect(.degrees(market.isRefreshing ? 180 : 0))
                        .animation(.easeInOut(duration: 0.35), value: market.isRefreshing)
                }
                .buttonStyle(ZKPressStyle())
            }

            MiniMarketChart(candles: market.candles)
                .frame(height: 78 * scale)
                .overlay {
                    if market.candles.count < 2 {
                        HStack(spacing: 7 * scale) {
                            ProgressView()
                                .tint(ZKTheme.purple)
                            Text(market.feedStatus == .offline ? "Market feed unavailable" : "Loading live 1M chart…")
                                .font(.system(size: 10 * scale, weight: .semibold))
                                .foregroundStyle(ZKTheme.textMuted)
                        }
                    }
                }

            HStack {
                Label(market.sessionName, systemImage: "clock.fill")
                Spacer()
                Text("\(market.candles.count) × 1M candles")
            }
            .font(.system(size: 9 * scale, weight: .bold))
            .foregroundStyle(ZKTheme.textMuted)
        }
        .padding(15 * scale)
        .background(
            RadialGradient(
                colors: [ZKTheme.purple.opacity(0.16), ZKTheme.card2.opacity(0.96), ZKTheme.card.opacity(0.98)],
                center: .topTrailing,
                startRadius: 0,
                endRadius: 260
            )
        )
        .overlay(RoundedRectangle(cornerRadius: 22 * scale).stroke(ZKTheme.borderStrong, lineWidth: 1))
        .clipShape(RoundedRectangle(cornerRadius: 22 * scale))
        .shadow(color: ZKTheme.purple.opacity(0.08), radius: 24)
    }

    private var marketStats: some View {
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8 * scale) {
            MarketStatTile(title: "Session open", value: money(market.openPrice))
            MarketStatTile(title: "Session high", value: money(market.dayHigh), valueColor: ZKTheme.green)
            MarketStatTile(title: "Session low", value: money(market.dayLow), valueColor: ZKTheme.red)
            MarketStatTile(title: "Range", value: market.range.map { String(format: "$%.2f", $0) } ?? "—", valueColor: ZKTheme.gold)
        }
    }

    private var systemStrip: some View {
        HStack(spacing: 0) {
            systemItem("DATA", market.feedStatus.rawValue, feedColor)
            Divider().overlay(ZKTheme.border)
            systemItem("CHART", market.candles.isEmpty ? "WAIT" : "1M LIVE", market.candles.isEmpty ? ZKTheme.gold : ZKTheme.green)
            Divider().overlay(ZKTheme.border)
            systemItem("AI", "OFFLINE", ZKTheme.textMuted)
        }
        .padding(.vertical, 10 * scale)
        .background(ZKTheme.card.opacity(0.88))
        .overlay(RoundedRectangle(cornerRadius: 14 * scale).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 14 * scale))
    }

    private func systemItem(_ title: String, _ value: String, _ color: Color) -> some View {
        VStack(spacing: 3 * scale) {
            Text(title)
                .font(.system(size: 7 * scale, weight: .black))
                .foregroundStyle(ZKTheme.textMuted)
            Text(value)
                .font(.system(size: 9 * scale, weight: .black, design: .rounded))
                .foregroundStyle(color)
                .lineLimit(1)
                .minimumScaleFactor(0.7)
        }
        .frame(maxWidth: .infinity)
    }

    private var quickActions: some View {
        VStack(alignment: .leading, spacing: 8 * scale) {
            HStack {
                ZKMicroLabel(text: "WORKSPACE")
                Spacer()
                Text("FAST ACCESS")
                    .font(.system(size: 7.5 * scale, weight: .black))
                    .foregroundStyle(ZKTheme.textMuted)
            }

            HomeActionButton(
                icon: "chart.xyaxis.line",
                title: "Live Chart",
                subtitle: "Open the interactive XAUUSD 1M chart with pan, zoom and drawings",
                primary: true
            ) { state.go(.chart) }

            HomeActionButton(
                icon: "diamond.fill",
                title: "Signal Console",
                subtitle: "Live market context is connected; AI signal logic remains intentionally off"
            ) { state.go(.signal) }

            HStack(spacing: 8 * scale) {
                compactAction(icon: "sparkles", title: "AI Lab", subtitle: "Model workspace") { state.go(.lab) }
                compactAction(icon: "bubble.left.and.bubble.right.fill", title: "Chat", subtitle: "App assistant") { state.go(.chat) }
            }
        }
    }

    private func compactAction(icon: String, title: String, subtitle: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 8 * scale) {
                Image(systemName: icon)
                    .font(.system(size: 17 * scale, weight: .bold))
                    .foregroundStyle(Color(red: 0.84, green: 0.48, blue: 0.91))
                Text(title)
                    .font(.system(size: 14 * scale, weight: .bold))
                    .foregroundStyle(.white)
                Text(subtitle)
                    .font(.system(size: 9 * scale, weight: .medium))
                    .foregroundStyle(ZKTheme.textMuted)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(12 * scale)
            .background(ZKTheme.card.opacity(0.90))
            .overlay(RoundedRectangle(cornerRadius: 15 * scale).stroke(ZKTheme.border))
            .clipShape(RoundedRectangle(cornerRadius: 15 * scale))
        }
        .buttonStyle(ZKPressStyle())
    }

    private var dataCard: some View {
        HStack(alignment: .top, spacing: 10 * scale) {
            Image(systemName: "antenna.radiowaves.left.and.right")
                .font(.system(size: 16 * scale, weight: .bold))
                .foregroundStyle(feedColor)
                .frame(width: 32 * scale, height: 32 * scale)
                .background(feedColor.opacity(0.08))
                .clipShape(RoundedRectangle(cornerRadius: 9 * scale))

            VStack(alignment: .leading, spacing: 3 * scale) {
                Text("LIVE MARKET LAYER")
                    .font(.system(size: 8 * scale, weight: .black))
                    .tracking(0.7 * scale)
                    .foregroundStyle(ZKTheme.textSoft)
                Text("XAUS spot + 1-minute chart feed")
                    .font(.system(size: 11 * scale, weight: .bold))
                Text("Indicative reference data, not an IC Markets executable quote. Broker integration comes after the native app is stable.")
                    .font(.system(size: 9 * scale, weight: .medium))
                    .foregroundStyle(ZKTheme.textMuted)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 2)
        }
        .padding(12 * scale)
        .background(ZKTheme.card.opacity(0.72))
        .overlay(RoundedRectangle(cornerRadius: 15 * scale).stroke(ZKTheme.border.opacity(0.8)))
        .clipShape(RoundedRectangle(cornerRadius: 15 * scale))
    }

    private var priceText: String {
        market.currentPrice.map { String(format: "$%.2f", $0) } ?? "$—"
    }

    private var changeText: String {
        guard let change = market.change, let pct = market.changePercent else { return "Waiting for market data" }
        return String(format: "%@%.2f  (%@%.2f%%)", change >= 0 ? "+" : "", change, pct >= 0 ? "+" : "", pct)
    }

    private var changeColor: Color {
        guard let change = market.change else { return ZKTheme.textMuted }
        return change >= 0 ? ZKTheme.green : ZKTheme.red
    }

    private var feedColor: Color {
        switch market.feedStatus {
        case .live: return ZKTheme.green
        case .stale: return ZKTheme.gold
        case .offline: return ZKTheme.red
        case .connecting: return ZKTheme.gold
        }
    }

    private func money(_ value: Double?) -> String {
        value.map { String(format: "$%.2f", $0) } ?? "—"
    }

    private var ambient: some View {
        ZStack {
            Circle()
                .fill(ZKTheme.purple.opacity(0.11))
                .frame(width: 280 * scale, height: 280 * scale)
                .blur(radius: 34)
                .offset(x: drift ? -100 : -160, y: drift ? -210 : -265)

            Circle()
                .fill(ZKTheme.gold.opacity(0.045))
                .frame(width: 240 * scale, height: 240 * scale)
                .blur(radius: 38)
                .offset(x: drift ? 150 : 210, y: drift ? 230 : 300)
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 10).repeatForever(autoreverses: true)) { drift = true }
        }
    }
}
