import SwiftUI

struct ChartView: View {
    @EnvironmentObject private var state: AppState
    @EnvironmentObject private var market: MarketDataService
    @Environment(\.zkScale) private var scale

    var body: some View {
        VStack(spacing: 8 * scale) {
            ZKPageHeader(
                micro: "LIVE NATIVE CHART",
                title: "XAUUSD • 1M",
                pill: market.feedStatus.rawValue,
                pillColor: feedColor
            )

            modeTabs
            marketBar

            if market.candles.isEmpty {
                emptyState
            } else if state.chartMode == 0 {
                agentChart
            } else {
                referenceChart
            }
        }
        .padding(.horizontal, 16 * scale)
        .padding(.top, 8 * scale)
        .padding(.bottom, 8 * scale)
        .background(ZKTheme.background)
        .refreshable { await market.refreshAll() }
    }

    private var modeTabs: some View {
        HStack(spacing: 6 * scale) {
            tab("AGENT CHART", 0)
            tab("CLEAN VIEW", 1)
        }
    }

    private func tab(_ title: String, _ index: Int) -> some View {
        Button { state.chartMode = index } label: {
            Text(title)
                .font(.system(size: 9 * scale, weight: .black))
                .tracking(0.5)
                .foregroundStyle(state.chartMode == index ? .white : ZKTheme.textMuted)
                .frame(maxWidth: .infinity, minHeight: 38 * scale)
                .background(state.chartMode == index ? Color(red: 0.086, green: 0.051, blue: 0.110) : ZKTheme.card)
                .overlay(RoundedRectangle(cornerRadius: 11 * scale).stroke(state.chartMode == index ? ZKTheme.borderStrong : ZKTheme.border))
                .clipShape(RoundedRectangle(cornerRadius: 11 * scale))
        }
        .buttonStyle(ZKPressStyle())
    }

    private var marketBar: some View {
        HStack(spacing: 8 * scale) {
            VStack(alignment: .leading, spacing: 2 * scale) {
                Text("LIVE PRICE")
                    .font(.system(size: 7 * scale, weight: .black))
                    .foregroundStyle(ZKTheme.textMuted)
                Text(market.currentPrice.map { String(format: "$%.2f", $0) } ?? "—")
                    .font(.system(size: 13 * scale, weight: .black, design: .monospaced))
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 2 * scale) {
                Text("SOURCE")
                    .font(.system(size: 7 * scale, weight: .black))
                    .foregroundStyle(ZKTheme.textMuted)
                Text("XAUS • \(market.freshnessText)")
                    .font(.system(size: 9 * scale, weight: .black))
                    .foregroundStyle(feedColor)
            }
            Button {
                Task { await market.refreshAll() }
            } label: {
                Image(systemName: "arrow.clockwise")
                    .font(.system(size: 12 * scale, weight: .bold))
                    .frame(width: 30 * scale, height: 30 * scale)
                    .background(ZKTheme.card2)
                    .overlay(Circle().stroke(ZKTheme.border))
                    .clipShape(Circle())
            }
            .buttonStyle(ZKPressStyle())
        }
        .padding(.horizontal, 10 * scale)
        .padding(.vertical, 7 * scale)
        .background(ZKTheme.card.opacity(0.88))
        .overlay(RoundedRectangle(cornerRadius: 11 * scale).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 11 * scale))
    }

    private var agentChart: some View {
        VStack(spacing: 0) {
            chartHeader(
                title: "AI-READABLE CHART",
                subtitle: "Pinch to zoom • drag to pan • tap candle",
                trailing: "\(state.drawings.count) DRAWINGS"
            )

            NativeAgentChart(candles: market.candles, drawings: state.drawings)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding(.vertical, 4 * scale)

            drawingToolbar
            footer("Live 1-minute reference candles from XAUS. Drawings are local and persistent; no AI-generated levels are used yet.")
        }
        .frame(maxHeight: .infinity)
        .background(Color(red: 0.031, green: 0.024, blue: 0.043))
        .overlay(RoundedRectangle(cornerRadius: 18 * scale).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 18 * scale))
    }

    private var referenceChart: some View {
        VStack(spacing: 0) {
            chartHeader(
                title: "CLEAN REFERENCE",
                subtitle: "Same live 1M feed • drawings hidden",
                trailing: "INTERACTIVE"
            )
            NativeAgentChart(candles: market.candles, drawings: [])
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding(.vertical, 4 * scale)
            footer("Clean mode uses the same live chart engine without local drawing overlays.")
        }
        .frame(maxHeight: .infinity)
        .background(Color(red: 0.031, green: 0.024, blue: 0.043))
        .overlay(RoundedRectangle(cornerRadius: 18 * scale).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 18 * scale))
    }

    private var emptyState: some View {
        VStack(spacing: 12 * scale) {
            Spacer()
            Image(systemName: market.feedStatus == .offline ? "wifi.slash" : "antenna.radiowaves.left.and.right")
                .font(.system(size: 32 * scale, weight: .medium))
                .foregroundStyle(feedColor)
            Text(market.feedStatus == .offline ? "Market feed unavailable" : "Loading live XAUUSD candles")
                .font(.system(size: 15 * scale, weight: .bold))
            Text(market.lastError ?? "The chart will populate from the live 1-minute reference endpoint when data arrives.")
                .font(.system(size: 10 * scale, weight: .medium))
                .foregroundStyle(ZKTheme.textMuted)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 22 * scale)
            Button("RETRY") {
                Task { await market.refreshAll() }
            }
            .font(.system(size: 9 * scale, weight: .black))
            .foregroundStyle(Color(red: 0.84, green: 0.48, blue: 0.91))
            .padding(.horizontal, 16 * scale)
            .frame(height: 34 * scale)
            .background(ZKTheme.card2)
            .overlay(Capsule().stroke(ZKTheme.borderStrong))
            .clipShape(Capsule())
            .buttonStyle(ZKPressStyle())
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(ZKTheme.card.opacity(0.45))
        .overlay(RoundedRectangle(cornerRadius: 18 * scale).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 18 * scale))
    }

    private func chartHeader(title: String, subtitle: String, trailing: String) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 3 * scale) {
                Text(title)
                    .font(.system(size: 8 * scale, weight: .black))
                    .tracking(0.7)
                    .foregroundStyle(ZKTheme.textMuted)
                Text(subtitle)
                    .font(.system(size: 10 * scale, weight: .bold))
                    .foregroundStyle(.white.opacity(0.9))
            }
            Spacer()
            Text(trailing)
                .font(.system(size: 8 * scale, weight: .bold))
                .foregroundStyle(ZKTheme.textSoft)
        }
        .padding(.horizontal, 11 * scale)
        .frame(height: 48 * scale)
        .background(Color(red: 0.039, green: 0.027, blue: 0.063))
    }

    private var drawingToolbar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 6 * scale) {
                tool("S/R") { state.replaceSupportResistance(around: market.currentPrice) }
                tool("ZONE") { state.addZone(around: market.currentPrice) }
                tool("UNDO") { state.removeLastDrawing() }
                tool("NO SUP") { state.removeSupport() }
                tool("NO RES") { state.removeResistance() }
                tool("CLEAR") { state.clearAllDrawings() }
            }
            .padding(.horizontal, 9 * scale)
        }
        .frame(height: 46 * scale)
        .background(Color(red: 0.039, green: 0.027, blue: 0.063))
        .overlay(alignment: .top) { Rectangle().fill(ZKTheme.border.opacity(0.7)).frame(height: 1) }
    }

    private func tool(_ name: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(name)
                .font(.system(size: 8 * scale, weight: .black))
                .foregroundStyle(Color(red: 0.831, green: 0.478, blue: 0.894))
                .padding(.horizontal, 10 * scale)
                .frame(height: 30 * scale)
                .background(Color(red: 0.086, green: 0.051, blue: 0.110))
                .overlay(Capsule().stroke(ZKTheme.borderStrong))
                .clipShape(Capsule())
        }
        .buttonStyle(ZKPressStyle())
    }

    private func footer(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 8 * scale, weight: .medium))
            .foregroundStyle(Color(red: 0.46, green: 0.42, blue: 0.48))
            .multilineTextAlignment(.center)
            .padding(.horizontal, 10 * scale)
            .frame(minHeight: 34 * scale)
            .background(ZKTheme.navBackground)
    }

    private var feedColor: Color {
        switch market.feedStatus {
        case .live: return ZKTheme.green
        case .stale, .connecting: return ZKTheme.gold
        case .offline: return ZKTheme.red
        }
    }
}
