import SwiftUI

struct ChatView: View {
    @EnvironmentObject private var state: AppState
    @EnvironmentObject private var market: MarketDataService
    @Environment(\.zkScale) private var scale
    @State private var input = ""
    @FocusState private var composerFocused: Bool

    var body: some View {
        VStack(spacing: 9 * scale) {
            ZKPageHeader(micro: "GROUNDED MODEL ASSISTANT", title: "ZK AI Chat", pill: "LOCAL", pillColor: ZKTheme.green)
            statusBar
            messages.frame(maxHeight: .infinity)
            chips
            composer
        }
        .padding(.horizontal, 16 * scale).padding(.top, 8 * scale).padding(.bottom, 8 * scale)
        .background(ZKTheme.background)
        .contentShape(Rectangle())
        .onTapGesture { composerFocused = false }
    }

    private var statusBar: some View {
        HStack(spacing: 9 * scale) {
            VStack(alignment: .leading, spacing: 3 * scale) {
                Text(state.selectedModel?.name ?? "No trading model trained").font(.system(size: 10 * scale, weight: .bold)).foregroundStyle(.white.opacity(0.88))
                Text("Market: \(market.feedStatus.rawValue.lowercased()) XAUS reference • \(market.currentPrice.map { String(format: "$%.2f", $0) } ?? "—")").font(.system(size: 9 * scale, weight: .medium)).foregroundStyle(ZKTheme.textMuted)
            }
            Spacer()
            Button { state.agentLoaded.toggle() } label: {
                Text(state.agentLoaded ? "AGENT READY" : "LOAD AGENT")
                    .font(.system(size: 8 * scale, weight: .black)).foregroundStyle(Color(red: 0.831, green: 0.478, blue: 0.894))
                    .padding(.horizontal, 10 * scale).frame(height: 34 * scale).background(Color(red: 0.086, green: 0.051, blue: 0.110))
                    .overlay(RoundedRectangle(cornerRadius: 10 * scale).stroke(ZKTheme.borderStrong)).clipShape(RoundedRectangle(cornerRadius: 10 * scale))
            }.buttonStyle(ZKPressStyle())
        }
        .padding(.horizontal, 11 * scale).padding(.vertical, 9 * scale).background(ZKTheme.card)
        .overlay(RoundedRectangle(cornerRadius: 13 * scale).stroke(ZKTheme.border)).clipShape(RoundedRectangle(cornerRadius: 13 * scale))
    }

    private var messages: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 9 * scale) {
                    ForEach(state.chatMessages) { message in bubble(message).id(message.id) }
                }
                .padding(.vertical, 3 * scale)
            }
            .scrollDismissesKeyboard(.interactively)
            .scrollIndicators(.hidden)
            .onChange(of: state.chatMessages.count) {
                if let last = state.chatMessages.last {
                    withAnimation(.easeOut(duration: 0.18)) { proxy.scrollTo(last.id, anchor: .bottom) }
                }
            }
        }
    }

    private func bubble(_ msg: ChatMessage) -> some View {
        HStack {
            if msg.role == .user { Spacer(minLength: 42 * scale) }
            VStack(alignment: .leading, spacing: 5 * scale) {
                Text(msg.role == .user ? "YOU" : "ZK AI").font(.system(size: 8 * scale, weight: .black)).tracking(0.6)
                    .foregroundStyle(msg.role == .user ? Color(red: 0.831, green: 0.478, blue: 0.894) : ZKTheme.textMuted)
                Text(msg.text).font(.system(size: 12 * scale, weight: .medium)).foregroundStyle(.white.opacity(0.92)).lineSpacing(2.2 * scale)
            }
            .padding(12 * scale)
            .background(msg.role == .user ? Color(red: 0.086, green: 0.051, blue: 0.110) : ZKTheme.card)
            .overlay(RoundedRectangle(cornerRadius: 15 * scale).stroke(msg.role == .user ? ZKTheme.borderStrong : ZKTheme.border))
            .clipShape(RoundedRectangle(cornerRadius: 15 * scale))
            if msg.role == .assistant { Spacer(minLength: 42 * scale) }
        }
    }

    private var chips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 7 * scale) {
                chip("What do you see?"); chip("Why waiting?"); chip("Performance"); chip("Macro status"); chip("Mark chart"); chip("Clear drawings")
            }.padding(.horizontal, 1)
        }.frame(height: 36 * scale)
    }

    private func chip(_ text: String) -> some View {
        Button { state.sendChat(text) } label: {
            Text(text).font(.system(size: 9 * scale, weight: .bold)).foregroundStyle(ZKTheme.textSoft)
                .padding(.horizontal, 11 * scale).frame(height: 31 * scale).background(ZKTheme.card)
                .overlay(Capsule().stroke(ZKTheme.border)).clipShape(Capsule())
        }.buttonStyle(ZKPressStyle())
    }

    private var composer: some View {
        HStack(spacing: 7 * scale) {
            TextField("Ask ZK AI about the market or model…", text: $input)
                .focused($composerFocused).font(.system(size: 12 * scale, weight: .medium)).padding(.horizontal, 12 * scale).frame(height: 46 * scale)
                .background(ZKTheme.card).overlay(RoundedRectangle(cornerRadius: 14 * scale).stroke(ZKTheme.borderStrong)).clipShape(RoundedRectangle(cornerRadius: 14 * scale))
                .submitLabel(.send).onSubmit(send)

            Button(action: send) {
                Image(systemName: "arrow.up").font(.system(size: 18 * scale, weight: .black)).foregroundStyle(.white)
                    .frame(width: 46 * scale, height: 46 * scale).background(ZKTheme.accentGradient).clipShape(RoundedRectangle(cornerRadius: 14 * scale))
            }.buttonStyle(ZKPressStyle())
        }
    }

    private func send() {
        let text = input
        input = ""
        state.sendChat(text)
    }
}
