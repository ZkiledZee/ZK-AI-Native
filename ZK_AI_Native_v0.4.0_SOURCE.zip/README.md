# ZK AI Native v0.4.0 — Live Data Foundation

This build focuses on the native iPhone experience and real market-data plumbing before any trading AI is enabled.

## What changed
- Reworked professional Home dashboard with live XAU/USD price, change, 1M mini-chart, session statistics, data health and fast navigation.
- Added `MarketDataService` using the public XAUS API.
- Live indicative XAU/USD spot refreshes about every 30 seconds.
- Native charts load real 1-minute XAU market OHLCV through the XAUS chart endpoint and refresh every minute.
- Home, Signal, Chart and Chat share the same live market service.
- Chart timestamps now show actual candle times instead of demo indexes.
- Pinch zoom, drag pan, candle tap/OHLC inspection, latest-price line and local persistent drawings remain enabled.
- Support/resistance and zone tools now anchor around the current live reference price rather than old demo levels.
- Removed demo-candle generators from Home/Signal/Chart.
- Trading AI remains deliberately OFF. The app does not generate live entries, SL, TP, or probabilities yet.
- Forced a new app-icon asset catalog name (`ZKAppIconV4`) and explicit `CFBundleIconName` to make iOS refresh the gold/black ZK icon on update.

## Data source
- Spot: `https://xaus.com/api/v1/spot`
- 1M chart: `https://xaus.com/api/v1/chart?symbol=xau&range=1d&interval=1m`

XAUS data is indicative reference market data, not an executable IC Markets broker quote. Exact broker matching is a later integration layer.

## Bundle
- Bundle ID: `com.zk.goldai.native`
- Marketing version: `0.4.0`
- iOS target: 17.0+
