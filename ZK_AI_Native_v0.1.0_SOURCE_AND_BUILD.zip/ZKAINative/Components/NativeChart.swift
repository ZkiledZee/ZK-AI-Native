import SwiftUI

struct NativeAgentChart: View {
    let candles: [ChartCandle]
    let drawings: [ChartDrawing]

    private var high: Double { candles.map(\.high).max() ?? 1 }
    private var low: Double { candles.map(\.low).min() ?? 0 }

    var body: some View {
        GeometryReader { geo in
            let span = max(high - low, 0.001)
            let step = max((geo.size.width - 24) / CGFloat(max(candles.count - 1, 1)), 1)
            let candleWidth = max(2.5, step * 0.57)

            ZStack {
                Canvas { context, size in
                    for row in 0...5 {
                        let y = size.height * CGFloat(row) / 5
                        var path = Path()
                        path.move(to: CGPoint(x: 0, y: y))
                        path.addLine(to: CGPoint(x: size.width, y: y))
                        context.stroke(path, with: .color(ZKTheme.border.opacity(0.42)), lineWidth: 0.6)
                    }

                    func y(_ value: Double) -> CGFloat {
                        size.height - CGFloat((value - low) / span) * (size.height - 28) - 14
                    }

                    for c in candles {
                        let x = CGFloat(c.index) * step + 12
                        let color = c.isUp ? ZKTheme.green : ZKTheme.red

                        var wick = Path()
                        wick.move(to: CGPoint(x: x, y: y(c.high)))
                        wick.addLine(to: CGPoint(x: x, y: y(c.low)))
                        context.stroke(wick, with: .color(color.opacity(0.95)), lineWidth: 1)

                        let top = min(y(c.open), y(c.close))
                        let bottom = max(y(c.open), y(c.close))
                        let rect = CGRect(
                            x: x - candleWidth/2,
                            y: top,
                            width: candleWidth,
                            height: max(2, bottom - top)
                        )
                        context.fill(Path(roundedRect: rect, cornerRadius: 0.7), with: .color(color))
                    }

                    for drawing in drawings {
                        let y1 = y(drawing.price)

                        if drawing.kind == .zone, let second = drawing.secondaryPrice {
                            let y2 = y(second)
                            let rect = CGRect(
                                x: 0,
                                y: min(y1, y2),
                                width: size.width,
                                height: abs(y2 - y1)
                            )
                            context.fill(Path(rect), with: .color(ZKTheme.purple.opacity(0.08)))
                            context.stroke(Path(rect), with: .color(ZKTheme.purple.opacity(0.55)), lineWidth: 0.8)
                        } else {
                            var path = Path()
                            path.move(to: CGPoint(x: 0, y: y1))
                            path.addLine(to: CGPoint(x: size.width, y: y1))
                            context.stroke(path, with: .color(color(for: drawing.kind).opacity(0.9)), style: StrokeStyle(lineWidth: 1, dash: [5, 4]))
                        }
                    }
                }

                ForEach(drawings) { drawing in
                    drawingLabel(drawing, height: geo.size.height, span: span)
                }
            }
        }
    }

    private func drawingLabel(_ d: ChartDrawing, height: CGFloat, span: Double) -> some View {
        let center = d.kind == .zone && d.secondaryPrice != nil
            ? (d.price + (d.secondaryPrice ?? d.price)) / 2
            : d.price
        let y = height - CGFloat((center - low) / span) * (height - 28) - 14

        return HStack {
            Spacer()
            Text(d.label)
                .font(.system(size: 6, weight: .black))
                .foregroundStyle(color(for: d.kind))
                .padding(.horizontal, 5)
                .padding(.vertical, 3)
                .background(ZKTheme.navBackground.opacity(0.88))
                .clipShape(RoundedRectangle(cornerRadius: 5))
        }
        .padding(.trailing, 5)
        .position(x: UIScreen.main.bounds.width/2 - 20, y: y)
        .allowsHitTesting(false)
    }

    private func color(for kind: DrawingKind) -> Color {
        switch kind {
        case .support: return ZKTheme.green
        case .resistance: return ZKTheme.red
        case .zone: return ZKTheme.purple
        case .entry: return ZKTheme.blue
        case .stopLoss: return ZKTheme.red
        case .takeProfit: return ZKTheme.green
        case .note: return ZKTheme.gold
        }
    }
}
