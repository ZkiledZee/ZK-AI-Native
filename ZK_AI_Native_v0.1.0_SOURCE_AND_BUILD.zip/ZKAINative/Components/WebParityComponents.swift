import SwiftUI

struct HomeLogo: View {
    @State private var pulseA = false
    @State private var pulseB = false
    @State private var float = false

    var body: some View {
        ZStack {
            Circle()
                .stroke(ZKTheme.purple.opacity(0.24), lineWidth: 1)
                .frame(width: 92, height: 92)
                .scaleEffect(pulseA ? 1.16 : 0.72)
                .opacity(pulseA ? 0 : 0.55)

            Circle()
                .stroke(ZKTheme.purple.opacity(0.20), lineWidth: 1)
                .frame(width: 104, height: 104)
                .scaleEffect(pulseB ? 1.16 : 0.72)
                .opacity(pulseB ? 0 : 0.40)

            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .fill(Color(red: 0.047, green: 0.031, blue: 0.063))
                .frame(width: 66, height: 66)
                .overlay(
                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .stroke(ZKTheme.goldLogo, lineWidth: 3)
                )
                .shadow(color: ZKTheme.goldLogo.opacity(0.14), radius: 14)

            Text("ZK")
                .font(.system(size: 23, weight: .black, design: .rounded))
                .foregroundStyle(.white)
        }
        .frame(width: 108, height: 108)
        .offset(y: float ? -3 : 3)
        .onAppear {
            withAnimation(.easeOut(duration: 3).repeatForever(autoreverses: false)) { pulseA = true }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                withAnimation(.easeOut(duration: 3).repeatForever(autoreverses: false)) { pulseB = true }
            }
            withAnimation(.easeInOut(duration: 4).repeatForever(autoreverses: true)) { float = true }
        }
    }
}

struct HomeActionButton: View {
    let glyph: String
    let title: String
    let subtitle: String
    var primary: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 10) {
                Text(glyph)
                    .font(.system(size: 19, weight: .black))
                    .foregroundStyle(Color(red: 0.79, green: 0.41, blue: 0.87))
                    .frame(width: 42, height: 42)
                    .background(Color(red: 0.086, green: 0.059, blue: 0.106))
                    .overlay(
                        RoundedRectangle(cornerRadius: 14)
                            .stroke(Color(red: 0.286, green: 0.196, blue: 0.322))
                    )
                    .clipShape(RoundedRectangle(cornerRadius: 14))

                VStack(alignment: .leading, spacing: 3) {
                    Text(title)
                        .font(.system(size: 14, weight: .bold))
                        .foregroundStyle(.white)
                    Text(subtitle)
                        .font(.system(size: 9, weight: .medium))
                        .foregroundStyle(ZKTheme.textMuted)
                        .lineLimit(2)
                }

                Spacer(minLength: 4)

                Text("›")
                    .font(.system(size: 25, weight: .medium))
                    .foregroundStyle(Color(red: 0.64, green: 0.44, blue: 0.69))
            }
            .frame(minHeight: 52)
            .padding(.horizontal, 13)
            .padding(.vertical, 10)
            .background(
                LinearGradient(
                    colors: [Color(red: 0.055, green: 0.039, blue: 0.071), Color(red: 0.031, green: 0.024, blue: 0.043)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .overlay(
                RoundedRectangle(cornerRadius: 20)
                    .stroke(primary ? ZKTheme.borderStrong : ZKTheme.border, lineWidth: 1)
            )
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .shadow(color: primary ? ZKTheme.purple.opacity(0.08) : .clear, radius: 20)
        }
        .buttonStyle(.plain)
    }
}

struct BottomNav: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        HStack(spacing: 2) {
            ForEach(ZKPage.allCases) { item in
                Button {
                    state.go(item)
                } label: {
                    VStack(spacing: 2) {
                        Text(item.glyph)
                            .font(.system(size: 18, weight: .black))
                        Text(item.title)
                            .font(.system(size: 7, weight: .black, design: .rounded))
                    }
                    .foregroundStyle(state.page == item ? Color(red: 0.824, green: 0.475, blue: 0.898) : Color(red: 0.466, green: 0.427, blue: 0.494))
                    .frame(maxWidth: .infinity, minHeight: 48)
                    .background(
                        state.page == item
                        ? LinearGradient(colors: [ZKTheme.purple.opacity(0.10), ZKTheme.purple.opacity(0.025)], startPoint: .top, endPoint: .bottom)
                        : LinearGradient(colors: [.clear, .clear], startPoint: .top, endPoint: .bottom)
                    )
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 8)
        .padding(.top, 5)
        .background(ZKTheme.navBackground)
        .overlay(alignment: .top) {
            Rectangle()
                .fill(Color(red: 0.173, green: 0.125, blue: 0.184))
                .frame(height: 1)
        }
    }
}

struct MetricCell: View {
    let label: String
    let value: String
    var color: Color = .white

    var body: some View {
        VStack(spacing: 3) {
            Text(label.uppercased())
                .font(.system(size: 6, weight: .black, design: .rounded))
                .foregroundStyle(ZKTheme.textMuted)
            Text(value)
                .font(.system(size: 10, weight: .black, design: .monospaced))
                .foregroundStyle(color)
                .lineLimit(1)
        }
        .frame(maxWidth: .infinity)
    }
}

struct ProbabilityCell: View {
    let label: String
    let value: Double
    let color: Color

    var body: some View {
        VStack(spacing: 2) {
            Text(label)
                .font(.system(size: 6, weight: .black))
                .foregroundStyle(ZKTheme.textMuted)
            Text("\(Int(value * 100))%")
                .font(.system(size: 11, weight: .black, design: .monospaced))
                .foregroundStyle(color)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 6)
        .background(Color.black.opacity(0.22))
        .overlay(RoundedRectangle(cornerRadius: 9).stroke(ZKTheme.border.opacity(0.85)))
        .clipShape(RoundedRectangle(cornerRadius: 9))
    }
}

struct SignalOrb: View {
    let color: Color
    @State private var pulse1 = false
    @State private var pulse2 = false

    var body: some View {
        ZStack {
            Circle()
                .stroke(color.opacity(0.50), lineWidth: 1)
                .frame(width: 42, height: 42)
                .scaleEffect(pulse1 ? 1.18 : 0.65)
                .opacity(pulse1 ? 0 : 0.55)
            Circle()
                .stroke(color.opacity(0.25), lineWidth: 1)
                .frame(width: 50, height: 50)
                .scaleEffect(pulse2 ? 1.18 : 0.65)
                .opacity(pulse2 ? 0 : 0.35)
            Circle()
                .fill(color)
                .frame(width: 16, height: 16)
                .shadow(color: color.opacity(0.9), radius: 10)
        }
        .frame(width: 52, height: 52)
        .onAppear {
            withAnimation(.easeOut(duration: 2.4).repeatForever(autoreverses: false)) { pulse1 = true }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.15) {
                withAnimation(.easeOut(duration: 2.4).repeatForever(autoreverses: false)) { pulse2 = true }
            }
        }
    }
}

struct ConfidenceRing: View {
    let value: Double
    let color: Color
    let label: String

    var body: some View {
        ZStack {
            Circle()
                .stroke(Color(red: 0.145, green: 0.110, blue: 0.169), lineWidth: 7)
            Circle()
                .trim(from: 0, to: max(0, min(value, 1)))
                .stroke(color, style: StrokeStyle(lineWidth: 7, lineCap: .round))
                .rotationEffect(.degrees(-90))
                .shadow(color: color.opacity(0.18), radius: 8)

            VStack(spacing: 1) {
                Text("\(Int(value * 100))%")
                    .font(.system(size: 11, weight: .black))
                Text(label.uppercased())
                    .font(.system(size: 5, weight: .black))
                    .foregroundStyle(ZKTheme.textMuted)
            }
        }
        .frame(width: 58, height: 58)
    }
}

struct StatusDotLine: View {
    let title: String
    let subtitle: String
    let color: Color

    var body: some View {
        HStack(spacing: 6) {
            Circle().fill(color).frame(width: 6, height: 6).shadow(color: color.opacity(0.8), radius: 4)
            Text(title.uppercased())
                .font(.system(size: 7, weight: .black))
                .foregroundStyle(.white.opacity(0.86))
            Spacer()
            Text(subtitle)
                .font(.system(size: 7, weight: .medium))
                .foregroundStyle(ZKTheme.textMuted)
                .lineLimit(1)
        }
    }
}
