import Foundation

enum SignalSide: String, Codable {
    case buy = "BUY"
    case sell = "SELL"
    case wait = "WAIT"
}

struct TradeSignal: Codable, Equatable {
    var side: SignalSide
    var entry: Double
    var stopLoss: Double
    var takeProfit: Double
    var confidence: Double
    var riskReward: Double
    var isDemo: Bool
    var activatedAt: Date

    static let demo = TradeSignal(
        side: .buy,
        entry: 4648.20,
        stopLoss: 4645.40,
        takeProfit: 4654.36,
        confidence: 0.78,
        riskReward: 2.2,
        isDemo: true,
        activatedAt: Date()
    )
}

struct ModelRecord: Identifiable, Codable, Equatable {
    var id: UUID
    var name: String
    var status: String
    var samples: Int
    var profitFactor: Double
    var expectancyR: Double
    var drawdownR: Double

    static let demoModels: [ModelRecord] = [
        .init(id: UUID(), name: "ZK AI v1", status: "ACTIVE", samples: 0, profitFactor: 0, expectancyR: 0, drawdownR: 0),
        .init(id: UUID(), name: "Challenger slot", status: "EMPTY", samples: 0, profitFactor: 0, expectancyR: 0, drawdownR: 0)
    ]
}

struct MacroComponent: Identifiable {
    let id = UUID()
    let name: String
    let value: String
    let detail: String
    let state: MacroState
}

enum MacroState {
    case bullish
    case bearish
    case neutral
    case unavailable
}

struct ChartCandle: Identifiable {
    let id = UUID()
    let index: Int
    let open: Double
    let high: Double
    let low: Double
    let close: Double

    var isUp: Bool { close >= open }
}
