import SwiftUI

enum ZKTheme {
    static let background = Color(red: 0.012, green: 0.012, blue: 0.024)       // #030306
    static let navBackground = Color(red: 0.027, green: 0.020, blue: 0.039)   // #07050a
    static let card = Color(red: 0.043, green: 0.031, blue: 0.063)
    static let card2 = Color(red: 0.059, green: 0.039, blue: 0.075)
    static let border = Color(red: 0.235, green: 0.169, blue: 0.267)
    static let borderStrong = Color(red: 0.404, green: 0.251, blue: 0.459)
    static let purple = Color(red: 0.710, green: 0.361, blue: 1.000)
    static let pink = Color(red: 1.000, green: 0.247, blue: 0.784)
    static let green = Color(red: 0.090, green: 0.851, blue: 0.576)
    static let red = Color(red: 1.000, green: 0.388, blue: 0.451)
    static let gold = Color(red: 0.945, green: 0.722, blue: 0.243)
    static let blue = Color(red: 0.357, green: 0.655, blue: 1.000)
    static let textMuted = Color(red: 0.505, green: 0.459, blue: 0.529)
    static let textSoft = Color(red: 0.635, green: 0.584, blue: 0.663)
    static let goldLogo = Color(red: 0.965, green: 0.741, blue: 0.222)

    static let accentGradient = LinearGradient(
        colors: [Color(red: 0.45, green: 0.14, blue: 0.56), Color(red: 0.68, green: 0.20, blue: 0.59)],
        startPoint: .leading,
        endPoint: .trailing
    )
}

struct ZKMicroLabel: View {
    let text: String

    var body: some View {
        Text(text.uppercased())
            .font(.system(size: 9, weight: .black, design: .rounded))
            .tracking(1.5)
            .foregroundStyle(ZKTheme.textSoft)
    }
}

struct ZKCard<Content: View>: View {
    var strongBorder = false
    @ViewBuilder var content: Content

    var body: some View {
        content
            .padding(10)
            .background(
                LinearGradient(
                    colors: [ZKTheme.card2.opacity(0.97), ZKTheme.card.opacity(0.97)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .overlay(
                RoundedRectangle(cornerRadius: 15, style: .continuous)
                    .stroke(strongBorder ? ZKTheme.borderStrong : ZKTheme.border, lineWidth: 1)
            )
            .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
    }
}

struct ZKDataPill: View {
    let text: String
    let color: Color

    var body: some View {
        HStack(spacing: 5) {
            Circle()
                .fill(color)
                .frame(width: 6, height: 6)
                .shadow(color: color.opacity(0.9), radius: 5)
            Text(text.uppercased())
                .font(.system(size: 7, weight: .black, design: .rounded))
                .tracking(0.7)
                .foregroundStyle(ZKTheme.textSoft)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 6)
        .background(Color(red: 0.043, green: 0.031, blue: 0.063))
        .overlay(Capsule().stroke(ZKTheme.borderStrong.opacity(0.8)))
        .clipShape(Capsule())
    }
}

struct ZKPageHeader: View {
    let micro: String
    let title: String
    let pill: String
    let pillColor: Color

    var body: some View {
        HStack(alignment: .bottom) {
            VStack(alignment: .leading, spacing: 3) {
                ZKMicroLabel(text: micro)
                Text(title)
                    .font(.system(size: 27, weight: .black, design: .rounded))
                    .tracking(-1.0)
            }
            Spacer()
            ZKDataPill(text: pill, color: pillColor)
        }
    }
}
