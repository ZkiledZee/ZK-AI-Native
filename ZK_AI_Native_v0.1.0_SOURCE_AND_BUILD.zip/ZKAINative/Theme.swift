import SwiftUI

enum ZKTheme {
    static let background = Color(red: 0.012, green: 0.009, blue: 0.02)
    static let panel = Color(red: 0.045, green: 0.03, blue: 0.06)
    static let panel2 = Color(red: 0.075, green: 0.04, blue: 0.095)
    static let border = Color(red: 0.20, green: 0.13, blue: 0.23)
    static let purple = Color(red: 0.71, green: 0.35, blue: 1.0)
    static let pink = Color(red: 0.94, green: 0.31, blue: 0.76)
    static let green = Color(red: 0.12, green: 0.88, blue: 0.61)
    static let red = Color(red: 1.0, green: 0.35, blue: 0.43)
    static let gold = Color(red: 0.96, green: 0.73, blue: 0.25)
    static let muted = Color.white.opacity(0.48)

    static let accentGradient = LinearGradient(
        colors: [purple, pink],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
}

struct GlassCard<Content: View>: View {
    @ViewBuilder let content: Content

    var body: some View {
        content
            .padding(14)
            .background(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .fill(
                        LinearGradient(
                            colors: [ZKTheme.panel2.opacity(0.95), ZKTheme.panel.opacity(0.96)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
            )
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(ZKTheme.border, lineWidth: 1)
            )
    }
}

struct MicroLabel: View {
    let text: String

    var body: some View {
        Text(text.uppercased())
            .font(.system(size: 10, weight: .heavy, design: .rounded))
            .tracking(1.6)
            .foregroundStyle(ZKTheme.muted)
    }
}
