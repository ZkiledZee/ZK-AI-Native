import SwiftUI

struct ChartView: View {
    @EnvironmentObject private var state: AppState

    private let candles: [ChartCandle] = {
        var result: [ChartCandle] = []
        var price = 4638.0
        for i in 0..<64 {
            let impulse = sin(Double(i) * 0.43) * 1.1 + cos(Double(i) * 0.16) * 0.5
            let open = price
            let close = open + impulse * 0.29 + (i > 34 ? 0.15 : 0.02)
            let high = max(open, close) + 0.38 + abs(sin(Double(i) * 0.78)) * 0.32
            let low = min(open, close) - 0.34 - abs(cos(Double(i) * 0.65)) * 0.27
            result.append(.init(index: i, open: open, high: high, low: low, close: close))
            price = close
        }
        return result
    }()

    var body: some View {
        VStack(spacing: 7) {
            ZKPageHeader(
                micro: "AI + NATIVE CHART",
                title: "XAUUSD • 1M",
                pill: "DEMO",
                pillColor: ZKTheme.gold
            )

            modeTabs

            if state.chartMode == 0 {
                agentChart
            } else {
                referencePlaceholder
            }
        }
        .padding(.horizontal, 14)
        .padding(.top, 8)
        .padding(.bottom, 8)
        .background(ZKTheme.background)
    }

    private var modeTabs: some View {
        HStack(spacing: 5) {
            tab("AGENT CHART", 0)
            tab("REFERENCE", 1)
        }
    }

    private func tab(_ title: String, _ index: Int) -> some View {
        Button {
            state.chartMode = index
        } label: {
            Text(title)
                .font(.system(size: 7, weight: .black))
                .tracking(0.6)
                .foregroundStyle(state.chartMode == index ? .white : ZKTheme.textMuted)
                .frame(maxWidth: .infinity, minHeight: 34)
                .background(state.chartMode == index ? Color(red: 0.086, green: 0.051, blue: 0.110) : Color(red: 0.043, green: 0.031, blue: 0.063))
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(state.chartMode == index ? ZKTheme.borderStrong : ZKTheme.border)
                )
                .clipShape(RoundedRectangle(cornerRadius: 10))
        }
        .buttonStyle(.plain)
    }

    private var agentChart: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("AI-READABLE CHART")
                        .font(.system(size: 6, weight: .black))
                        .tracking(0.8)
                        .foregroundStyle(ZKTheme.textMuted)
                    Text("Native demo candle series")
                        .font(.system(size: 8, weight: .bold))
                }
                Spacer()
                Text("\(state.drawings.count) DRAWINGS")
                    .font(.system(size: 7, weight: .bold))
                    .foregroundStyle(ZKTheme.textSoft)
            }
            .padding(.horizontal, 10)
            .frame(height: 40)
            .background(Color(red: 0.039, green: 0.027, blue: 0.063))

            NativeAgentChart(candles: candles, drawings: state.drawings)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding(.vertical, 4)

            drawingToolbar

            Text("Native chart state is shared with ZK AI. Live broker candles replace demo data in the next data-layer build.")
                .font(.system(size: 6, weight: .medium))
                .foregroundStyle(Color(red: 0.373, green: 0.337, blue: 0.392))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 8)
                .frame(height: 26)
                .background(ZKTheme.navBackground)
        }
        .frame(maxHeight: .infinity)
        .background(Color(red: 0.031, green: 0.024, blue: 0.043))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }

    private var drawingToolbar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 5) {
                tool("S/R") { state.replaceSupportResistance() }
                tool("ZONE") { state.addDemoZone() }
                tool("UNDO") { state.removeLastDrawing() }
                tool("NO SUP") { state.removeSupport() }
                tool("NO RES") { state.removeResistance() }
                tool("CLEAR") { state.clearAllDrawings() }
            }
            .padding(.horizontal, 8)
        }
        .frame(height: 42)
        .background(Color(red: 0.039, green: 0.027, blue: 0.063))
        .overlay(alignment: .top) {
            Rectangle().fill(ZKTheme.border.opacity(0.7)).frame(height: 1)
        }
    }

    private func tool(_ name: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(name)
                .font(.system(size: 6, weight: .black))
                .foregroundStyle(Color(red: 0.831, green: 0.478, blue: 0.894))
                .padding(.horizontal, 9)
                .frame(height: 28)
                .background(Color(red: 0.086, green: 0.051, blue: 0.110))
                .overlay(Capsule().stroke(ZKTheme.borderStrong))
                .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }

    private var referencePlaceholder: some View {
        VStack(spacing: 10) {
            Spacer()
            Text("TRADINGVIEW REFERENCE")
                .font(.system(size: 11, weight: .black))
                .tracking(1.0)
            Text("The web app used an IC Markets TradingView iframe as a visual reference. The native build will add a broker/reference panel later; the AI will still read the native candle feed, not protected iframe pixels.")
                .font(.system(size: 9, weight: .medium))
                .foregroundStyle(ZKTheme.textMuted)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 24)
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(red: 0.031, green: 0.024, blue: 0.043))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }
}
