import SwiftUI

struct ChartView: View {
    private let candles: [ChartCandle] = {
        var result: [ChartCandle] = []
        var price = 4642.0
        for i in 0..<52 {
            let drift = sin(Double(i) * 0.52) * 1.15 + cos(Double(i) * 0.19) * 0.55
            let open = price
            let close = open + drift * 0.32 + (i > 30 ? 0.18 : -0.03)
            let high = max(open, close) + 0.42 + abs(sin(Double(i))) * 0.35
            let low = min(open, close) - 0.38 - abs(cos(Double(i) * 0.7)) * 0.31
            result.append(.init(index: i, open: open, high: high, low: low, close: close))
            price = close
        }
        return result
    }()

    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        MicroLabel(text: "NATIVE CHART • PROTOTYPE")
                        Text("XAUUSD • 1M")
                            .font(.system(size: 25, weight: .black, design: .rounded))
                    }
                    Spacer()
                    Text("LOCAL")
                        .font(.system(size: 10, weight: .black))
                        .foregroundStyle(ZKTheme.purple)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 7)
                        .background(ZKTheme.purple.opacity(0.11))
                        .clipShape(Capsule())
                }

                GlassCard {
                    NativeCandlestickChart(candles: candles)
                        .frame(maxWidth: .infinity)
                        .frame(height: 390)
                }

                GlassCard {
                    VStack(alignment: .leading, spacing: 8) {
                        MicroLabel(text: "NEXT DATA UPGRADE")
                        Text("This is a native SwiftUI chart surface. The next build will replace demo candles with broker-quality XAUUSD data and let the AI draw zones, entry, SL and TP directly.")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundStyle(ZKTheme.muted)
                    }
                }

                Spacer(minLength: 0)
            }
            .padding(16)
            .background(ZKTheme.background)
            .navigationBarHidden(true)
        }
    }
}

struct NativeCandlestickChart: View {
    let candles: [ChartCandle]

    var body: some View {
        GeometryReader { geo in
            let high = candles.map(\.high).max() ?? 1
            let low = candles.map(\.low).min() ?? 0
            let span = max(high - low, 0.001)
            let candleWidth = max(3.2, (geo.size.width - 34) / CGFloat(max(candles.count, 1)) * 0.62)
            let step = (geo.size.width - 34) / CGFloat(max(candles.count - 1, 1))

            ZStack {
                Canvas { context, size in
                    for row in 0...5 {
                        let y = size.height * CGFloat(row) / 5
                        var path = Path()
                        path.move(to: CGPoint(x: 0, y: y))
                        path.addLine(to: CGPoint(x: size.width, y: y))
                        context.stroke(path, with: .color(ZKTheme.border.opacity(0.55)), lineWidth: 0.7)
                    }

                    for c in candles {
                        let x = CGFloat(c.index) * step + 10
                        func y(_ value: Double) -> CGFloat {
                            size.height - CGFloat((value - low) / span) * (size.height - 24) - 12
                        }

                        let color = c.isUp ? ZKTheme.green : ZKTheme.red

                        var wick = Path()
                        wick.move(to: CGPoint(x: x, y: y(c.high)))
                        wick.addLine(to: CGPoint(x: x, y: y(c.low)))
                        context.stroke(wick, with: .color(color.opacity(0.9)), lineWidth: 1)

                        let top = min(y(c.open), y(c.close))
                        let bottom = max(y(c.open), y(c.close))
                        let rect = CGRect(
                            x: x - candleWidth / 2,
                            y: top,
                            width: candleWidth,
                            height: max(bottom - top, 2)
                        )
                        context.fill(Path(roundedRect: rect, cornerRadius: 1), with: .color(color))
                    }
                }

                VStack {
                    HStack {
                        Text("DEMO DATA")
                            .font(.system(size: 9, weight: .black))
                            .foregroundStyle(ZKTheme.gold)
                        Spacer()
                        Text(String(format: "%.2f", candles.last?.close ?? 0))
                            .font(.system(size: 12, weight: .black, design: .monospaced))
                    }
                    Spacer()
                }
                .padding(8)
            }
        }
    }
}
