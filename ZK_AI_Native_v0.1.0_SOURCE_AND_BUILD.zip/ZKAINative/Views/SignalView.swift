import SwiftUI

struct SignalView: View {
    @EnvironmentObject private var state: AppState
    @StateObject private var notifications = NotificationManager.shared
    @State private var requesting = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 12) {
                    header

                    signalCard

                    if let signal = state.activeSignal {
                        levelsCard(signal)
                    }

                    notificationCard
                }
                .padding(16)
            }
            .background(ZKTheme.background)
            .navigationBarHidden(true)
            .task {
                state.notificationPermission = await notifications.refreshStatus()
            }
        }
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                MicroLabel(text: "AI SIGNAL • XAUUSD • 1M")
                Text("Native signal engine")
                    .font(.system(size: 25, weight: .black, design: .rounded))
            }
            Spacer()
            Text(state.activeSignal == nil ? "SCANNING" : "ACTIVE")
                .font(.system(size: 10, weight: .black))
                .foregroundStyle(state.activeSignal == nil ? ZKTheme.gold : ZKTheme.green)
                .padding(.horizontal, 10)
                .padding(.vertical, 7)
                .background((state.activeSignal == nil ? ZKTheme.gold : ZKTheme.green).opacity(0.11))
                .clipShape(Capsule())
        }
    }

    private var signalCard: some View {
        GlassCard {
            VStack(spacing: 15) {
                HStack {
                    VStack(alignment: .leading, spacing: 3) {
                        MicroLabel(text: state.activeSignal?.isDemo == true ? "DEMO SIGNAL" : "CURRENT BIAS")
                        Text(state.activeSignal?.side.rawValue ?? "WAIT")
                            .font(.system(size: 41, weight: .black, design: .rounded))
                            .foregroundStyle(sideColor)
                    }
                    Spacer()

                    ZStack {
                        Circle()
                            .stroke(ZKTheme.border, lineWidth: 8)
                        Circle()
                            .trim(from: 0, to: state.activeSignal?.confidence ?? 0.0)
                            .stroke(sideColor, style: StrokeStyle(lineWidth: 8, lineCap: .round))
                            .rotationEffect(.degrees(-90))
                        VStack(spacing: 1) {
                            Text(state.activeSignal == nil ? "—" : "\(Int((state.activeSignal?.confidence ?? 0) * 100))%")
                                .font(.system(size: 18, weight: .black))
                            Text("CONF")
                                .font(.system(size: 8, weight: .heavy))
                                .foregroundStyle(ZKTheme.muted)
                        }
                    }
                    .frame(width: 86, height: 86)
                }

                Divider().overlay(ZKTheme.border)

                Text(state.activeSignal == nil
                     ? "No live market feed is connected in v0.1. Use the demo button to verify native signal state and iOS notifications."
                     : "Demo signal remains active until you clear it manually. The real build will lock signals until SL or TP is hit.")
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(ZKTheme.muted)
                    .frame(maxWidth: .infinity, alignment: .leading)

                Button {
                    Task {
                        if state.activeSignal == nil {
                            state.activateDemoSignal()
                            if let signal = state.activeSignal {
                                await notifications.sendSignalNotification(signal)
                            }
                        } else {
                            state.clearDemoSignal()
                        }
                    }
                } label: {
                    Text(state.activeSignal == nil ? "ACTIVATE DEMO SIGNAL" : "CLEAR DEMO SIGNAL")
                        .font(.system(size: 13, weight: .black))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                        .background(state.activeSignal == nil ? ZKTheme.accentGradient : LinearGradient(colors: [ZKTheme.red.opacity(0.8), ZKTheme.red], startPoint: .leading, endPoint: .trailing))
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                }
                .buttonStyle(.plain)
            }
        }
    }

    private func levelsCard(_ s: TradeSignal) -> some View {
        GlassCard {
            HStack(spacing: 8) {
                level("ENTRY", s.entry, .white)
                level("SL", s.stopLoss, ZKTheme.red)
                level("TP", s.takeProfit, ZKTheme.green)
                VStack(spacing: 4) {
                    MicroLabel(text: "R:R")
                    Text(String(format: "%.1fR", s.riskReward))
                        .font(.system(size: 14, weight: .black))
                        .foregroundStyle(ZKTheme.purple)
                }
                .frame(maxWidth: .infinity)
            }
        }
    }

    private func level(_ title: String, _ value: Double, _ color: Color) -> some View {
        VStack(spacing: 4) {
            MicroLabel(text: title)
            Text(String(format: "%.2f", value))
                .font(.system(size: 13, weight: .black, design: .monospaced))
                .foregroundStyle(color)
        }
        .frame(maxWidth: .infinity)
    }

    private var notificationCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    VStack(alignment: .leading, spacing: 3) {
                        MicroLabel(text: "IOS NOTIFICATIONS")
                        Text(notifications.statusText)
                            .font(.system(size: 16, weight: .bold))
                    }
                    Spacer()
                    Circle()
                        .fill(state.notificationPermission ? ZKTheme.green : ZKTheme.gold)
                        .frame(width: 9, height: 9)
                }

                Text("Enable this now so future valid signals can trigger native banners, sound and lock-screen alerts.")
                    .font(.system(size: 12))
                    .foregroundStyle(ZKTheme.muted)

                Button {
                    requesting = true
                    Task {
                        state.notificationPermission = await notifications.requestPermission()
                        requesting = false
                    }
                } label: {
                    Text(requesting ? "REQUESTING…" : "ENABLE NOTIFICATIONS")
                        .font(.system(size: 12, weight: .black))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 11)
                        .background(ZKTheme.panel2)
                        .overlay(RoundedRectangle(cornerRadius: 12).stroke(ZKTheme.purple.opacity(0.45)))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }
                .buttonStyle(.plain)
                .disabled(requesting)
            }
        }
    }

    private var sideColor: Color {
        switch state.activeSignal?.side {
        case .buy: ZKTheme.green
        case .sell: ZKTheme.red
        default: ZKTheme.gold
        }
    }
}
