import SwiftUI

struct SignalView: View {
    @EnvironmentObject private var state: AppState
    @StateObject private var notifications = NotificationManager.shared

    private let demoCandles: [ChartCandle] = {
        var result: [ChartCandle] = []
        var price = 4642.0
        for i in 0..<44 {
            let wave = sin(Double(i) * 0.48) * 0.9 + cos(Double(i) * 0.19) * 0.4
            let open = price
            let close = open + wave * 0.27 + (i > 26 ? 0.12 : -0.02)
            let high = max(open, close) + 0.35 + abs(sin(Double(i))) * 0.28
            let low = min(open, close) - 0.32 - abs(cos(Double(i) * 0.7)) * 0.25
            result.append(.init(index: i, open: open, high: high, low: low, close: close))
            price = close
        }
        return result
    }()

    var body: some View {
        GeometryReader { geo in
            VStack(spacing: 7) {
                ZKPageHeader(
                    micro: "AI SIGNAL • 1M",
                    title: "Live model",
                    pill: "NO FEED",
                    pillColor: ZKTheme.gold
                )

                modelStrip
                macroStrip
                signalCore

                chart
                    .frame(maxHeight: .infinity)

                levels
                lifecycle
            }
            .padding(.horizontal, 14)
            .padding(.top, 8)
            .padding(.bottom, 8)
        }
        .background(ZKTheme.background)
        .task {
            state.notificationPermission = await notifications.refresh()
        }
    }

    private var modelStrip: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("ACTIVE MODEL")
                    .font(.system(size: 6, weight: .black))
                    .tracking(0.8)
                    .foregroundStyle(ZKTheme.textMuted)
                Text(state.selectedModel?.name ?? "UNTRAINED")
                    .font(.system(size: 10, weight: .bold))
            }
            Spacer()
            Text(state.selectedModel?.evidence ?? "EXPERIMENTAL")
                .font(.system(size: 7, weight: .black))
                .tracking(0.6)
                .foregroundStyle(Color(red: 0.831, green: 0.580, blue: 0.898))
                .padding(.horizontal, 8)
                .padding(.vertical, 5)
                .background(Color(red: 0.086, green: 0.051, blue: 0.110))
                .overlay(Capsule().stroke(ZKTheme.borderStrong))
                .clipShape(Capsule())
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 8)
        .background(
            LinearGradient(
                colors: [Color(red: 0.063, green: 0.043, blue: 0.078), Color(red: 0.031, green: 0.024, blue: 0.043)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(ZKTheme.borderStrong))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private var macroStrip: some View {
        HStack(spacing: 4) {
            stripCell("GOLD REGIME", state.macroRegime)
            stripCell("USD", "—")
            stripCell("YIELDS", "—")
            stripCell("COT", "—")
        }
    }

    private func stripCell(_ title: String, _ value: String) -> some View {
        VStack(spacing: 2) {
            Text(title)
                .font(.system(size: 5, weight: .black))
                .foregroundStyle(ZKTheme.textMuted)
            Text(value)
                .font(.system(size: 7, weight: .black))
                .foregroundStyle(.white.opacity(0.85))
                .lineLimit(1)
                .minimumScaleFactor(0.7)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 5)
        .background(Color(red: 0.035, green: 0.027, blue: 0.051))
        .overlay(RoundedRectangle(cornerRadius: 9).stroke(ZKTheme.border.opacity(0.85)))
        .clipShape(RoundedRectangle(cornerRadius: 9))
    }

    private var signalCore: some View {
        let sideColor: Color = {
            switch state.signal.side {
            case .buy: return ZKTheme.green
            case .sell: return ZKTheme.red
            case .wait: return ZKTheme.gold
            }
        }()

        return VStack(spacing: 7) {
            HStack(alignment: .top) {
                HStack(spacing: 9) {
                    SignalOrb(color: sideColor)
                    VStack(alignment: .leading, spacing: 3) {
                        Text("AI BIAS")
                            .font(.system(size: 6, weight: .black))
                            .tracking(0.8)
                            .foregroundStyle(ZKTheme.textSoft)

                        Text(state.signal.side.rawValue)
                            .font(.system(size: 29, weight: .black, design: .rounded))
                            .tracking(-1.0)
                            .foregroundStyle(sideColor)

                        HStack(spacing: 4) {
                            Circle().fill(sideColor).frame(width: 5, height: 5).shadow(color: sideColor, radius: 4)
                            Text("LEARNING MODE")
                                .font(.system(size: 6, weight: .bold))
                                .foregroundStyle(ZKTheme.textSoft)
                        }
                        .padding(.horizontal, 6)
                        .padding(.vertical, 3)
                        .background(Color(red: 0.063, green: 0.043, blue: 0.078))
                        .overlay(Capsule().stroke(ZKTheme.border))
                        .clipShape(Capsule())
                    }
                }

                Spacer()

                VStack(spacing: 2) {
                    ConfidenceRing(value: state.signal.executionConfidence, color: sideColor, label: "EXEC")
                    Text("UNTRAINED")
                        .font(.system(size: 6, weight: .bold))
                        .foregroundStyle(ZKTheme.textSoft)
                }
            }

            HStack(spacing: 5) {
                ProbabilityCell(label: "BUY", value: state.signal.buyProbability, color: ZKTheme.green)
                ProbabilityCell(label: "WAIT", value: state.signal.waitProbability, color: ZKTheme.gold)
                ProbabilityCell(label: "SELL", value: state.signal.sellProbability, color: ZKTheme.red)
            }

            HStack(spacing: 5) {
                confidenceMini("DIRECTIONAL", state.signal.directionalConfidence)
                confidenceMini("WAIT", state.signal.waitProbability)
                confidenceMini("EXECUTION", state.signal.executionConfidence)
            }

            Text(state.signal.reason)
                .font(.system(size: 8, weight: .medium))
                .foregroundStyle(ZKTheme.textMuted)
                .frame(maxWidth: .infinity, alignment: .leading)
                .lineLimit(2)
        }
        .padding(11)
        .background(
            RadialGradient(
                colors: [sideColor.opacity(0.10), Color(red: 0.051, green: 0.035, blue: 0.067)],
                center: .topTrailing,
                startRadius: 0,
                endRadius: 180
            )
        )
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(sideColor.opacity(0.26)))
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }

    private func confidenceMini(_ title: String, _ value: Double) -> some View {
        VStack(spacing: 2) {
            Text(title)
                .font(.system(size: 5, weight: .black))
                .foregroundStyle(ZKTheme.textMuted)
            Text("\(Int(value * 100))%")
                .font(.system(size: 8, weight: .black, design: .monospaced))
        }
        .frame(maxWidth: .infinity)
    }

    private var chart: some View {
        ZStack(alignment: .top) {
            NativeAgentChart(candles: demoCandles, drawings: state.drawings)
                .padding(.top, 26)

            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 1) {
                    Text("XAUUSD")
                        .font(.system(size: 10, weight: .black))
                    Text("Demo native candles • no live feed")
                        .font(.system(size: 6))
                        .foregroundStyle(ZKTheme.textMuted)
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 1) {
                    Text("SOURCE")
                        .font(.system(size: 5, weight: .black))
                        .foregroundStyle(ZKTheme.textMuted)
                    Text("DEMO")
                        .font(.system(size: 10, weight: .black))
                }
            }
            .padding(9)
        }
        .frame(minHeight: 125)
        .background(
            RadialGradient(
                colors: [ZKTheme.purple.opacity(0.07), Color(red: 0.031, green: 0.024, blue: 0.043)],
                center: .topTrailing,
                startRadius: 0,
                endRadius: 220
            )
        )
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(ZKTheme.borderStrong))
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }

    private var levels: some View {
        HStack(spacing: 5) {
            level("VALID AT", state.signal.entry)
            level("SL", state.signal.stopLoss)
            level("TP", state.signal.takeProfit)
            VStack(spacing: 2) {
                Text("R:R")
                    .font(.system(size: 5, weight: .black))
                    .foregroundStyle(ZKTheme.textMuted)
                Text(state.signal.riskReward.map { String(format: "%.1fR", $0) } ?? "—")
                    .font(.system(size: 9, weight: .black, design: .monospaced))
                    .foregroundStyle(Color(red: 0.831, green: 0.478, blue: 0.894))
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 7)
            .background(Color(red: 0.035, green: 0.027, blue: 0.051))
            .overlay(RoundedRectangle(cornerRadius: 11).stroke(ZKTheme.border))
            .clipShape(RoundedRectangle(cornerRadius: 11))
        }
    }

    private func level(_ title: String, _ value: Double?) -> some View {
        VStack(spacing: 2) {
            Text(title)
                .font(.system(size: 5, weight: .black))
                .foregroundStyle(ZKTheme.textMuted)
            Text(value.map { String(format: "%.2f", $0) } ?? "HIDDEN")
                .font(.system(size: 8, weight: .black, design: .monospaced))
                .foregroundStyle(.white.opacity(0.90))
                .minimumScaleFactor(0.65)
                .lineLimit(1)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 7)
        .background(Color(red: 0.035, green: 0.027, blue: 0.051))
        .overlay(RoundedRectangle(cornerRadius: 11).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 11))
    }

    private var lifecycle: some View {
        HStack(spacing: 5) {
            Circle().fill(ZKTheme.gold).frame(width: 6, height: 6)
            Text(state.signal.lifecycle)
                .font(.system(size: 6, weight: .black))
                .foregroundStyle(.white.opacity(0.86))
            Spacer()
            Button {
                Task {
                    if !state.notificationPermission {
                        state.notificationPermission = await notifications.request()
                    }
                    if state.notificationPermission {
                        await notifications.sendDemo()
                    }
                }
            } label: {
                Text(state.notificationPermission ? "TEST ALERT" : "ENABLE ALERTS")
                    .font(.system(size: 6, weight: .black))
                    .foregroundStyle(Color(red: 0.831, green: 0.478, blue: 0.894))
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 8)
        .frame(height: 28)
        .background(Color(red: 0.035, green: 0.027, blue: 0.051))
        .overlay(RoundedRectangle(cornerRadius: 10).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }
}
