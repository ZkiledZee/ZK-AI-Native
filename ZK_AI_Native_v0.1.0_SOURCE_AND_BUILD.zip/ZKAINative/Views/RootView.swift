import SwiftUI

struct RootView: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        ZStack {
            ZKTheme.background.ignoresSafeArea()

            Group {
                switch state.page {
                case .home: HomeView()
                case .signal: SignalView()
                case .chart: ChartView()
                case .lab: AILabView()
                case .chat: ChatView()
                }
            }
            .transition(.opacity)
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            BottomNav()
                .environmentObject(state)
        }
    }
}
