import SwiftUI

struct RootView: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        ZStack {
            ZKTheme.background.ignoresSafeArea()

            TabView(selection: $state.selectedTab) {
                HomeView()
                    .tag(0)
                    .tabItem { Label("Home", systemImage: "house.fill") }

                SignalView()
                    .tag(1)
                    .tabItem { Label("Signal", systemImage: "waveform.path.ecg") }

                ChartView()
                    .tag(2)
                    .tabItem { Label("Chart", systemImage: "chart.xyaxis.line") }

                AILabView()
                    .tag(3)
                    .tabItem { Label("AI Lab", systemImage: "brain.head.profile") }

                ChatView()
                    .tag(4)
                    .tabItem { Label("Chat", systemImage: "bubble.left.and.bubble.right.fill") }
            }
            .tint(ZKTheme.purple)
        }
    }
}
