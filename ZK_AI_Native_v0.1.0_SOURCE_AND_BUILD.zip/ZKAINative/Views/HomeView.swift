import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var state: AppState
    @State private var drift = false

    var body: some View {
        GeometryReader { geo in
            ZStack {
                ambient

                VStack(spacing: 14) {
                    Spacer(minLength: 6)

                    VStack(spacing: 4) {
                        HomeLogo()
                            .padding(.bottom, 2)

                        ZKMicroLabel(text: "XAUUSD • NATIVE AI")

                        Text("AI Scalper")
                            .font(.system(size: min(44, geo.size.width * 0.112), weight: .black, design: .rounded))
                            .tracking(-2)
                            .foregroundStyle(
                                LinearGradient(
                                    colors: [.white, Color(red: 0.843, green: 0.788, blue: 0.867), Color(red: 0.655, green: 0.416, blue: 0.741)],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )

                        Text("Learn the market. Test it. Then predict.")
                            .font(.system(size: 11, weight: .medium))
                            .foregroundStyle(ZKTheme.textMuted)

                        HStack(spacing: 6) {
                            Circle()
                                .fill(ZKTheme.green)
                                .frame(width: 6, height: 6)
                                .shadow(color: ZKTheme.green, radius: 5)
                            Text("NATIVE FOUNDATION")
                                .font(.system(size: 7, weight: .black))
                                .tracking(0.8)
                                .foregroundStyle(ZKTheme.textSoft)
                        }
                        .padding(.horizontal, 9)
                        .padding(.vertical, 6)
                        .background(Color(red: 0.039, green: 0.027, blue: 0.063))
                        .overlay(Capsule().stroke(ZKTheme.border))
                        .clipShape(Capsule())
                        .padding(.top, 4)
                    }

                    VStack(spacing: 9) {
                        HomeActionButton(
                            glyph: "◆",
                            title: "AI Signal",
                            subtitle: "AI probability → ideal entry → structure SL / 2R+ TP",
                            primary: true
                        ) { state.go(.signal) }

                        HomeActionButton(
                            glyph: "✦",
                            title: "AI Lab",
                            subtitle: "Model Vault, Macro AI, diagnostics and evidence status"
                        ) { state.go(.lab) }

                        HomeActionButton(
                            glyph: "◌",
                            title: "Talk to ZK AI",
                            subtitle: "Ask what it sees, manage drawings and explain model state"
                        ) { state.go(.chat) }
                    }

                    Spacer(minLength: 6)
                }
                .padding(.horizontal, 14)
                .padding(.top, 6)
            }
        }
        .background(ZKTheme.background)
    }

    private var ambient: some View {
        ZStack {
            Circle()
                .fill(ZKTheme.purple.opacity(0.12))
                .frame(width: 260, height: 260)
                .blur(radius: 30)
                .offset(x: drift ? -75 : -145, y: drift ? -180 : -235)

            Circle()
                .fill(ZKTheme.pink.opacity(0.07))
                .frame(width: 240, height: 240)
                .blur(radius: 30)
                .offset(x: drift ? 115 : 175, y: drift ? 260 : 310)

            ForEach(0..<6, id: \.self) { i in
                Circle()
                    .fill(ZKTheme.purple.opacity(0.28))
                    .frame(width: 3, height: 3)
                    .shadow(color: ZKTheme.purple, radius: 4)
                    .offset(
                        x: CGFloat([-130, 110, 150, -85, 15, 80][i]),
                        y: CGFloat([180, 210, -70, -20, 270, -180][i]) + (drift ? -35 : 30)
                    )
            }
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 9).repeatForever(autoreverses: true)) {
                drift = true
            }
        }
    }
}
