import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var state: AppState
    @State private var pulse = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    Spacer(minLength: 16)

                    ZStack {
                        Circle()
                            .stroke(ZKTheme.purple.opacity(0.22), lineWidth: 1)
                            .frame(width: 132, height: 132)
                            .scaleEffect(pulse ? 1.12 : 0.96)
                            .opacity(pulse ? 0.15 : 0.65)

                        Circle()
                            .fill(ZKTheme.accentGradient)
                            .frame(width: 104, height: 104)
                            .shadow(color: ZKTheme.purple.opacity(0.4), radius: 28)

                        Text("ZK")
                            .font(.system(size: 39, weight: .black, design: .rounded))
                            .foregroundStyle(.white)
                    }
                    .onAppear {
                        withAnimation(.easeInOut(duration: 2.0).repeatForever(autoreverses: true)) {
                            pulse = true
                        }
                    }

                    VStack(spacing: 5) {
                        MicroLabel(text: "XAUUSD • NATIVE IOS")
                        Text("AI Scalper")
                            .font(.system(size: 38, weight: .black, design: .rounded))
                        Text("Native foundation for the trading system.")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundStyle(ZKTheme.muted)
                    }

                    statusCard

                    actionButton(
                        title: "AI Signal",
                        subtitle: "Native signal lifecycle + notifications",
                        icon: "bolt.fill",
                        tab: 1
                    )

                    actionButton(
                        title: "Native Chart",
                        subtitle: "Fast SwiftUI chart surface",
                        icon: "chart.xyaxis.line",
                        tab: 2
                    )

                    actionButton(
                        title: "AI Lab",
                        subtitle: "Model Vault + Gold Intelligence foundation",
                        icon: "brain.head.profile",
                        tab: 3
                    )

                    actionButton(
                        title: "Talk to ZK AI",
                        subtitle: "Local agent interface foundation",
                        icon: "bubble.left.and.bubble.right.fill",
                        tab: 4
                    )
                }
                .padding(16)
            }
            .scrollIndicators(.hidden)
            .background(ZKTheme.background)
            .toolbar(.hidden, for: .navigationBar)
        }
    }

    private var statusCard: some View {
        GlassCard {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    MicroLabel(text: "BUILD")
                    Text("Native v0.1.0")
                        .font(.system(size: 17, weight: .bold))
                    Text("Launch \(state.launchCount) • local storage active")
                        .font(.system(size: 12))
                        .foregroundStyle(ZKTheme.muted)
                }

                Spacer()

                Text("READY")
                    .font(.system(size: 11, weight: .black))
                    .padding(.horizontal, 11)
                    .padding(.vertical, 7)
                    .background(ZKTheme.green.opacity(0.12))
                    .foregroundStyle(ZKTheme.green)
                    .clipShape(Capsule())
            }
        }
    }

    private func actionButton(title: String, subtitle: String, icon: String, tab: Int) -> some View {
        Button {
            state.selectedTab = tab
        } label: {
            GlassCard {
                HStack(spacing: 13) {
                    Image(systemName: icon)
                        .font(.system(size: 20, weight: .bold))
                        .frame(width: 42, height: 42)
                        .background(ZKTheme.purple.opacity(0.14))
                        .foregroundStyle(ZKTheme.purple)
                        .clipShape(RoundedRectangle(cornerRadius: 13))

                    VStack(alignment: .leading, spacing: 3) {
                        Text(title)
                            .font(.system(size: 16, weight: .bold))
                            .foregroundStyle(.white)
                        Text(subtitle)
                            .font(.system(size: 12))
                            .foregroundStyle(ZKTheme.muted)
                    }

                    Spacer()

                    Image(systemName: "chevron.right")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(ZKTheme.muted)
                }
            }
        }
        .buttonStyle(.plain)
    }
}
