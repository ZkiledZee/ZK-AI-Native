import SwiftUI

struct AILabView: View {
    @EnvironmentObject private var state: AppState

    private let macroComponents: [MacroComponent] = [
        .init(name: "DXY / USD", value: "NOT CONNECTED", detail: "Live dollar pressure", state: .unavailable),
        .init(name: "US 10Y / REAL YIELD", value: "NOT CONNECTED", detail: "Rates pressure", state: .unavailable),
        .init(name: "COT GOLD", value: "PLANNED", detail: "Managed Money + percentiles", state: .neutral),
        .init(name: "SILVER", value: "NOT CONNECTED", detail: "Precious-metals confirmation", state: .unavailable),
        .init(name: "NEWS", value: "PLANNED", detail: "CPI • NFP • FOMC • PCE", state: .neutral),
        .init(name: "EXECUTION GATE", value: "WAIT", detail: "Market AI → Macro AI → Risk gate", state: .neutral)
    ]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 12) {
                    header
                    architectureCard
                    modelVault
                    goldIntelligence
                }
                .padding(16)
            }
            .background(ZKTheme.background)
            .navigationBarHidden(true)
        }
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                MicroLabel(text: "NATIVE AI FOUNDATION")
                Text("AI Lab")
                    .font(.system(size: 28, weight: .black, design: .rounded))
            }
            Spacer()
            Text("v0.1")
                .font(.system(size: 10, weight: .black))
                .foregroundStyle(ZKTheme.purple)
        }
    }

    private var architectureCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 12) {
                MicroLabel(text: "TARGET ARCHITECTURE")

                flow("1", "MARKET AI", "Price • structure • momentum • volatility • MFE/MAE")
                arrow
                flow("2", "MACRO AI", "USD • yields • COT • news • silver • risk regime")
                arrow
                flow("3", "EXECUTION GATE", "Expected value • structure • spread • 2R+ filter")

                Text("The talking AI will explain and use tools. It will not be allowed to override the numerical trading model.")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(ZKTheme.muted)
                    .padding(.top, 3)
            }
        }
    }

    private func flow(_ number: String, _ title: String, _ subtitle: String) -> some View {
        HStack(spacing: 10) {
            Text(number)
                .font(.system(size: 11, weight: .black))
                .frame(width: 27, height: 27)
                .background(ZKTheme.purple.opacity(0.14))
                .foregroundStyle(ZKTheme.purple)
                .clipShape(RoundedRectangle(cornerRadius: 9))

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 12, weight: .black))
                Text(subtitle)
                    .font(.system(size: 11))
                    .foregroundStyle(ZKTheme.muted)
            }
            Spacer()
        }
    }

    private var arrow: some View {
        Image(systemName: "chevron.down")
            .font(.system(size: 9, weight: .bold))
            .foregroundStyle(ZKTheme.border)
            .padding(.leading, 8)
    }

    private var modelVault: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    VStack(alignment: .leading, spacing: 3) {
                        MicroLabel(text: "MODEL VAULT")
                        Text("Active + challengers + rollback")
                            .font(.system(size: 14, weight: .bold))
                    }
                    Spacer()
                    Text("\(state.models.count) SAVED")
                        .font(.system(size: 9, weight: .black))
                        .foregroundStyle(ZKTheme.muted)
                }

                Picker("Model", selection: Binding(
                    get: { state.selectedModelID ?? state.models.first!.id },
                    set: { state.selectedModelID = $0 }
                )) {
                    ForEach(state.models) { model in
                        Text("\(model.status) • \(model.name)").tag(model.id)
                    }
                }
                .pickerStyle(.menu)
                .tint(.white)

                if let model = state.models.first(where: { $0.id == state.selectedModelID }) {
                    HStack {
                        metric("SAMPLES", "\(model.samples)")
                        metric("PF", model.profitFactor == 0 ? "—" : String(format: "%.2f", model.profitFactor))
                        metric("EXP", model.expectancyR == 0 ? "—" : String(format: "%+.2fR", model.expectancyR))
                        metric("DD", model.drawdownR == 0 ? "—" : String(format: "%.1fR", model.drawdownR))
                    }
                }

                Text("Native model persistence is wired. The actual Core ML challenger models come after the install pipeline is proven.")
                    .font(.system(size: 11))
                    .foregroundStyle(ZKTheme.muted)
            }
        }
    }

    private func metric(_ name: String, _ value: String) -> some View {
        VStack(spacing: 3) {
            MicroLabel(text: name)
            Text(value)
                .font(.system(size: 12, weight: .black, design: .monospaced))
        }
        .frame(maxWidth: .infinity)
    }

    private var goldIntelligence: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    VStack(alignment: .leading, spacing: 3) {
                        MicroLabel(text: "GOLD INTELLIGENCE")
                        Text("Macro regime")
                            .font(.system(size: 14, weight: .bold))
                    }
                    Spacer()
                    Text("NO DATA")
                        .font(.system(size: 9, weight: .black))
                        .foregroundStyle(ZKTheme.gold)
                }

                ForEach(macroComponents) { component in
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(component.name)
                                .font(.system(size: 11, weight: .bold))
                            Text(component.detail)
                                .font(.system(size: 10))
                                .foregroundStyle(ZKTheme.muted)
                        }
                        Spacer()
                        Text(component.value)
                            .font(.system(size: 9, weight: .black))
                            .foregroundStyle(componentColor(component.state))
                    }
                    .padding(.vertical, 5)

                    if component.id != macroComponents.last?.id {
                        Divider().overlay(ZKTheme.border)
                    }
                }
            }
        }
    }

    private func componentColor(_ state: MacroState) -> Color {
        switch state {
        case .bullish: ZKTheme.green
        case .bearish: ZKTheme.red
        case .neutral: ZKTheme.gold
        case .unavailable: ZKTheme.muted
        }
    }
}
