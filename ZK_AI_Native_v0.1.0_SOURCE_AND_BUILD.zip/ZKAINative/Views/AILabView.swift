import SwiftUI

struct AILabView: View {
    @EnvironmentObject private var state: AppState

    private let macroItems: [MacroItem] = [
        .init(name: "DXY / USD", value: "—", subtitle: "Dollar pressure", state: .unavailable),
        .init(name: "US 10Y", value: "—", subtitle: "Yield pressure", state: .unavailable),
        .init(name: "COT GOLD", value: "—", subtitle: "Managed Money", state: .unavailable),
        .init(name: "SILVER", value: "—", subtitle: "Precious metals", state: .unavailable),
        .init(name: "EURUSD", value: "—", subtitle: "USD cross-check", state: .unavailable),
        .init(name: "USDJPY", value: "—", subtitle: "USD cross-check", state: .unavailable),
        .init(name: "VIX", value: "—", subtitle: "Risk stress", state: .unavailable),
        .init(name: "NEWS", value: "—", subtitle: "CPI • NFP • FOMC", state: .unavailable)
    ]

    var body: some View {
        ScrollView {
            VStack(spacing: 8) {
                ZKPageHeader(
                    micro: "NATIVE MACHINE LEARNING",
                    title: "AI Lab",
                    pill: "READY",
                    pillColor: ZKTheme.green
                )

                labHero
                modelVault
                multiLayer
                macroCard
                evidenceCard
                journalDiagnostics
            }
            .padding(.horizontal, 14)
            .padding(.top, 8)
            .padding(.bottom, 16)
        }
        .scrollIndicators(.hidden)
        .background(ZKTheme.background)
    }

    private var labHero: some View {
        HStack(spacing: 10) {
            Text("✦")
                .font(.system(size: 24, weight: .black))
                .foregroundStyle(Color(red: 0.855, green: 0.490, blue: 0.925))
                .frame(width: 48, height: 48)
                .background(Color(red: 0.094, green: 0.051, blue: 0.114))
                .overlay(RoundedRectangle(cornerRadius: 15).stroke(ZKTheme.borderStrong))
                .clipShape(RoundedRectangle(cornerRadius: 15))
                .shadow(color: ZKTheme.purple.opacity(0.12), radius: 16)

            VStack(alignment: .leading, spacing: 2) {
                Text("ACTIVE")
                    .font(.system(size: 6, weight: .black))
                    .tracking(0.8)
                    .foregroundStyle(ZKTheme.textMuted)
                Text(state.selectedModel?.name ?? "No trained model")
                    .font(.system(size: 13, weight: .bold))
                Text("Load broker history, train chronologically, then paper-test a challenger.")
                    .font(.system(size: 7, weight: .medium))
                    .foregroundStyle(ZKTheme.textMuted)
                    .lineLimit(2)
            }
            Spacer()
        }
        .padding(10)
        .background(
            RadialGradient(
                colors: [ZKTheme.purple.opacity(0.10), Color(red: 0.059, green: 0.039, blue: 0.075)],
                center: .topTrailing,
                startRadius: 0,
                endRadius: 180
            )
        )
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(ZKTheme.borderStrong))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    private var modelVault: some View {
        ZKCard {
            VStack(alignment: .leading, spacing: 8) {
                sectionHeader("MODEL VAULT", "Active + challengers + older models", trailing: "\(state.models.count) SAVED")

                Menu {
                    ForEach(state.models) { model in
                        Button("\(model.status) • \(model.name)") {
                            state.selectedModelID = model.id
                        }
                    }
                } label: {
                    HStack {
                        Text(state.selectedModel.map { "\($0.status) • \($0.name)" } ?? "No saved models")
                            .font(.system(size: 9, weight: .bold))
                            .foregroundStyle(.white)
                        Spacer()
                        Text("⌄").foregroundStyle(ZKTheme.textSoft)
                    }
                    .padding(.horizontal, 10)
                    .frame(height: 40)
                    .background(Color(red: 0.039, green: 0.027, blue: 0.063))
                    .overlay(RoundedRectangle(cornerRadius: 11).stroke(ZKTheme.borderStrong))
                    .clipShape(RoundedRectangle(cornerRadius: 11))
                }

                if let m = state.selectedModel {
                    Text("\(m.evidence) • Train: \(m.trainRange) • Unseen: \(m.unseenRange)")
                        .font(.system(size: 7, weight: .medium))
                        .foregroundStyle(ZKTheme.textMuted)

                    HStack(spacing: 4) {
                        MetricCell(label: "TRADES", value: "\(m.resolvedTrades)")
                        MetricCell(label: "PF", value: m.profitFactor.map { String(format: "%.2f", $0) } ?? "—")
                        MetricCell(label: "EXP", value: m.expectancyR.map { String(format: "%+.2fR", $0) } ?? "—")
                        MetricCell(label: "DD", value: m.drawdownR.map { String(format: "%.1fR", $0) } ?? "—")
                    }
                }
            }
        }
    }

    private var multiLayer: some View {
        ZKCard {
            VStack(alignment: .leading, spacing: 8) {
                sectionHeader("MULTI-LAYER AI", "Market AI → Macro AI → Execution Gate", trailing: "WAIT")

                HStack(spacing: 4) {
                    flow("1", "MARKET AI", "Price • structure • MFE/MAE")
                    Text("›").foregroundStyle(Color(red: 0.463, green: 0.333, blue: 0.506))
                    flow("2", "MACRO AI", "USD • yields • COT • news")
                    Text("›").foregroundStyle(Color(red: 0.463, green: 0.333, blue: 0.506))
                    flow("3", "EXECUTION", "EV • spread • 2R+ gate")
                }
            }
        }
    }

    private func flow(_ num: String, _ title: String, _ subtitle: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(num)
                .font(.system(size: 6, weight: .black))
                .foregroundStyle(Color(red: 0.831, green: 0.478, blue: 0.894))
                .frame(width: 17, height: 17)
                .overlay(RoundedRectangle(cornerRadius: 6).stroke(ZKTheme.borderStrong))
            Text(title)
                .font(.system(size: 7, weight: .black))
            Text(subtitle)
                .font(.system(size: 5.5, weight: .medium))
                .foregroundStyle(ZKTheme.textMuted)
                .lineLimit(2)
        }
        .padding(7)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(red: 0.035, green: 0.027, blue: 0.051))
        .overlay(RoundedRectangle(cornerRadius: 10).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }

    private var macroCard: some View {
        ZKCard {
            VStack(alignment: .leading, spacing: 8) {
                sectionHeader("GOLD INTELLIGENCE", "Macro regime unavailable", trailing: "\(Int(state.macroCoverage * 100))% COVERAGE")

                HStack(spacing: 9) {
                    VStack(spacing: 1) {
                        Text("—")
                            .font(.system(size: 20, weight: .black))
                        Text("REGIME")
                            .font(.system(size: 5, weight: .black))
                            .foregroundStyle(ZKTheme.textMuted)
                    }
                    .frame(width: 70, height: 62)
                    .background(ZKTheme.purple.opacity(0.06))
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(ZKTheme.borderStrong))
                    .clipShape(RoundedRectangle(cornerRadius: 14))

                    VStack(alignment: .leading, spacing: 4) {
                        Text("Macro influence is gated off")
                            .font(.system(size: 8, weight: .bold))
                        Text("Below 50–60% future source coverage, Macro AI stays informational and cannot materially alter a trade.")
                            .font(.system(size: 7, weight: .medium))
                            .foregroundStyle(ZKTheme.textMuted)
                    }
                }

                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 5) {
                    ForEach(macroItems) { item in
                        VStack(alignment: .leading, spacing: 2) {
                            Text(item.name)
                                .font(.system(size: 5, weight: .black))
                                .foregroundStyle(ZKTheme.textMuted)
                            Text(item.value)
                                .font(.system(size: 8, weight: .black))
                            Text(item.subtitle)
                                .font(.system(size: 5.5, weight: .medium))
                                .foregroundStyle(Color(red: 0.388, green: 0.357, blue: 0.408))
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(7)
                        .background(Color(red: 0.035, green: 0.027, blue: 0.051))
                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(ZKTheme.border))
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                    }
                }

                HStack {
                    Text("COT planned: net, weekly Δ, %OI, 13/52w percentile, z-score")
                        .font(.system(size: 6, weight: .medium))
                        .foregroundStyle(ZKTheme.textMuted)
                    Spacer()
                }
            }
        }
    }

    private var evidenceCard: some View {
        ZKCard {
            VStack(alignment: .leading, spacing: 8) {
                sectionHeader("MODEL EVIDENCE", "Minimum proof before promotion", trailing: state.selectedModel?.evidence ?? "EXPERIMENTAL")

                HStack(spacing: 5) {
                    evidence("EXPERIMENTAL", "0–99 unseen")
                    evidence("DEVELOPING", "100–299 unseen")
                    evidence("VALIDATED", "300+ unseen")
                }

                Text("Promotion also requires positive expectancy after costs, acceptable drawdown, and no single period carrying the result.")
                    .font(.system(size: 7, weight: .medium))
                    .foregroundStyle(ZKTheme.textMuted)
            }
        }
    }

    private func evidence(_ title: String, _ subtitle: String) -> some View {
        VStack(spacing: 2) {
            Text(title)
                .font(.system(size: 6, weight: .black))
            Text(subtitle)
                .font(.system(size: 5.5))
                .foregroundStyle(ZKTheme.textMuted)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 7)
        .background(Color(red: 0.035, green: 0.027, blue: 0.051))
        .overlay(RoundedRectangle(cornerRadius: 9).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 9))
    }

    private var journalDiagnostics: some View {
        ZKCard {
            VStack(alignment: .leading, spacing: 7) {
                sectionHeader("TRADE JOURNAL", "Diagnostics foundation", trailing: "\(state.journal.count) TRADES")
                Text("Each future trade will save model probabilities, macro coverage, DXY/yields, volatility, structure, spread, session, similarity, entry/SL/TP and outcome.")
                    .font(.system(size: 7, weight: .medium))
                    .foregroundStyle(ZKTheme.textMuted)
            }
        }
    }

    private func sectionHeader(_ micro: String, _ title: String, trailing: String) -> some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 2) {
                Text(micro)
                    .font(.system(size: 6, weight: .black))
                    .tracking(0.8)
                    .foregroundStyle(ZKTheme.textMuted)
                Text(title)
                    .font(.system(size: 9, weight: .bold))
            }
            Spacer()
            Text(trailing)
                .font(.system(size: 6, weight: .bold))
                .foregroundStyle(ZKTheme.textSoft)
        }
    }
}
