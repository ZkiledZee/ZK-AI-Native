import SwiftUI

struct ChatView: View {
    @EnvironmentObject private var state: AppState
    @State private var input = ""

    var body: some View {
        VStack(spacing: 7) {
            ZKPageHeader(
                micro: "GROUNDED MODEL ASSISTANT",
                title: "ZK AI Chat",
                pill: "LOCAL",
                pillColor: ZKTheme.green
            )

            statusBar

            messages
                .frame(maxHeight: .infinity)

            chips
            composer
        }
        .padding(.horizontal, 14)
        .padding(.top, 8)
        .padding(.bottom, 8)
        .background(ZKTheme.background)
    }

    private var statusBar: some View {
        HStack(spacing: 8) {
            VStack(alignment: .leading, spacing: 2) {
                Text(state.selectedModel?.name ?? "No trading model trained")
                    .font(.system(size: 7, weight: .bold))
                    .foregroundStyle(.white.opacity(0.86))
                Text("Market: no verified feed")
                    .font(.system(size: 6, weight: .medium))
                    .foregroundStyle(ZKTheme.textMuted)
            }

            Spacer()

            Button {
                state.agentLoaded.toggle()
            } label: {
                Text(state.agentLoaded ? "AGENT READY" : "LOAD AGENT")
                    .font(.system(size: 6, weight: .black))
                    .foregroundStyle(Color(red: 0.831, green: 0.478, blue: 0.894))
                    .padding(.horizontal, 9)
                    .frame(height: 30)
                    .background(Color(red: 0.086, green: 0.051, blue: 0.110))
                    .overlay(RoundedRectangle(cornerRadius: 9).stroke(ZKTheme.borderStrong))
                    .clipShape(RoundedRectangle(cornerRadius: 9))
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 8)
        .background(Color(red: 0.043, green: 0.031, blue: 0.063))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }

    private var messages: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 7) {
                    ForEach(state.chatMessages) { message in
                        bubble(message)
                            .id(message.id)
                    }
                }
                .padding(.vertical, 2)
            }
            .scrollIndicators(.hidden)
            .onChange(of: state.chatMessages.count) {
                if let last = state.chatMessages.last {
                    withAnimation(.easeOut(duration: 0.18)) {
                        proxy.scrollTo(last.id, anchor: .bottom)
                    }
                }
            }
        }
    }

    private func bubble(_ msg: ChatMessage) -> some View {
        HStack {
            if msg.role == .user { Spacer(minLength: 44) }

            VStack(alignment: .leading, spacing: 3) {
                Text(msg.role == .user ? "YOU" : "ZK AI")
                    .font(.system(size: 6, weight: .black))
                    .tracking(0.7)
                    .foregroundStyle(msg.role == .user ? Color(red: 0.831, green: 0.478, blue: 0.894) : ZKTheme.textMuted)
                Text(msg.text)
                    .font(.system(size: 9, weight: .medium))
                    .foregroundStyle(.white.opacity(0.90))
                    .lineSpacing(1.5)
            }
            .padding(10)
            .background(msg.role == .user ? Color(red: 0.086, green: 0.051, blue: 0.110) : Color(red: 0.043, green: 0.031, blue: 0.063))
            .overlay(
                RoundedRectangle(cornerRadius: 13)
                    .stroke(msg.role == .user ? ZKTheme.borderStrong : ZKTheme.border)
            )
            .clipShape(RoundedRectangle(cornerRadius: 13))

            if msg.role == .assistant { Spacer(minLength: 44) }
        }
    }

    private var chips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 5) {
                chip("What do you see?")
                chip("Why waiting?")
                chip("Performance")
                chip("Macro status")
                chip("Mark chart")
                chip("Clear drawings")
            }
        }
        .frame(height: 30)
    }

    private func chip(_ text: String) -> some View {
        Button {
            state.sendChat(text)
        } label: {
            Text(text)
                .font(.system(size: 6.5, weight: .bold))
                .foregroundStyle(ZKTheme.textSoft)
                .padding(.horizontal, 9)
                .frame(height: 26)
                .background(Color(red: 0.043, green: 0.031, blue: 0.063))
                .overlay(Capsule().stroke(ZKTheme.border))
                .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }

    private var composer: some View {
        HStack(spacing: 6) {
            TextField("Ask ZK AI about the market or model…", text: $input)
                .font(.system(size: 9, weight: .medium))
                .padding(.horizontal, 11)
                .frame(height: 42)
                .background(Color(red: 0.043, green: 0.031, blue: 0.063))
                .overlay(RoundedRectangle(cornerRadius: 13).stroke(ZKTheme.borderStrong))
                .clipShape(RoundedRectangle(cornerRadius: 13))
                .submitLabel(.send)
                .onSubmit(send)

            Button(action: send) {
                Text("↑")
                    .font(.system(size: 18, weight: .black))
                    .foregroundStyle(.white)
                    .frame(width: 40, height: 42)
                    .background(ZKTheme.accentGradient)
                    .clipShape(RoundedRectangle(cornerRadius: 13))
            }
            .buttonStyle(.plain)
        }
    }

    private func send() {
        let text = input
        input = ""
        state.sendChat(text)
    }
}
