import SwiftUI

struct ChatView: View {
    @EnvironmentObject private var state: AppState
    @State private var input = ""

    var body: some View {
        NavigationStack {
            VStack(spacing: 10) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        MicroLabel(text: "LOCAL AGENT INTERFACE")
                        Text("ZK AI Chat")
                            .font(.system(size: 25, weight: .black, design: .rounded))
                    }
                    Spacer()
                    Text("NATIVE")
                        .font(.system(size: 10, weight: .black))
                        .foregroundStyle(ZKTheme.purple)
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)

                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(spacing: 8) {
                            ForEach(state.chatMessages) { message in
                                messageBubble(message)
                                    .id(message.id)
                            }
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 4)
                    }
                    .onChange(of: state.chatMessages.count) {
                        if let last = state.chatMessages.last {
                            withAnimation(.easeOut(duration: 0.2)) {
                                proxy.scrollTo(last.id, anchor: .bottom)
                            }
                        }
                    }
                }

                quickPrompts

                HStack(spacing: 8) {
                    TextField("Ask ZK AI…", text: $input)
                        .textInputAutocapitalization(.sentences)
                        .padding(.horizontal, 13)
                        .frame(height: 44)
                        .background(ZKTheme.panel)
                        .overlay(RoundedRectangle(cornerRadius: 14).stroke(ZKTheme.border))
                        .clipShape(RoundedRectangle(cornerRadius: 14))

                    Button {
                        send()
                    } label: {
                        Image(systemName: "arrow.up")
                            .font(.system(size: 16, weight: .black))
                            .frame(width: 44, height: 44)
                            .background(ZKTheme.accentGradient)
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                    }
                    .buttonStyle(.plain)
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 8)
            }
            .background(ZKTheme.background)
            .navigationBarHidden(true)
        }
    }

    private func messageBubble(_ message: ChatMessage) -> some View {
        HStack {
            if message.role == .user { Spacer(minLength: 38) }

            VStack(alignment: .leading, spacing: 4) {
                MicroLabel(text: message.role == .user ? "YOU" : "ZK AI")
                Text(message.text)
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(.white.opacity(0.93))
            }
            .padding(12)
            .background(message.role == .user ? ZKTheme.panel2 : ZKTheme.panel)
            .overlay(RoundedRectangle(cornerRadius: 16).stroke(message.role == .user ? ZKTheme.purple.opacity(0.45) : ZKTheme.border))
            .clipShape(RoundedRectangle(cornerRadius: 16))

            if message.role == .assistant { Spacer(minLength: 38) }
        }
    }

    private var quickPrompts: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 6) {
                quick("What do you see?")
                quick("Why are you waiting?")
                quick("Model status")
                quick("Macro status")
            }
            .padding(.horizontal, 16)
        }
    }

    private func quick(_ text: String) -> some View {
        Button {
            input = text
            send()
        } label: {
            Text(text)
                .font(.system(size: 11, weight: .bold))
                .padding(.horizontal, 11)
                .padding(.vertical, 8)
                .background(ZKTheme.panel)
                .overlay(Capsule().stroke(ZKTheme.border))
                .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }

    private func send() {
        let q = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return }
        input = ""

        state.chatMessages.append(.init(role: .user, text: q))
        state.chatMessages.append(.init(role: .assistant, text: answer(q)))
    }

    private func answer(_ query: String) -> String {
        let q = query.lowercased()

        if q.contains("model") {
            return "The native model vault is running as a foundation, but v0.1 intentionally has no live Core ML trading model yet. We are proving the IPA, storage and notification pipeline first."
        }
        if q.contains("macro") || q.contains("cot") || q.contains("dollar") || q.contains("yield") {
            return "Gold Intelligence is laid out for DXY, US yields, COT, silver and economic-event context. Those live connectors come after the native build installs successfully."
        }
        if q.contains("wait") {
            return "I am waiting because v0.1 has no broker market feed. This build will never pretend demo data is a real trade setup."
        }
        if q.contains("see") || q.contains("chart") {
            return "I can access the native app state and demo chart foundation. The next data build will give the agent structured candle and drawing tools instead of trying to read a protected TradingView iframe."
        }
        return "This is the native agent shell. Once the install pipeline is proven, I will be connected to the trading model, broker candles, Macro AI, Model Vault and chart tools."
    }
}
