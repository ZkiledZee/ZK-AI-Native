import SwiftUI
import Foundation

@MainActor
final class AppState: ObservableObject {
    @Published var selectedTab: Int = 0
    @Published var activeSignal: TradeSignal?
    @Published var notificationPermission: Bool = false
    @Published var selectedModelID: UUID?
    @Published var models: [ModelRecord] = ModelRecord.demoModels
    @Published var chatMessages: [ChatMessage] = [
        .init(role: .assistant, text: "ZK AI Native is running locally. This first build is for proving native performance, SideStore installation, notifications, storage and the UI pipeline.")
    ]

    @AppStorage("zk_native_install_id") private var storedInstallID: String = ""
    @AppStorage("zk_native_launch_count") private var storedLaunchCount: Int = 0

    let installID: String
    let launchCount: Int

    init() {
        if storedInstallID.isEmpty {
            storedInstallID = UUID().uuidString
        }
        storedLaunchCount += 1
        installID = storedInstallID
        launchCount = storedLaunchCount
        selectedModelID = models.first?.id
    }

    func activateDemoSignal() {
        activeSignal = .demo
    }

    func clearDemoSignal() {
        activeSignal = nil
    }
}

struct ChatMessage: Identifiable, Equatable {
    enum Role {
        case user
        case assistant
    }

    let id = UUID()
    let role: Role
    let text: String
}
