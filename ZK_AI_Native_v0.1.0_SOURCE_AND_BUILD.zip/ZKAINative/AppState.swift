import SwiftUI
import Foundation

@MainActor
final class AppState: ObservableObject {
    @Published var page: ZKPage = .home
    @Published var signal: SignalSnapshot = .disconnected
    @Published var models: [ModelRecord] = ModelRecord.seed
    @Published var selectedModelID: UUID?
    @Published var drawings: [ChartDrawing] = []
    @Published var journal: [TradeJournalEntry] = []
    @Published var macroCoverage: Double = 0
    @Published var macroRegime: String = "NO MACRO DATA"
    @Published var agentLoaded = false
    @Published var chartMode: Int = 0
    @Published var notificationPermission = false
    @Published var chatMessages: [ChatMessage] = [
        .init(
            role: .assistant,
            text: "I am the native ZK AI shell. I can explain app state and use the chart drawing tools. Live market decisions stay disabled until a verified broker feed and numerical model are connected."
        )
    ]

    let installID: String
    let launchCount: Int

    init() {
        let defaults = UserDefaults.standard
        let existing = defaults.string(forKey: "zk.installID")
        let id = existing ?? UUID().uuidString
        if existing == nil { defaults.set(id, forKey: "zk.installID") }

        let nextCount = defaults.integer(forKey: "zk.launchCount") + 1
        defaults.set(nextCount, forKey: "zk.launchCount")

        installID = id
        launchCount = nextCount
        selectedModelID = models.first?.id
        loadDrawings()
    }

    var selectedModel: ModelRecord? {
        models.first(where: { $0.id == selectedModelID })
    }

    func go(_ destination: ZKPage) {
        withAnimation(.easeOut(duration: 0.18)) {
            page = destination
        }
    }

    func replaceSupportResistance() {
        drawings.removeAll { $0.kind == .support || $0.kind == .resistance }
        drawings.append(.init(kind: .support, price: 4639.8, label: "SUPPORT • DEMO"))
        drawings.append(.init(kind: .resistance, price: 4651.4, label: "RESISTANCE • DEMO"))
        persistDrawings()
    }

    func addDemoZone() {
        drawings.removeAll { $0.kind == .zone }
        drawings.append(.init(kind: .zone, price: 4642.4, secondaryPrice: 4644.2, label: "AI ZONE • DEMO"))
        persistDrawings()
    }

    func removeLastDrawing() {
        guard !drawings.isEmpty else { return }
        drawings.removeLast()
        persistDrawings()
    }

    func clearAllDrawings() {
        drawings.removeAll()
        persistDrawings()
    }

    func removeSupport() {
        drawings.removeAll { $0.kind == .support }
        persistDrawings()
    }

    func removeResistance() {
        drawings.removeAll { $0.kind == .resistance }
        persistDrawings()
    }

    private func persistDrawings() {
        if let data = try? JSONEncoder().encode(drawings) {
            UserDefaults.standard.set(data, forKey: "zk.drawings")
        }
    }

    private func loadDrawings() {
        guard
            let data = UserDefaults.standard.data(forKey: "zk.drawings"),
            let decoded = try? JSONDecoder().decode([ChartDrawing].self, from: data)
        else { return }
        drawings = decoded
    }

    func sendChat(_ raw: String) {
        let q = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return }
        chatMessages.append(.init(role: .user, text: q))
        chatMessages.append(.init(role: .assistant, text: respond(to: q)))
    }

    private func respond(to query: String) -> String {
        let q = query.lowercased()

        if q.contains("support") || q.contains("resistance") {
            replaceSupportResistance()
            return "I replaced the previous support/resistance set with one demo support and one demo resistance level on the Agent Chart. Live smart zones will use broker candles once the feed is connected."
        }

        if q.contains("clear") && q.contains("drawing") {
            clearAllDrawings()
            return "All chart drawings are cleared."
        }

        if q.contains("macro") || q.contains("cot") || q.contains("yield") || q.contains("dxy") {
            return "Macro coverage is currently \(Int(macroCoverage * 100))%. Below the future coverage threshold, Macro AI remains informational and cannot materially change an execution decision."
        }

        if q.contains("model") || q.contains("performance") {
            let m = selectedModel
            return "The selected model is \(m?.name ?? "none"). Evidence status: \(m?.evidence ?? "unknown"). There are \(m?.resolvedTrades ?? 0) resolved unseen trades, so this build does not claim validation."
        }

        if q.contains("why") && q.contains("wait") {
            return "Execution is WAIT because no broker-quality XAUUSD feed or validated numerical model is connected. I will not turn placeholder or demo data into a live trade."
        }

        if q.contains("see") || q.contains("chart") {
            return "The native Agent Chart is available and I can manage its drawing state. The candle series in v0.2 is explicitly demo data; broker candles are the next data-layer build."
        }

        return "I can explain Market AI, Macro AI, the execution gate, Model Vault, macro coverage and chart drawings. Trading decisions remain disabled until verified live data and a trained numerical model are connected."
    }
}
