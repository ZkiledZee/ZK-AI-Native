import Foundation
import UserNotifications

@MainActor
final class NotificationManager: ObservableObject {
    static let shared = NotificationManager()

    @Published private(set) var statusText = "Not requested"

    private init() {}

    func refreshStatus() async -> Bool {
        let settings = await UNUserNotificationCenter.current().notificationSettings()
        switch settings.authorizationStatus {
        case .authorized, .provisional, .ephemeral:
            statusText = "Enabled"
            return true
        case .denied:
            statusText = "Denied"
            return false
        case .notDetermined:
            statusText = "Not requested"
            return false
        @unknown default:
            statusText = "Unknown"
            return false
        }
    }

    func requestPermission() async -> Bool {
        do {
            let granted = try await UNUserNotificationCenter.current()
                .requestAuthorization(options: [.alert, .sound, .badge])
            _ = await refreshStatus()
            return granted
        } catch {
            statusText = "Error"
            return false
        }
    }

    func sendSignalNotification(_ signal: TradeSignal) async {
        let content = UNMutableNotificationContent()
        content.title = signal.isDemo ? "ZK AI — DEMO SIGNAL" : "ZK AI — SIGNAL VALID"
        content.body = String(
            format: "%@ XAUUSD • Entry %.2f • SL %.2f • TP %.2f • %.1fR",
            signal.side.rawValue,
            signal.entry,
            signal.stopLoss,
            signal.takeProfit,
            signal.riskReward
        )
        content.sound = .default

        let request = UNNotificationRequest(
            identifier: "zk.signal.\(UUID().uuidString)",
            content: content,
            trigger: UNTimeIntervalNotificationTrigger(timeInterval: 1.0, repeats: false)
        )

        do {
            try await UNUserNotificationCenter.current().add(request)
        } catch {
            // The UI exposes permission state; no crash if the notification cannot be scheduled.
        }
    }
}
