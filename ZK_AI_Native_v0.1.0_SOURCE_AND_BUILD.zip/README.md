# ZK AI Native v0.2.0 — Web Parity

This build intentionally ports the visual language of the latest ZK XAUUSD web app into native SwiftUI rather than inventing a new UI.

## Web-parity targets
- dark #030306 / #07050a surfaces
- gold ZK logo and pulsing rings
- centered AI Scalper home hero
- same three home actions
- same 5-item bottom nav glyph style
- Live Model signal header
- Active Model strip
- Gold Regime / USD / Yields / COT strip
- AI Bias orb
- probability row
- large chart area
- compact Entry / SL / TP / R:R strip
- AI Lab / Model Vault / Gold Intelligence styling
- grounded ZK AI Chat styling

## Native additions in v0.2
- Directional Confidence, WAIT Probability and Execution Confidence are separate
- Smart chart drawing state:
  - replace support/resistance
  - draw zone
  - remove last
  - remove support
  - remove resistance
  - clear all
- Macro coverage gate
- planned COT metrics: net, weekly change, %OI, 13/52w percentile, z-score
- Model evidence status
- model train/unseen metadata
- Trade Journal / diagnostics foundation
- native notification test
- local persistence for drawing state
- same bundle ID as v0.1: com.zk.goldai.native

## Important
v0.2 still does not claim live trading intelligence. The chart is explicitly demo data and the signal stays WAIT until a verified broker feed and trained numerical model are connected.
