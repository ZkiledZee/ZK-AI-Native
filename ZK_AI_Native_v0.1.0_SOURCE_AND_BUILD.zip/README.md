# ZK AI Native v0.1.0

This is the first **real native iOS SwiftUI build** for the ZK XAUUSD project.

## What v0.1 proves
- Native SwiftUI UI, not a web wrapper
- Home / Signal / Chart / AI Lab / Chat tabs
- Local persistence with `@AppStorage`
- Model Vault foundation
- Gold Intelligence / Macro AI foundation
- Native candlestick chart surface
- Native notification permission
- Demo signal notification
- SideStore-ready unsigned IPA build workflow

## Deliberately NOT live yet
This first build has **no live XAUUSD feed and no real trading signal model**. Demo candles and the demo signal are visibly labelled. The purpose is to verify that the IPA builds, installs, launches, stores data and sends native notifications before adding broker data and AI models.

## Building the IPA without a Mac
The included GitHub Actions workflow:
`.github/workflows/build-ipa.yml`

uses a GitHub macOS runner to:
1. install XcodeGen,
2. create the Xcode project,
3. compile an unsigned iPhone app,
4. package it as `ZK-AI-Native-v0.1.0-unsigned.ipa`,
5. upload the IPA as a workflow artifact.

SideStore handles signing when you install the IPA with your Apple account.

## Planned next layers
1. IC Markets / cTrader market-data engine
2. True XAUUSD candle + spread database
3. Market AI: BUY / WAIT / SELL + MFE/MAE + time-to-resolution
4. Macro AI: DXY, yields, COT, silver, event risk
5. Execution gate: EV + structure + spread + 2R+ filter
6. Locked trade lifecycle until TP/SL
7. Model Vault challengers + rollback
8. Trade journal + diagnostics
9. Similar-historical-state search
10. Local native conversational agent + chart tools
11. Push notification backend for 24/7 signals
