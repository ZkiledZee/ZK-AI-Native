import SwiftUI

struct SignalView: View {
    @EnvironmentObject private var state: AppState
    @EnvironmentObject private var market: MarketDataService
    @EnvironmentObject private var engine: SignalEngine
    @Environment(\.zkScale) private var scale
    @StateObject private var notifications = NotificationManager.shared

    var body: some View {
        VStack(spacing: 10 * scale) {
            ZKPageHeader(
                micro: "XAUUSD • 1M SIGNAL ENGINE",
                title: "Signal",
                pill: engine.enabled ? engine.mode.rawValue : "PAUSED",
                pillColor: engine.enabled ? modeColor : ZKTheme.textMuted
            )

            marketAndModeBar
            chart
            compactSignalCard

            if engine.activeTrade != nil {
                tradeLevels
            }

            footerBar
        }
        .padding(.horizontal, 16 * scale)
        .padding(.top, 8 * scale)
        .padding(.bottom, 8 * scale)
        .background(ZKTheme.background)
        .task { state.notificationPermission = await notifications.refresh() }
    }

    // MARK: - Top controls

    private var marketAndModeBar: some View {
        VStack(spacing: 9 * scale) {
            HStack(alignment: .center, spacing: 10 * scale) {
                VStack(alignment: .leading, spacing: 2 * scale) {
                    HStack(spacing: 5 * scale) {
                        Circle()
                            .fill(feedColor)
                            .frame(width: 6 * scale, height: 6 * scale)
                        Text("XAUUSD")
                            .font(.system(size: 8 * scale, weight: .black))
                            .foregroundStyle(ZKTheme.textMuted)
                    }
                    Text(market.currentPrice.map { String(format: "$%.2f", $0) } ?? "—")
                        .font(.system(size: 18 * scale, weight: .black, design: .monospaced))
                        .contentTransition(.numericText())
                }

                Spacer(minLength: 8)

                VStack(alignment: .trailing, spacing: 2 * scale) {
                    Text(market.feedStatus.rawValue)
                        .font(.system(size: 8 * scale, weight: .black))
                        .foregroundStyle(feedColor)
                    Text(market.freshnessText)
                        .font(.system(size: 7 * scale, weight: .semibold))
                        .foregroundStyle(ZKTheme.textMuted)
                }

                Toggle("", isOn: Binding(get: { engine.enabled }, set: { engine.setEnabled($0) }))
                    .labelsHidden()
                    .tint(ZKTheme.green)
                    .scaleEffect(0.86)
            }

            Picker("Signal mode", selection: Binding(
                get: { engine.mode },
                set: { engine.setMode($0) }
            )) {
                Text("SELECTIVE").tag(SignalEngineMode.selective)
                Text("FAST SCALPER").tag(SignalEngineMode.fastScalper)
            }
            .pickerStyle(.segmented)
            .disabled(!engine.enabled)
        }
        .padding(.horizontal, 12 * scale)
        .padding(.vertical, 10 * scale)
        .background(Color(red: 0.035, green: 0.027, blue: 0.051))
        .overlay(RoundedRectangle(cornerRadius: 14 * scale, style: .continuous).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 14 * scale, style: .continuous))
    }

    // MARK: - Main chart

    private var chart: some View {
        VStack(spacing: 0) {
            HStack(spacing: 8 * scale) {
                VStack(alignment: .leading, spacing: 1 * scale) {
                    Text("XAUUSD · 1M")
                        .font(.system(size: 10 * scale, weight: .black))
                    Text("Custom chart · same candles used by the signal engine")
                        .font(.system(size: 7 * scale, weight: .medium))
                        .foregroundStyle(ZKTheme.textMuted)
                }

                Spacer()

                Button {
                    engine.forceEvaluate()
                } label: {
                    Image(systemName: "arrow.clockwise")
                        .font(.system(size: 11 * scale, weight: .bold))
                        .foregroundStyle(ZKTheme.textSoft)
                        .frame(width: 31 * scale, height: 31 * scale)
                        .background(ZKTheme.card2)
                        .overlay(Circle().stroke(ZKTheme.border))
                        .clipShape(Circle())
                }
                .buttonStyle(ZKPressStyle())
                .accessibilityLabel("Scan now")
            }
            .padding(.horizontal, 11 * scale)
            .padding(.vertical, 9 * scale)

            Divider().overlay(ZKTheme.border.opacity(0.55))

            Group {
                if market.candles.isEmpty {
                    VStack(spacing: 8 * scale) {
                        ProgressView().tint(ZKTheme.purple)
                        Text(market.feedStatus == .offline ? "Chart unavailable" : "Loading 1M candles…")
                            .font(.system(size: 9 * scale, weight: .bold))
                            .foregroundStyle(ZKTheme.textMuted)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    NativeAgentChart(candles: market.candles, drawings: signalDrawings)
                        .padding(.horizontal, 4 * scale)
                        .padding(.vertical, 5 * scale)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .frame(minHeight: 300 * scale, maxHeight: .infinity)
        .background(Color(red: 0.025, green: 0.021, blue: 0.036))
        .overlay(RoundedRectangle(cornerRadius: 16 * scale, style: .continuous).stroke(ZKTheme.borderStrong.opacity(0.85)))
        .clipShape(RoundedRectangle(cornerRadius: 16 * scale, style: .continuous))
    }

    /// Keep the Signal chart deliberately clean. AI/support-resistance drawings belong on the full Chart tab.
    /// The Signal chart only overlays an active paper setup (entry, SL and TP).
    private var signalDrawings: [ChartDrawing] {
        guard let trade = engine.activeTrade else { return [] }
        return [
            .init(kind: .entry, price: trade.entry, label: "ENTRY"),
            .init(kind: .stopLoss, price: trade.stopLoss, label: "SL"),
            .init(kind: .takeProfit, price: trade.takeProfit, label: "TP")
        ]
    }

    // MARK: - Compact status

    private var compactSignalCard: some View {
        let s = engine.snapshot
        return HStack(alignment: .center, spacing: 12 * scale) {
            VStack(alignment: .leading, spacing: 3 * scale) {
                HStack(spacing: 7 * scale) {
                    Circle()
                        .fill(signalColor)
                        .frame(width: 8 * scale, height: 8 * scale)
                        .shadow(color: signalColor.opacity(0.55), radius: 4)
                    Text(s.side.rawValue)
                        .font(.system(size: 20 * scale, weight: .black, design: .rounded))
                        .foregroundStyle(signalColor)
                    Text("\(Int((s.executionConfidence * 100).rounded()))%")
                        .font(.system(size: 10 * scale, weight: .black, design: .monospaced))
                        .foregroundStyle(ZKTheme.textSoft)
                }

                Text(cleanReason(s.reason))
                    .font(.system(size: 8.3 * scale, weight: .medium))
                    .foregroundStyle(ZKTheme.textMuted)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
            }

            Spacer(minLength: 8)

            VStack(alignment: .trailing, spacing: 3 * scale) {
                Text("SCORE \(Int(engine.lastScore))")
                    .font(.system(size: 8 * scale, weight: .black, design: .monospaced))
                    .foregroundStyle(ZKTheme.textSoft)
                Text("\(engine.todayTradeCount) TODAY")
                    .font(.system(size: 7.5 * scale, weight: .black, design: .monospaced))
                    .foregroundStyle(modeColor)
                Text(engine.activeTrade == nil ? "SCANNING" : "PAPER OPEN")
                    .font(.system(size: 7 * scale, weight: .black))
                    .foregroundStyle(engine.activeTrade == nil ? ZKTheme.textMuted : ZKTheme.green)
            }
        }
        .padding(.horizontal, 12 * scale)
        .padding(.vertical, 10 * scale)
        .background(Color(red: 0.035, green: 0.027, blue: 0.051))
        .overlay(RoundedRectangle(cornerRadius: 14 * scale, style: .continuous).stroke(signalColor.opacity(0.22)))
        .clipShape(RoundedRectangle(cornerRadius: 14 * scale, style: .continuous))
    }

    private func cleanReason(_ reason: String) -> String {
        let first = reason
            .replacingOccurrences(of: "Selective scan: ", with: "")
            .replacingOccurrences(of: "Fast scalper scan: ", with: "")
        return first.isEmpty ? "Waiting for a qualified setup." : first
    }

    // MARK: - Open trade only

    private var tradeLevels: some View {
        let s = engine.snapshot
        return HStack(spacing: 6 * scale) {
            levelCell("ENTRY", priceText(s.entry), signalColor)
            levelCell("SL", priceText(s.stopLoss), ZKTheme.red)
            levelCell("TP", priceText(s.takeProfit), ZKTheme.green)
            levelCell("R:R", s.riskReward.map { String(format: "%.2f", $0) } ?? "—", ZKTheme.purple)
        }
    }

    private func levelCell(_ title: String, _ value: String, _ color: Color) -> some View {
        VStack(spacing: 2 * scale) {
            Text(title)
                .font(.system(size: 6.5 * scale, weight: .black))
                .foregroundStyle(ZKTheme.textMuted)
            Text(value)
                .font(.system(size: 8.3 * scale, weight: .black, design: .monospaced))
                .foregroundStyle(color)
                .lineLimit(1)
                .minimumScaleFactor(0.65)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 7 * scale)
        .background(Color(red: 0.035, green: 0.027, blue: 0.051))
        .overlay(RoundedRectangle(cornerRadius: 10 * scale).stroke(ZKTheme.border.opacity(0.85)))
        .clipShape(RoundedRectangle(cornerRadius: 10 * scale))
    }

    private var footerBar: some View {
        HStack(spacing: 7 * scale) {
            Circle()
                .fill(engine.enabled ? modeColor : ZKTheme.textMuted)
                .frame(width: 6 * scale, height: 6 * scale)
            Text(engine.enabled ? "ENGINE ON · PAPER" : "ENGINE PAUSED")
                .font(.system(size: 7 * scale, weight: .black))
                .foregroundStyle(ZKTheme.textMuted)
            Spacer()
            Button {
                Task {
                    if !state.notificationPermission { state.notificationPermission = await notifications.request() }
                    if state.notificationPermission { await notifications.sendDemo() }
                }
            } label: {
                Image(systemName: state.notificationPermission ? "bell.fill" : "bell")
                    .font(.system(size: 10 * scale, weight: .bold))
                    .foregroundStyle(state.notificationPermission ? ZKTheme.purple : ZKTheme.textMuted)
            }
            .buttonStyle(ZKPressStyle())
            .accessibilityLabel(state.notificationPermission ? "Alerts enabled" : "Enable alerts")
        }
        .padding(.horizontal, 4 * scale)
        .frame(height: 20 * scale)
    }

    private func priceText(_ value: Double?) -> String {
        value.map { String(format: "%.2f", $0) } ?? "—"
    }

    private var signalColor: Color {
        switch engine.snapshot.side {
        case .buy: return ZKTheme.green
        case .sell: return ZKTheme.red
        case .wait: return ZKTheme.gold
        }
    }

    private var modeColor: Color {
        engine.mode == .fastScalper ? ZKTheme.pink : ZKTheme.purple
    }

    private var feedColor: Color {
        switch market.feedStatus {
        case .live: return ZKTheme.green
        case .stale, .connecting: return ZKTheme.gold
        case .offline: return ZKTheme.red
        }
    }
}
