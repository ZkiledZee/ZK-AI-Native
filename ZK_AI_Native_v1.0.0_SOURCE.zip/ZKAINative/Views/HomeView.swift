import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var state: AppState
    @EnvironmentObject private var ai: LocalAIService
    @EnvironmentObject private var signalEngine: SignalEngine
    @EnvironmentObject private var cTrader: CTraderConnectionService
    @Environment(\.zkScale) private var scale
    @State private var drift = false
    @State private var orbit = false

    var body: some View {
        ZStack {
            ZKTheme.background.ignoresSafeArea()
            ambient

            ScrollView {
                VStack(spacing: 18 * scale) {
                    hero
                    marketPicker
                    actions
                    statusLine
                }
                .padding(.horizontal, 18 * scale)
                .padding(.top, 24 * scale)
                .padding(.bottom, 24 * scale)
            }
            .scrollIndicators(.hidden)
        }
    }

    private var hero: some View {
        VStack(spacing: 11 * scale) {
            ZStack {
                Circle()
                    .stroke(ZKTheme.purple.opacity(0.16), lineWidth: 1)
                    .frame(width: 146 * scale, height: 146 * scale)
                    .rotationEffect(.degrees(orbit ? 360 : 0))

                Circle()
                    .trim(from: 0.08, to: 0.30)
                    .stroke(
                        AngularGradient(colors: [ZKTheme.gold.opacity(0.05), ZKTheme.gold, ZKTheme.pink.opacity(0.30)], center: .center),
                        style: StrokeStyle(lineWidth: 2.0 * scale, lineCap: .round)
                    )
                    .frame(width: 138 * scale, height: 138 * scale)
                    .rotationEffect(.degrees(orbit ? 360 : 0))
                    .shadow(color: ZKTheme.gold.opacity(0.20), radius: 8)

                HomeLogo()
                    .scaleEffect(1.30)
            }
            .frame(height: 154 * scale)
            .onAppear {
                withAnimation(.linear(duration: 12).repeatForever(autoreverses: false)) { orbit = true }
            }

            Text("ZK AI")
                .font(.system(size: 34 * scale, weight: .black, design: .rounded))
                .tracking(-1.2 * scale)

            Text("TRADE  •  SIGNAL  •  AGENT")
                .font(.system(size: 8.5 * scale, weight: .black, design: .rounded))
                .tracking(1.5 * scale)
                .foregroundStyle(ZKTheme.textMuted)
        }
        .frame(maxWidth: .infinity)
    }

    private var marketPicker: some View {
        VStack(alignment: .leading, spacing: 8 * scale) {
            HStack {
                Text("MARKETS")
                    .font(.system(size: 8 * scale, weight: .black, design: .rounded))
                    .tracking(1.0 * scale)
                    .foregroundStyle(ZKTheme.textMuted)
                Spacer()
                Text(state.selectedMarket.availability)
                    .font(.system(size: 7.5 * scale, weight: .black, design: .rounded))
                    .foregroundStyle(state.selectedMarket.weekendFriendly ? ZKTheme.green : ZKTheme.textSoft)
            }

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 7 * scale) {
                    ForEach(TradeMarket.watchlist) { market in
                        marketChip(market)
                    }
                }
            }
        }
    }

    private func marketChip(_ market: TradeMarket) -> some View {
        let selected = state.selectedMarketSymbol == market.symbol
        return Button {
            state.selectMarket(market)
        } label: {
            VStack(alignment: .leading, spacing: 2 * scale) {
                Text(market.symbol)
                    .font(.system(size: 9 * scale, weight: .black, design: .rounded))
                Text(market.weekendFriendly ? "7D" : "WK")
                    .font(.system(size: 6.5 * scale, weight: .black, design: .rounded))
                    .foregroundStyle(selected ? .white.opacity(0.72) : ZKTheme.textMuted)
            }
            .foregroundStyle(selected ? .white : ZKTheme.textSoft)
            .frame(width: 70 * scale, height: 42 * scale, alignment: .leading)
            .padding(.horizontal, 10 * scale)
            .background(selected ? ZKTheme.purple.opacity(0.24) : ZKTheme.card.opacity(0.78))
            .overlay(RoundedRectangle(cornerRadius: 13 * scale).stroke(selected ? ZKTheme.borderStrong : ZKTheme.border.opacity(0.7)))
            .clipShape(RoundedRectangle(cornerRadius: 13 * scale))
        }
        .buttonStyle(ZKPressStyle())
    }

    private var actions: some View {
        HStack(spacing: 10 * scale) {
            homeButton(icon: "diamond.fill", title: "Signal", accent: ZKTheme.gold) { state.go(.signal) }
            homeButton(icon: "chart.xyaxis.line", title: "cTrader", accent: ZKTheme.green) { state.go(.chart) }
            homeButton(icon: "bubble.left.and.bubble.right.fill", title: "Agent", accent: ZKTheme.purple) { state.go(.chat) }
        }
    }

    private func homeButton(icon: String, title: String, accent: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 9 * scale) {
                Image(systemName: icon)
                    .font(.system(size: 20 * scale, weight: .bold))
                    .foregroundStyle(accent)
                    .frame(width: 44 * scale, height: 44 * scale)
                    .background(accent.opacity(0.08))
                    .clipShape(Circle())
                Text(title)
                    .font(.system(size: 11 * scale, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 92 * scale)
            .background(
                LinearGradient(
                    colors: [ZKTheme.card2.opacity(0.92), ZKTheme.card.opacity(0.84)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .overlay(RoundedRectangle(cornerRadius: 19 * scale).stroke(ZKTheme.border.opacity(0.85)))
            .clipShape(RoundedRectangle(cornerRadius: 19 * scale))
        }
        .buttonStyle(ZKPressStyle())
    }

    private var statusLine: some View {
        HStack(spacing: 7 * scale) {
            Circle()
                .fill(ZKTheme.gold)
                .frame(width: 6 * scale, height: 6 * scale)
            Text(cTrader.isConnected ? "CTRADER \(cTrader.environmentLabel)" : "CTRADER OFF")
            Text("•")
            Text(signalEngine.enabled ? signalEngine.mode.rawValue : "SIGNALS PAUSED")
            Text("•")
            Text(ai.isReady ? "AGENT READY" : "AGENT OFF")
        }
        .font(.system(size: 7.2 * scale, weight: .black, design: .rounded))
        .foregroundStyle(ZKTheme.textMuted)
        .lineLimit(1)
        .minimumScaleFactor(0.78)
        .frame(maxWidth: .infinity)
        .padding(.top, 2 * scale)
    }

    private var ambient: some View {
        ZStack {
            Circle()
                .fill(ZKTheme.purple.opacity(0.10))
                .frame(width: 300 * scale, height: 300 * scale)
                .blur(radius: 48)
                .offset(x: drift ? -130 : -180, y: drift ? -250 : -310)

            Circle()
                .fill(ZKTheme.gold.opacity(0.045))
                .frame(width: 260 * scale, height: 260 * scale)
                .blur(radius: 48)
                .offset(x: drift ? 150 : 210, y: drift ? 270 : 330)
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 11).repeatForever(autoreverses: true)) { drift = true }
        }
    }
}
