import Foundation
import SwiftUI

struct ChartView: View {
    @EnvironmentObject private var state: AppState
    @EnvironmentObject private var cTrader: CTraderConnectionService
    @Environment(\.zkScale) private var scale

    @State private var clientID = ""
    @State private var clientSecret = ""
    @State private var accessToken = ""
    @State private var refreshToken = ""
    @State private var environment: CTraderConnectionService.Environment = .demo
    @State private var showCredentials = false
    @State private var showForgetConfirmation = false

    var body: some View {
        ZStack {
            ZKTheme.background.ignoresSafeArea()
            if cTrader.isConnected { connectedView } else { loginGate }
        }
        .confirmationDialog("Remove saved cTrader credentials?", isPresented: $showForgetConfirmation) {
            Button("Remove credentials", role: .destructive) { cTrader.disconnect(forgetCredentials: true) }
            Button("Cancel", role: .cancel) {}
        }
    }

    private var loginGate: some View {
        ScrollView {
            VStack(spacing: 15 * scale) {
                ZKPageHeader(micro: "SECURE OPEN API", title: "Connect cTrader", pill: environment.rawValue, pillColor: ZKTheme.gold)

                connectionHero

                if cTrader.hasSavedCredentials && !showCredentials {
                    savedCredentialsCard
                } else {
                    credentialsCard
                }

                if !cTrader.errorMessage.isEmpty { errorCard }

                Text("Credentials are stored only in this iPhone's Keychain. They are never added to the app source, GitHub or chat.")
                    .font(.system(size: 7.5 * scale, weight: .medium))
                    .foregroundStyle(ZKTheme.textMuted)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 18 * scale)
            }
            .padding(.horizontal, 14 * scale)
            .padding(.top, 10 * scale)
            .padding(.bottom, 18 * scale)
        }
        .scrollIndicators(.hidden)
    }

    private var connectionHero: some View {
        ZKCard(strongBorder: true) {
            HStack(spacing: 13 * scale) {
                ZStack {
                    Circle().fill(statusColor.opacity(0.10)).frame(width: 54 * scale, height: 54 * scale)
                    Image(systemName: cTrader.phase == .failed ? "exclamationmark.triangle.fill" : "link.circle.fill")
                        .font(.system(size: 28 * scale, weight: .semibold))
                        .foregroundStyle(statusColor)
                }
                VStack(alignment: .leading, spacing: 4 * scale) {
                    Text(statusTitle)
                        .font(.system(size: 12 * scale, weight: .black, design: .rounded))
                    Text("Raw Trading Ltd is IC Markets Global")
                        .font(.system(size: 8 * scale, weight: .medium))
                        .foregroundStyle(ZKTheme.textMuted)
                }
                Spacer()
                if cTrader.phase == .connecting || cTrader.phase == .authorizing {
                    ProgressView().tint(ZKTheme.purple)
                }
            }
        }
    }

    private var savedCredentialsCard: some View {
        ZKCard {
            VStack(spacing: 11 * scale) {
                HStack {
                    Label("Credentials saved securely", systemImage: "key.fill")
                        .font(.system(size: 9 * scale, weight: .black))
                        .foregroundStyle(ZKTheme.green)
                    Spacer()
                }

                Picker("Environment", selection: $environment) {
                    ForEach(CTraderConnectionService.Environment.allCases) { item in Text(item.rawValue).tag(item) }
                }
                .pickerStyle(.segmented)
                .onChange(of: environment) { _, _ in showCredentials = true }

                Button { cTrader.connectStored() } label: {
                    Text("CONNECT SAVED ACCOUNT")
                        .font(.system(size: 9.5 * scale, weight: .black))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity, minHeight: 43 * scale)
                        .background(ZKTheme.purple)
                        .clipShape(RoundedRectangle(cornerRadius: 13 * scale))
                }
                .buttonStyle(ZKPressStyle())
                .disabled(cTrader.phase == .connecting || cTrader.phase == .authorizing)

                HStack {
                    Button("REPLACE") { showCredentials = true }
                    Spacer()
                    Button("FORGET", role: .destructive) { showForgetConfirmation = true }
                }
                .font(.system(size: 7.5 * scale, weight: .black))
                .buttonStyle(.plain)
            }
        }
    }

    private var credentialsCard: some View {
        ZKCard {
            VStack(spacing: 10 * scale) {
                HStack {
                    Text("CTRADER API CREDENTIALS")
                        .font(.system(size: 8 * scale, weight: .black))
                        .foregroundStyle(ZKTheme.textMuted)
                    Spacer()
                    Button("OPEN PORTAL") { cTrader.openOpenAPIPortal() }
                        .font(.system(size: 7 * scale, weight: .black))
                        .buttonStyle(.plain)
                        .foregroundStyle(ZKTheme.purple)
                }

                Picker("Environment", selection: $environment) {
                    ForEach(CTraderConnectionService.Environment.allCases) { item in Text(item.rawValue).tag(item) }
                }
                .pickerStyle(.segmented)

                secretField("Client ID", text: $clientID)
                secretField("Client secret", text: $clientSecret)
                secretField("Access token", text: $accessToken)
                secretField("Refresh token (recommended)", text: $refreshToken)

                Button {
                    cTrader.connect(
                        clientID: clientID,
                        clientSecret: clientSecret,
                        accessToken: accessToken,
                        refreshToken: refreshToken,
                        environment: environment
                    )
                    clientID = ""; clientSecret = ""; accessToken = ""; refreshToken = ""
                } label: {
                    HStack(spacing: 7 * scale) {
                        if cTrader.phase == .connecting || cTrader.phase == .authorizing { ProgressView().tint(.white) }
                        Text("SAVE & CONNECT")
                    }
                    .font(.system(size: 9.5 * scale, weight: .black))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity, minHeight: 44 * scale)
                    .background(ZKTheme.purple)
                    .clipShape(RoundedRectangle(cornerRadius: 13 * scale))
                }
                .buttonStyle(ZKPressStyle())
                .disabled(clientID.isEmpty || clientSecret.isEmpty || accessToken.isEmpty || cTrader.phase == .connecting || cTrader.phase == .authorizing)
            }
        }
    }

    private func secretField(_ title: String, text: Binding<String>) -> some View {
        SecureField(title, text: text)
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled()
            .font(.system(size: 9 * scale, weight: .semibold, design: .monospaced))
            .padding(.horizontal, 11 * scale)
            .frame(height: 40 * scale)
            .background(ZKTheme.card2)
            .overlay(RoundedRectangle(cornerRadius: 11 * scale).stroke(ZKTheme.border))
            .clipShape(RoundedRectangle(cornerRadius: 11 * scale))
    }

    private var errorCard: some View {
        HStack(alignment: .top, spacing: 8 * scale) {
            Image(systemName: "exclamationmark.triangle.fill").foregroundStyle(ZKTheme.red)
            Text(cTrader.errorMessage)
                .font(.system(size: 8 * scale, weight: .semibold))
                .foregroundStyle(ZKTheme.textSoft)
            Spacer()
        }
        .padding(12 * scale)
        .background(ZKTheme.red.opacity(0.08))
        .overlay(RoundedRectangle(cornerRadius: 12 * scale).stroke(ZKTheme.red.opacity(0.22)))
        .clipShape(RoundedRectangle(cornerRadius: 12 * scale))
    }

    private var connectedView: some View {
        ScrollView {
            VStack(spacing: 10 * scale) {
                ZKPageHeader(
                    micro: "CTRADER • \(state.selectedMarket.symbol)",
                    title: "Account",
                    pill: cTrader.environmentLabel,
                    pillColor: cTrader.environmentLabel == "DEMO" ? ZKTheme.green : ZKTheme.red
                )

                accountCard
                executionCard
                positionsCard

                HStack(spacing: 10 * scale) {
                    Button("REFRESH") { cTrader.refreshAccount() }
                        .frame(maxWidth: .infinity)
                    Button("DISCONNECT", role: .destructive) { cTrader.disconnect() }
                        .frame(maxWidth: .infinity)
                }
                .font(.system(size: 8 * scale, weight: .black))
                .buttonStyle(.bordered)
                .tint(ZKTheme.purple)
            }
            .padding(.horizontal, 14 * scale)
            .padding(.top, 10 * scale)
            .padding(.bottom, 18 * scale)
        }
        .scrollIndicators(.hidden)
    }

    private var accountCard: some View {
        ZKCard(strongBorder: true) {
            VStack(spacing: 12 * scale) {
                HStack {
                    VStack(alignment: .leading, spacing: 3 * scale) {
                        Text(cTrader.accountLabel.isEmpty ? "CTRADER ACCOUNT" : cTrader.accountLabel)
                            .font(.system(size: 10 * scale, weight: .black, design: .rounded))
                            .lineLimit(1)
                            .minimumScaleFactor(0.72)
                        Text(cTrader.permissionCanTrade ? "TRADING PERMISSION" : "VIEW-ONLY PERMISSION")
                            .font(.system(size: 7 * scale, weight: .black))
                            .foregroundStyle(cTrader.permissionCanTrade ? ZKTheme.green : ZKTheme.gold)
                    }
                    Spacer()
                    Circle().fill(ZKTheme.green).frame(width: 8 * scale, height: 8 * scale)
                }

                HStack(spacing: 8 * scale) {
                    metric("BALANCE", money(cTrader.balance))
                    metric("EQUITY", money(cTrader.equity ?? cTrader.balance))
                    metric("LEVERAGE", cTrader.leverage.map { "1:\($0)" } ?? "—")
                }
            }
        }
    }

    private func metric(_ title: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 3 * scale) {
            Text(title).font(.system(size: 6.5 * scale, weight: .black)).foregroundStyle(ZKTheme.textMuted)
            Text(value)
                .font(.system(size: 12 * scale, weight: .black, design: .monospaced))
                .foregroundStyle(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.65)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(9 * scale)
        .background(ZKTheme.card2)
        .clipShape(RoundedRectangle(cornerRadius: 11 * scale))
    }

    private var executionCard: some View {
        ZKCard {
            VStack(spacing: 10 * scale) {
                HStack {
                    VStack(alignment: .leading, spacing: 3 * scale) {
                        Text("AI DEMO EXECUTION")
                            .font(.system(size: 8 * scale, weight: .black))
                        Text(cTrader.lastTradeStatus)
                            .font(.system(size: 7.5 * scale, weight: .medium))
                            .foregroundStyle(ZKTheme.textMuted)
                    }
                    Spacer()
                    Toggle("", isOn: Binding(get: { cTrader.aiExecutionEnabled }, set: { cTrader.setAIExecution($0) }))
                        .labelsHidden()
                        .tint(ZKTheme.green)
                        .disabled(!cTrader.canEnableAIExecution)
                }

                HStack {
                    Text("ORDER SIZE")
                        .font(.system(size: 7 * scale, weight: .black))
                        .foregroundStyle(ZKTheme.textMuted)
                    Spacer()
                    Stepper(value: $cTrader.lotSize, in: 0.01...1.0, step: 0.01) {
                        Text("\(String(format: "%.2f", cTrader.lotSize)) lot")
                            .font(.system(size: 9 * scale, weight: .black, design: .monospaced))
                    }
                    .fixedSize()
                }

                Text(cTrader.environmentLabel == "DEMO"
                     ? "When enabled, each new ZK signal is sent once as a protected demo market order."
                     : "Automatic live trading is locked until demo execution is verified.")
                    .font(.system(size: 7.3 * scale, weight: .medium))
                    .foregroundStyle(cTrader.environmentLabel == "DEMO" ? ZKTheme.textMuted : ZKTheme.red)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }

    private var positionsCard: some View {
        ZKCard {
            VStack(spacing: 9 * scale) {
                HStack {
                    Text("OPEN POSITIONS")
                        .font(.system(size: 8 * scale, weight: .black))
                        .foregroundStyle(ZKTheme.textMuted)
                    Spacer()
                    Text("\(cTrader.positions.count) OPEN • \(cTrader.pendingOrderCount) PENDING")
                        .font(.system(size: 7 * scale, weight: .black))
                        .foregroundStyle(ZKTheme.textSoft)
                }

                if cTrader.positions.isEmpty {
                    Text("No open positions")
                        .font(.system(size: 9 * scale, weight: .semibold))
                        .foregroundStyle(ZKTheme.textMuted)
                        .frame(maxWidth: .infinity, minHeight: 54 * scale)
                } else {
                    ForEach(cTrader.positions.prefix(8)) { position in
                        HStack {
                            VStack(alignment: .leading, spacing: 2 * scale) {
                                Text("\(position.side) • \(position.symbol)")
                                    .font(.system(size: 9 * scale, weight: .black, design: .rounded))
                                    .foregroundStyle(position.side == "BUY" ? ZKTheme.green : ZKTheme.red)
                                Text("\(String(format: "%.2f", position.volume)) units • @ \(String(format: "%.5f", position.entryPrice))")
                                    .font(.system(size: 7 * scale, weight: .medium, design: .monospaced))
                                    .foregroundStyle(ZKTheme.textMuted)
                            }
                            Spacer()
                            Text(position.netProfit.map { String(format: "%+.2f %@", $0, cTrader.currency) } ?? "—")
                                .font(.system(size: 9 * scale, weight: .black, design: .monospaced))
                                .foregroundStyle((position.netProfit ?? 0) >= 0 ? ZKTheme.green : ZKTheme.red)
                        }
                        .padding(9 * scale)
                        .background(ZKTheme.card2)
                        .clipShape(RoundedRectangle(cornerRadius: 10 * scale))
                    }
                }
            }
        }
    }

    private func money(_ value: Double?) -> String {
        guard let value else { return "—" }
        return String(format: "%.2f %@", value, cTrader.currency)
    }

    private var statusTitle: String {
        switch cTrader.phase {
        case .disconnected: return "Enter your cTrader API credentials"
        case .readyToConnect: return "Ready to connect"
        case .connecting: return "Opening secure cTrader connection"
        case .authorizing: return "Authorising your IC Markets account"
        case .connected: return "Connected"
        case .failed: return "Connection needs attention"
        }
    }

    private var statusColor: Color {
        switch cTrader.phase {
        case .failed: return ZKTheme.red
        case .connecting, .authorizing: return ZKTheme.gold
        case .connected, .readyToConnect: return ZKTheme.green
        case .disconnected: return ZKTheme.purple
        }
    }
}
