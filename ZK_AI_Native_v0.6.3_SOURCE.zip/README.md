# ZK AI Native v0.6.3 — Local inference memory fix

This build fixes the second local-chat crash seen on 4 GB-class iPhones: the app reached `THINKING`, began local prefill, then iOS terminated the process a few seconds later.

## Root cause addressed
v0.6.1 avoided the earlier 256-token batch overflow by making `n_batch` 4096. That prevented one native bounds problem, but it created the opposite problem: llama.cpp had to allocate/prepare a very large inference batch and compute buffers while a ~491 MB model plus app/UI/chart/WebKit state were resident. On a 4 GB iPhone this can produce a transient memory spike large enough for iOS to terminate the app.

## v0.6.3 fix
- vendors a small patched SwiftLlama wrapper in `Packages/SwiftLlama`
- prompt prefill is decoded in bounded 192-token chunks instead of one giant batch
- context window reduced to 2048 for the 0.5B assistant
- `n_batch` reduced to 192
- CPU compatibility mode remains enabled for the first stable release
- reply budget reduced to 192 tokens
- prompt character budget reduced to 4500 and recent conversation to three turns
- runtime checks tokenized prompt length before entering llama.cpp; an oversized prompt becomes a visible Swift error instead of a native crash
- existing downloaded Qwen model path and checksum are unchanged, so SideStore update should preserve the model file

The chatbot remains an analysis/explanation layer. It does not replace the future trained BUY/WAIT/SELL market model.


## v0.6.3 build fix
- Restores the SwiftLlama module re-export (`@_exported @preconcurrency import llama`) required for the vendored llama.cpp C symbols to compile.
- Keeps the v0.6.2 chunked 192-token prefill / 2048 context crash mitigation unchanged.
