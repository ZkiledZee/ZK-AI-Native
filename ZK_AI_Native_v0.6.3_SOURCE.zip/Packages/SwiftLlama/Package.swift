// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "swift-llama",
    platforms: [
        .macOS(.v14),
        .iOS(.v17),
        .visionOS(.v1),
    ],
    products: [
        .library(name: "SwiftLlama", targets: ["SwiftLlama"])
    ],
    targets: [
        .binaryTarget(
            name: "llama-cpp",
            url: "https://github.com/ggml-org/llama.cpp/releases/download/b8668/llama-b8668-xcframework.zip",
            checksum: "639716d1e2fb47f1d4361fea9609fcd7286aff4618b2f9b8a4743c28d8ab41fb"
        ),
        .target(
            name: "SwiftLlama",
            dependencies: ["llama-cpp"]
        )
    ]
)
