import Foundation
import os.log

public final class LlamaContext: @unchecked Sendable {
    public let context: OpaquePointer
    public let model: LlamaModel
    private var batch: llama_batch

    private static let logger = Logger(subsystem: "com.zk.swift-llama", category: "LlamaContext")

    init(model: LlamaModel) throws {
        self.model = model
        var ctxParams = llama_context_default_params()
        ctxParams.n_ctx = model.config.contextSize
        ctxParams.n_threads = Int32(model.config.effectiveThreads)
        ctxParams.n_threads_batch = Int32(model.config.effectiveThreads)
        ctxParams.n_batch = UInt32(model.config.batchSize)
        guard let ctx = llama_init_from_model(model.model, ctxParams) else {
            throw LlamaError.failedToCreateContext
        }
        self.context = ctx
        self.batch = llama_batch_init(model.config.batchSize, 0, 1)
        Self.logger.info("Context: \(llama_n_ctx(ctx)) tokens; batch \(model.config.batchSize)")
    }

    public var contextSize: Int { Int(llama_n_ctx(context)) }
    public var batchCapacity: Int { Int(model.config.batchSize) }

    func tokenize(_ text: String, addSpecial: Bool = true) throws -> [llama_token] {
        let utf8 = text.utf8CString
        let maxTokens = max(Int32(utf8.count) + (addSpecial ? 8 : 0), 32)
        var tokens = [llama_token](repeating: 0, count: Int(maxTokens))
        let tokenCount = llama_tokenize(
            model.vocab,
            text,
            Int32(text.utf8.count),
            &tokens,
            maxTokens,
            addSpecial,
            true
        )
        guard tokenCount >= 0 else { throw LlamaError.tokenizationFailed }
        tokens.removeSubrange(Int(tokenCount)..<tokens.count)
        return tokens
    }

    func clearBatch() { batch.n_tokens = 0 }

    func addTokenToBatch(_ token: llama_token, position: Int32, sequenceID: llama_seq_id = 0, logits: Bool = false) {
        let i = Int(batch.n_tokens)
        batch.token[i] = token
        batch.pos[i] = position
        batch.n_seq_id[i] = 1
        batch.seq_id[i]![0] = sequenceID
        batch.logits[i] = logits ? 1 : 0
        batch.n_tokens += 1
    }

    func decode() throws {
        let status = llama_decode(context, batch)
        guard status == 0 else {
            if status == 1 { throw LlamaError.kvCacheFull }
            throw LlamaError.decodingFailed(status: status)
        }
    }

    func tokenToString(_ token: llama_token) -> [CChar] {
        var result = [CChar](repeating: 0, count: 256)
        let length = llama_token_to_piece(model.vocab, token, &result, Int32(result.count), 0, true)
        if length > 0 { result.removeSubrange(Int(length)..<result.count) }
        else { result.removeAll() }
        return result
    }

    func isEndOfGeneration(_ token: llama_token) -> Bool { llama_vocab_is_eog(model.vocab, token) }

    deinit {
        llama_batch_free(batch)
        llama_free(context)
    }
}
