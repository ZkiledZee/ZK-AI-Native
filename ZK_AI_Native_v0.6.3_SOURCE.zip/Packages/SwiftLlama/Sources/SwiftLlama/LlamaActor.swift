import Foundation
import os.log

public actor LlamaActor {
    private let llamaContext: LlamaContext
    private var sampling: LlamaSampling
    private var isCancelled = false
    private static let logger = Logger(subsystem: "com.zk.swift-llama", category: "LlamaActor")

    public init(model: LlamaModel, params: SamplingParams = .balanced) throws {
        self.llamaContext = try model.makeContext()
        self.sampling = LlamaSampling(params: params)
    }

    public func cancel() { isCancelled = true }

    public func generate(prompt: String, params: SamplingParams? = nil) -> AsyncThrowingStream<String, Error> {
        if let params { self.sampling = LlamaSampling(params: params) }
        return AsyncThrowingStream { continuation in
            Task {
                do { try await self.runInference(prompt: prompt, params: params, continuation: continuation) }
                catch { continuation.finish(throwing: error) }
            }
        }
    }

    private func runInference(
        prompt: String,
        params: SamplingParams?,
        continuation: AsyncThrowingStream<String, Error>.Continuation
    ) async throws {
        isCancelled = false
        let maxTokens = Int(params?.maxTokens ?? 256)
        let tokens = try llamaContext.tokenize(prompt)
        let reserve = maxTokens + 16
        guard tokens.count + reserve < llamaContext.contextSize else {
            throw LlamaError.promptTooLong(tokens: tokens.count, context: llamaContext.contextSize, reserved: reserve)
        }

        // The upstream wrapper submits the entire prompt in one batch. On 4 GB iPhones,
        // making n_batch large enough for that creates a large transient compute buffer and
        // can be jetsam-killed. Prefill the prompt in bounded chunks instead.
        let chunkSize = max(32, min(llamaContext.batchCapacity, 192))
        var start = 0
        while start < tokens.count {
            if isCancelled { throw LlamaError.cancelled }
            let end = min(start + chunkSize, tokens.count)
            llamaContext.clearBatch()
            for i in start..<end {
                llamaContext.addTokenToBatch(
                    tokens[i],
                    position: Int32(i),
                    logits: i == tokens.count - 1
                )
            }
            try llamaContext.decode()
            start = end
            await Task.yield()
        }

        var currentPosition = Int32(tokens.count)
        var utf8Buffer: [CChar] = []

        for _ in 0..<maxTokens {
            if isCancelled { throw LlamaError.cancelled }
            let newToken = sampling.sample(context: llamaContext.context, batchIndex: 0)
            if llamaContext.isEndOfGeneration(newToken) { break }

            let piece = llamaContext.tokenToString(newToken)
            utf8Buffer.append(contentsOf: piece)
            utf8Buffer.append(0)
            if let tokenString = String(validatingUTF8: utf8Buffer) {
                utf8Buffer.removeAll(keepingCapacity: true)
                if !tokenString.isEmpty { continuation.yield(tokenString) }
            } else {
                utf8Buffer.removeLast()
            }

            llamaContext.clearBatch()
            llamaContext.addTokenToBatch(newToken, position: currentPosition, logits: true)
            try llamaContext.decode()
            currentPosition += 1
            if currentPosition >= Int32(llamaContext.contextSize - 1) { break }
        }
        continuation.finish()
    }
}
