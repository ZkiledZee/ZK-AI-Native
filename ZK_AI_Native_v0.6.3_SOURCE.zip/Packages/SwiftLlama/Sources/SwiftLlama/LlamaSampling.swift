import Foundation

public final class LlamaSampling: @unchecked Sendable {
    let sampler: UnsafeMutablePointer<llama_sampler>

    public init(params: SamplingParams = .balanced) {
        let chain = llama_sampler_chain_init(llama_sampler_chain_default_params())!
        if params.repeatPenalty != 1.0 {
            llama_sampler_chain_add(chain, llama_sampler_init_penalties(64, params.repeatPenalty, 0.0, 0.0))
        }
        if params.topK > 0 { llama_sampler_chain_add(chain, llama_sampler_init_top_k(params.topK)) }
        if params.topP < 1.0 { llama_sampler_chain_add(chain, llama_sampler_init_top_p(params.topP, 1)) }
        if params.temperature > 0 {
            llama_sampler_chain_add(chain, llama_sampler_init_temp(params.temperature))
            llama_sampler_chain_add(chain, llama_sampler_init_dist(UInt32.random(in: 0..<UInt32.max)))
        } else {
            llama_sampler_chain_add(chain, llama_sampler_init_greedy())
        }
        self.sampler = chain
    }

    func sample(context: OpaquePointer, batchIndex: Int32) -> llama_token {
        llama_sampler_sample(sampler, context, batchIndex)
    }

    deinit { llama_sampler_free(sampler) }
}
