import Foundation

public struct ModelConfig: Sendable {
    public var contextSize: UInt32
    public var batchSize: Int32
    public var gpuLayers: GPULayers
    public var threads: Int
    public var seed: UInt32

    public init(
        contextSize: UInt32 = 2048,
        batchSize: Int32 = 256,
        gpuLayers: GPULayers = .none,
        threads: Int = 4,
        seed: UInt32 = 0xFFFFFFFF
    ) {
        self.contextSize = contextSize
        self.batchSize = batchSize
        self.gpuLayers = gpuLayers
        self.threads = threads
        self.seed = seed
    }

    public var effectiveThreads: Int {
        let maxThreads = ProcessInfo.processInfo.processorCount
        if threads <= 0 { return min(max(maxThreads - 2, 1), 8) }
        return min(threads, maxThreads)
    }
}

public enum GPULayers: Sendable, Equatable {
    case all
    case none
    case count(Int32)

    public var rawValue: Int32 {
        switch self {
        case .all: 999
        case .none: 0
        case .count(let n): n
        }
    }
}

public struct SamplingParams: Sendable {
    public var temperature: Float
    public var topP: Float
    public var topK: Int32
    public var repeatPenalty: Float
    public var maxTokens: Int32

    public init(
        temperature: Float = 0.7,
        topP: Float = 0.9,
        topK: Int32 = 40,
        repeatPenalty: Float = 1.1,
        maxTokens: Int32 = 512
    ) {
        self.temperature = temperature
        self.topP = topP
        self.topK = topK
        self.repeatPenalty = repeatPenalty
        self.maxTokens = maxTokens
    }

    public static let greedy = SamplingParams(temperature: 0.0, topP: 1.0, topK: 1)
    public static let balanced = SamplingParams(temperature: 0.7, topP: 0.9, topK: 40)
}

public enum ModelSource: Sendable {
    case huggingFace(repo: String, file: String)
    case url(URL)

    public var downloadURL: URL {
        switch self {
        case .huggingFace(let repo, let file):
            return URL(string: "https://huggingface.co/\(repo)/resolve/main/\(file)")!
        case .url(let url):
            return url
        }
    }
}

public enum DownloadEvent: Sendable {
    case progress(percent: Double, bytesDownloaded: Int64, totalBytes: Int64)
    case verifying
    case completed(URL)
    case failed(LlamaError)
}

public enum LlamaError: Error, Sendable {
    case failedToLoadModel(path: String)
    case failedToCreateContext
    case tokenizationFailed
    case decodingFailed(status: Int32)
    case kvCacheFull
    case cancelled
    case promptTooLong(tokens: Int, context: Int, reserved: Int)
    case downloadFailed(underlying: String)
    case checksumMismatch(expected: String, actual: String)
    case invalidModelPath(String)
}

extension LlamaError: LocalizedError {
    public var errorDescription: String? {
        switch self {
        case .failedToLoadModel(let path): return "Failed to load model from: \(path)"
        case .failedToCreateContext: return "Failed to create inference context"
        case .tokenizationFailed: return "Failed to tokenize input"
        case .decodingFailed(let status): return "Decoding failed with status: \(status)"
        case .kvCacheFull: return "KV cache is full — context window exceeded"
        case .cancelled: return "Inference was cancelled"
        case .promptTooLong(let tokens, let context, let reserved):
            return "Prompt is too long (\(tokens) tokens for \(context)-token context with \(reserved) reserved for reply)."
        case .downloadFailed(let underlying): return "Download failed: \(underlying)"
        case .checksumMismatch(let expected, let actual): return "Checksum mismatch — expected: \(expected), got: \(actual)"
        case .invalidModelPath(let path): return "Invalid model path: \(path)"
        }
    }
}
