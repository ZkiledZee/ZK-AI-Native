import Foundation
import CryptoKit
import os.log

public actor ModelDownloader {
    private static let logger = Logger(subsystem: "com.zk.swift-llama", category: "ModelDownloader")
    public init() {}

    public func download(from source: ModelSource, to destination: URL, expectedSHA256: String? = nil) -> AsyncStream<DownloadEvent> {
        AsyncStream { continuation in
            Task {
                await self.performDownload(url: source.downloadURL, destination: destination, expectedSHA256: expectedSHA256, continuation: continuation)
            }
        }
    }

    private func performDownload(
        url: URL,
        destination: URL,
        expectedSHA256: String?,
        continuation: AsyncStream<DownloadEvent>.Continuation
    ) async {
        do {
            try FileManager.default.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
            var request = URLRequest(url: url)
            var existingBytes: Int64 = 0
            if FileManager.default.fileExists(atPath: destination.path) {
                let attrs = try FileManager.default.attributesOfItem(atPath: destination.path)
                existingBytes = attrs[.size] as? Int64 ?? 0
                request.setValue("bytes=\(existingBytes)-", forHTTPHeaderField: "Range")
            }

            let (asyncBytes, response) = try await URLSession.shared.bytes(for: request)
            guard let http = response as? HTTPURLResponse,
                  (200...299).contains(http.statusCode) || http.statusCode == 206 else {
                continuation.yield(.failed(.downloadFailed(underlying: "HTTP \((response as? HTTPURLResponse)?.statusCode ?? 0)")))
                continuation.finish(); return
            }

            let total = http.expectedContentLength > 0 ? http.expectedContentLength + existingBytes : -1
            let handle: FileHandle
            if http.statusCode == 206 {
                handle = try FileHandle(forWritingTo: destination)
                handle.seekToEndOfFile()
            } else {
                FileManager.default.createFile(atPath: destination.path, contents: nil)
                handle = try FileHandle(forWritingTo: destination)
                existingBytes = 0
            }

            var downloaded = existingBytes
            var lastPercent = -1.0
            var buffer = Data()
            let bufferSize = 1024 * 1024
            for try await byte in asyncBytes {
                buffer.append(byte)
                if buffer.count >= bufferSize {
                    handle.write(buffer)
                    downloaded += Int64(buffer.count)
                    buffer.removeAll(keepingCapacity: true)
                    if total > 0 {
                        let percent = Double(downloaded) / Double(total) * 100
                        if percent - lastPercent >= 0.5 {
                            continuation.yield(.progress(percent: percent, bytesDownloaded: downloaded, totalBytes: total))
                            lastPercent = percent
                        }
                    }
                }
            }
            if !buffer.isEmpty { handle.write(buffer); downloaded += Int64(buffer.count) }
            handle.closeFile()

            if let expectedSHA256, !expectedSHA256.isEmpty {
                continuation.yield(.verifying)
                let actual = try sha256(of: destination)
                guard actual.lowercased() == expectedSHA256.lowercased() else {
                    try? FileManager.default.removeItem(at: destination)
                    continuation.yield(.failed(.checksumMismatch(expected: expectedSHA256, actual: actual)))
                    continuation.finish(); return
                }
            }
            continuation.yield(.completed(destination))
            continuation.finish()
        } catch {
            continuation.yield(.failed(.downloadFailed(underlying: error.localizedDescription)))
            continuation.finish()
        }
    }

    private func sha256(of fileURL: URL) throws -> String {
        let handle = try FileHandle(forReadingFrom: fileURL)
        var hasher = SHA256()
        while true {
            let data = handle.readData(ofLength: 10 * 1024 * 1024)
            if data.isEmpty { break }
            hasher.update(data: data)
        }
        handle.closeFile()
        return hasher.finalize().map { String(format: "%02x", $0) }.joined()
    }
}
