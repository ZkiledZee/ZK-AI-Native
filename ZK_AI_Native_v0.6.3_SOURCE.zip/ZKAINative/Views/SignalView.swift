import SwiftUI

struct SignalView: View {
    @EnvironmentObject private var state: AppState
    @EnvironmentObject private var market: MarketDataService
    @Environment(\.zkScale) private var scale
    @StateObject private var notifications = NotificationManager.shared
    @AppStorage("zk.settings.signalTV") private var signalUsesTradingView = true

    var body: some View {
        VStack(spacing: 8 * scale) {
            ZKPageHeader(
                micro: "SIGNAL CONSOLE • 1M",
                title: "Live market",
                pill: market.feedStatus.rawValue,
                pillColor: feedColor
            )

            marketStrip
            modelStrip
            signalCore
            chart.frame(maxHeight: .infinity)
            levels
            lifecycle
        }
        .padding(.horizontal, 16 * scale)
        .padding(.top, 8 * scale)
        .padding(.bottom, 8 * scale)
        .background(ZKTheme.background)
        .task { state.notificationPermission = await notifications.refresh() }
    }

    private var marketStrip: some View {
        HStack(spacing: 6 * scale) {
            VStack(alignment: .leading, spacing: 2 * scale) {
                Text("XAU / USD")
                    .font(.system(size: 8 * scale, weight: .black))
                    .foregroundStyle(ZKTheme.textMuted)
                Text(market.currentPrice.map { String(format: "$%.2f", $0) } ?? "—")
                    .font(.system(size: 15 * scale, weight: .black, design: .monospaced))
                    .contentTransition(.numericText())
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 2 * scale) {
                Text(signalUsesTradingView ? "NATIVE REF PRICE" : "REFERENCE FEED")
                    .font(.system(size: 7 * scale, weight: .black))
                    .foregroundStyle(ZKTheme.textMuted)
                Text(signalUsesTradingView ? "TV CHART • ICM" : "XAUS • \(market.freshnessText)")
                    .font(.system(size: 9 * scale, weight: .bold))
                    .foregroundStyle(feedColor)
            }
        }
        .padding(.horizontal, 11 * scale)
        .padding(.vertical, 9 * scale)
        .background(Color(red: 0.035, green: 0.027, blue: 0.051))
        .overlay(RoundedRectangle(cornerRadius: 12 * scale).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 12 * scale))
    }

    private var modelStrip: some View {
        HStack {
            VStack(alignment: .leading, spacing: 3 * scale) {
                Text("TRADING MODEL")
                    .font(.system(size: 8 * scale, weight: .black))
                    .tracking(0.8)
                    .foregroundStyle(ZKTheme.textMuted)
                Text("Not enabled yet")
                    .font(.system(size: 12 * scale, weight: .bold))
            }
            Spacer()
            Text("DATA ONLY")
                .font(.system(size: 8 * scale, weight: .black))
                .tracking(0.5)
                .foregroundStyle(ZKTheme.gold)
                .padding(.horizontal, 9 * scale)
                .padding(.vertical, 6 * scale)
                .background(ZKTheme.gold.opacity(0.07))
                .overlay(Capsule().stroke(ZKTheme.gold.opacity(0.35)))
                .clipShape(Capsule())
        }
        .padding(.horizontal, 11 * scale)
        .padding(.vertical, 9 * scale)
        .background(LinearGradient(colors: [Color(red: 0.063, green: 0.043, blue: 0.078), Color(red: 0.031, green: 0.024, blue: 0.043)], startPoint: .topLeading, endPoint: .bottomTrailing))
        .overlay(RoundedRectangle(cornerRadius: 14 * scale).stroke(ZKTheme.borderStrong))
        .clipShape(RoundedRectangle(cornerRadius: 14 * scale))
    }

    private var signalCore: some View {
        VStack(spacing: 8 * scale) {
            HStack(alignment: .center, spacing: 11 * scale) {
                SignalOrb(color: ZKTheme.gold)
                VStack(alignment: .leading, spacing: 4 * scale) {
                    Text("AI BIAS")
                        .font(.system(size: 8 * scale, weight: .black))
                        .tracking(0.8)
                        .foregroundStyle(ZKTheme.textSoft)
                    Text("WAIT")
                        .font(.system(size: 27 * scale, weight: .black, design: .rounded))
                        .tracking(-0.8)
                        .foregroundStyle(ZKTheme.gold)
                    Text("MODEL STAGE NOT STARTED")
                        .font(.system(size: 7.5 * scale, weight: .black))
                        .foregroundStyle(ZKTheme.textMuted)
                }
                Spacer()
                ConfidenceRing(value: 0, color: ZKTheme.gold, label: "EXEC")
            }

            HStack(spacing: 6 * scale) {
                ProbabilityCell(label: "BUY", value: 0, color: ZKTheme.green)
                ProbabilityCell(label: "WAIT", value: 1, color: ZKTheme.gold)
                ProbabilityCell(label: "SELL", value: 0, color: ZKTheme.red)
            }

            Text("The live data layer is running independently. No AI probability, entry, SL or TP is generated in this build.")
                .font(.system(size: 10 * scale, weight: .medium))
                .foregroundStyle(ZKTheme.textMuted)
                .frame(maxWidth: .infinity, alignment: .leading)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(12 * scale)
        .background(RadialGradient(colors: [ZKTheme.gold.opacity(0.09), Color(red: 0.051, green: 0.035, blue: 0.067)], center: .topTrailing, startRadius: 0, endRadius: 180))
        .overlay(RoundedRectangle(cornerRadius: 18 * scale).stroke(ZKTheme.gold.opacity(0.24)))
        .clipShape(RoundedRectangle(cornerRadius: 18 * scale))
    }

    private var chart: some View {
        ZStack(alignment: .top) {
            if signalUsesTradingView {
                TradingViewICMarketsChart(compact: true, showHeader: false)
                    .padding(.top, 34 * scale)
            } else if market.candles.isEmpty {
                VStack(spacing: 8 * scale) {
                    ProgressView().tint(ZKTheme.purple)
                    Text(market.feedStatus == .offline ? "Native chart unavailable" : "Loading native XAUUSD 1M candles…")
                        .font(.system(size: 10 * scale, weight: .bold))
                        .foregroundStyle(ZKTheme.textMuted)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                NativeAgentChart(candles: market.candles, drawings: state.drawings)
                    .padding(.top, 34 * scale)
            }

            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 2 * scale) {
                    Text("XAUUSD • 1M")
                        .font(.system(size: 12 * scale, weight: .black))
                    Text(signalUsesTradingView ? "IC Markets chart via TradingView" : "ZK native chart • smooth pan / pinch / tap")
                        .font(.system(size: 8 * scale))
                        .foregroundStyle(ZKTheme.textMuted)
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 2 * scale) {
                    Text("SOURCE")
                        .font(.system(size: 7 * scale, weight: .black))
                        .foregroundStyle(ZKTheme.textMuted)
                    Text(signalUsesTradingView ? "ICM TV" : "XAUS")
                        .font(.system(size: 11 * scale, weight: .black))
                        .foregroundStyle(signalUsesTradingView ? ZKTheme.green : feedColor)
                }
            }
            .padding(10 * scale)
            .allowsHitTesting(false)
        }
        .frame(minHeight: 180 * scale)
        .background(RadialGradient(colors: [ZKTheme.purple.opacity(0.07), Color(red: 0.031, green: 0.024, blue: 0.043)], center: .topTrailing, startRadius: 0, endRadius: 220))
        .overlay(RoundedRectangle(cornerRadius: 18 * scale).stroke(ZKTheme.borderStrong))
        .clipShape(RoundedRectangle(cornerRadius: 18 * scale))
    }

    private var levels: some View {
        HStack(spacing: 5 * scale) {
            levelText("ENTRY", "AI OFF", ZKTheme.textMuted)
            levelText("SL", "AI OFF", ZKTheme.textMuted)
            levelText("TP", "AI OFF", ZKTheme.textMuted)
            levelText("R:R", "—", Color(red: 0.831, green: 0.478, blue: 0.894))
        }
    }

    private func levelText(_ title: String, _ text: String, _ color: Color) -> some View {
        VStack(spacing: 3 * scale) {
            Text(title).font(.system(size: 7 * scale, weight: .black)).foregroundStyle(ZKTheme.textMuted)
            Text(text).font(.system(size: 9 * scale, weight: .black, design: .monospaced)).foregroundStyle(color).minimumScaleFactor(0.65).lineLimit(1)
        }
        .frame(maxWidth: .infinity).padding(.vertical, 8 * scale)
        .background(Color(red: 0.035, green: 0.027, blue: 0.051))
        .overlay(RoundedRectangle(cornerRadius: 11 * scale).stroke(ZKTheme.border)).clipShape(RoundedRectangle(cornerRadius: 11 * scale))
    }

    private var lifecycle: some View {
        HStack(spacing: 7 * scale) {
            Circle().fill(feedColor).frame(width: 7 * scale, height: 7 * scale)
            Text("\(market.feedStatus.rawValue) MARKET DATA • AI OFF")
                .font(.system(size: 8 * scale, weight: .black))
                .foregroundStyle(.white.opacity(0.86))
            Spacer()
            Button {
                Task {
                    if !state.notificationPermission { state.notificationPermission = await notifications.request() }
                    if state.notificationPermission { await notifications.sendDemo() }
                }
            } label: {
                Text(state.notificationPermission ? "TEST ALERT" : "ENABLE ALERTS")
                    .font(.system(size: 8 * scale, weight: .black))
                    .foregroundStyle(Color(red: 0.831, green: 0.478, blue: 0.894))
            }
            .buttonStyle(ZKPressStyle())
        }
        .padding(.horizontal, 10 * scale)
        .frame(height: 34 * scale)
        .background(Color(red: 0.035, green: 0.027, blue: 0.051))
        .overlay(RoundedRectangle(cornerRadius: 10 * scale).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 10 * scale))
    }

    private var feedColor: Color {
        switch market.feedStatus {
        case .live: return ZKTheme.green
        case .stale, .connecting: return ZKTheme.gold
        case .offline: return ZKTheme.red
        }
    }
}
