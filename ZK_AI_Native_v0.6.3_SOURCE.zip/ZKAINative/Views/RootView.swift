import SwiftUI

struct RootView: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        GeometryReader { geo in
            ZStack {
                ZKTheme.background.ignoresSafeArea()

                Group {
                    switch state.page {
                    case .home: HomeView()
                    case .chart: ChartView()
                    case .lab: AILabView()
                    case .signal: SignalView()
                    case .backtest: BacktestView()
                    case .chat: ChatView()
                    case .settings: SettingsView()
                    }
                }
                .transition(.opacity)
            }
            .environment(\.zkScale, ZKTheme.scale(for: geo.size.width))
            .safeAreaInset(edge: .bottom, spacing: 0) {
                BottomNav()
                    .environmentObject(state)
            }
        }
        .background(ZKTheme.background)
    }
}
