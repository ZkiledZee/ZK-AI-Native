import SwiftUI

struct ChartView: View {
    @EnvironmentObject private var state: AppState
    @EnvironmentObject private var market: MarketDataService
    @Environment(\.zkScale) private var scale

    var body: some View {
        VStack(spacing: 8 * scale) {
            ZKPageHeader(
                micro: "IC MARKETS + ZK NATIVE",
                title: "XAUUSD • 1M",
                pill: state.chartMode == 0 ? "ICM TV" : market.feedStatus.rawValue,
                pillColor: state.chartMode == 0 ? ZKTheme.green : feedColor
            )

            modeTabs
            sourceBar

            if state.chartMode == 0 {
                tradingViewChart
            } else if market.candles.isEmpty {
                emptyState
            } else {
                nativeChart
            }
        }
        .padding(.horizontal, 14 * scale)
        .padding(.top, 8 * scale)
        .padding(.bottom, 8 * scale)
        .background(ZKTheme.background)
        .refreshable { await market.refreshAll() }
        .onChange(of: state.chartMode) { _, newValue in
            UserDefaults.standard.set(newValue, forKey: "zk.settings.chartMode")
        }
    }

    private var modeTabs: some View {
        HStack(spacing: 6 * scale) {
            tab("IC MARKETS TV", 0, icon: "waveform.path.ecg.rectangle")
            tab("ZK NATIVE", 1, icon: "chart.xyaxis.line")
        }
    }

    private func tab(_ title: String, _ index: Int, icon: String) -> some View {
        Button { state.chartMode = index } label: {
            HStack(spacing: 6 * scale) {
                Image(systemName: icon)
                    .font(.system(size: 10 * scale, weight: .bold))
                Text(title)
                    .font(.system(size: 8.5 * scale, weight: .black))
                    .tracking(0.35)
            }
            .foregroundStyle(state.chartMode == index ? .white : ZKTheme.textMuted)
            .frame(maxWidth: .infinity, minHeight: 38 * scale)
            .background(state.chartMode == index ? Color(red: 0.086, green: 0.051, blue: 0.110) : ZKTheme.card)
            .overlay(RoundedRectangle(cornerRadius: 11 * scale).stroke(state.chartMode == index ? ZKTheme.borderStrong : ZKTheme.border))
            .clipShape(RoundedRectangle(cornerRadius: 11 * scale))
        }
        .buttonStyle(ZKPressStyle())
    }

    private var sourceBar: some View {
        HStack(spacing: 8 * scale) {
            VStack(alignment: .leading, spacing: 2 * scale) {
                Text(state.chartMode == 0 ? "VISUAL SOURCE" : "NATIVE FALLBACK")
                    .font(.system(size: 7 * scale, weight: .black))
                    .foregroundStyle(ZKTheme.textMuted)
                Text(state.chartMode == 0 ? "ICMARKETS:XAUUSD" : "XAUS XAU/USD")
                    .font(.system(size: 11 * scale, weight: .black, design: .monospaced))
                    .foregroundStyle(state.chartMode == 0 ? ZKTheme.green : .white)
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 2 * scale) {
                Text("TIMEFRAME")
                    .font(.system(size: 7 * scale, weight: .black))
                    .foregroundStyle(ZKTheme.textMuted)
                Text("1 MINUTE")
                    .font(.system(size: 9 * scale, weight: .black))
            }
            if state.chartMode == 1 {
                Button {
                    Task { await market.refreshAll() }
                } label: {
                    Image(systemName: "arrow.clockwise")
                        .font(.system(size: 12 * scale, weight: .bold))
                        .frame(width: 30 * scale, height: 30 * scale)
                        .background(ZKTheme.card2)
                        .overlay(Circle().stroke(ZKTheme.border))
                        .clipShape(Circle())
                }
                .buttonStyle(ZKPressStyle())
            }
        }
        .padding(.horizontal, 10 * scale)
        .padding(.vertical, 7 * scale)
        .background(ZKTheme.card.opacity(0.88))
        .overlay(RoundedRectangle(cornerRadius: 11 * scale).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 11 * scale))
    }

    private var tradingViewChart: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 3 * scale) {
                    Text("TRADINGVIEW • IC MARKETS")
                        .font(.system(size: 8 * scale, weight: .black))
                        .tracking(0.7)
                        .foregroundStyle(ZKTheme.textMuted)
                    Text("Direct TradingView widget • drag / zoom / inspect")
                        .font(.system(size: 10 * scale, weight: .bold))
                        .foregroundStyle(.white.opacity(0.9))
                }
                Spacer()
                Text("1M")
                    .font(.system(size: 9 * scale, weight: .black, design: .monospaced))
                    .foregroundStyle(ZKTheme.green)
            }
            .padding(.horizontal, 11 * scale)
            .frame(height: 46 * scale)
            .background(Color(red: 0.039, green: 0.027, blue: 0.063))

            TradingViewICMarketsChart(compact: false, showHeader: false)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding(4 * scale)

            Text("This view is the TradingView IC Markets XAUUSD chart itself. The ZK native chart is separate because TradingView does not expose its candle feed to the app.")
                .font(.system(size: 7.6 * scale, weight: .medium))
                .foregroundStyle(ZKTheme.textMuted)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 10 * scale)
                .frame(minHeight: 32 * scale)
                .background(ZKTheme.navBackground)
        }
        .frame(maxHeight: .infinity)
        .background(Color(red: 0.031, green: 0.024, blue: 0.043))
        .overlay(RoundedRectangle(cornerRadius: 18 * scale).stroke(ZKTheme.borderStrong))
        .clipShape(RoundedRectangle(cornerRadius: 18 * scale))
    }

    private var nativeChart: some View {
        VStack(spacing: 0) {
            chartHeader(
                title: "ZK NATIVE CHART",
                subtitle: "Continuous drag • momentum • pinch zoom • tap candle",
                trailing: "\(state.drawings.count) DRAWINGS"
            )

            NativeAgentChart(candles: market.candles, drawings: state.drawings)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding(.vertical, 4 * scale)

            drawingToolbar
            footer("The native chart is optimized for our future AI overlays and tools. It uses the native fallback feed, so exact candle equality with TradingView requires a broker-authorized IC Markets feed later.")
        }
        .frame(maxHeight: .infinity)
        .background(Color(red: 0.031, green: 0.024, blue: 0.043))
        .overlay(RoundedRectangle(cornerRadius: 18 * scale).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 18 * scale))
    }

    private var emptyState: some View {
        VStack(spacing: 12 * scale) {
            Spacer()
            Image(systemName: market.feedStatus == .offline ? "wifi.slash" : "antenna.radiowaves.left.and.right")
                .font(.system(size: 32 * scale, weight: .medium))
                .foregroundStyle(feedColor)
            Text(market.feedStatus == .offline ? "Native market feed unavailable" : "Loading native XAUUSD candles")
                .font(.system(size: 15 * scale, weight: .bold))
            Text(market.lastError ?? "Switch to IC Markets TV above for the TradingView chart while the native feed loads.")
                .font(.system(size: 10 * scale, weight: .medium))
                .foregroundStyle(ZKTheme.textMuted)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 22 * scale)
            Button("RETRY") {
                Task { await market.refreshAll() }
            }
            .font(.system(size: 9 * scale, weight: .black))
            .foregroundStyle(Color(red: 0.84, green: 0.48, blue: 0.91))
            .padding(.horizontal, 16 * scale)
            .frame(height: 34 * scale)
            .background(ZKTheme.card2)
            .overlay(Capsule().stroke(ZKTheme.borderStrong))
            .clipShape(Capsule())
            .buttonStyle(ZKPressStyle())
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(ZKTheme.card.opacity(0.45))
        .overlay(RoundedRectangle(cornerRadius: 18 * scale).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 18 * scale))
    }

    private func chartHeader(title: String, subtitle: String, trailing: String) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 3 * scale) {
                Text(title)
                    .font(.system(size: 8 * scale, weight: .black))
                    .tracking(0.7)
                    .foregroundStyle(ZKTheme.textMuted)
                Text(subtitle)
                    .font(.system(size: 10 * scale, weight: .bold))
                    .foregroundStyle(.white.opacity(0.9))
            }
            Spacer()
            Text(trailing)
                .font(.system(size: 8 * scale, weight: .bold))
                .foregroundStyle(ZKTheme.textSoft)
        }
        .padding(.horizontal, 11 * scale)
        .frame(height: 48 * scale)
        .background(Color(red: 0.039, green: 0.027, blue: 0.063))
    }

    private var drawingToolbar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 6 * scale) {
                tool("S/R") { state.replaceSupportResistance(around: market.currentPrice) }
                tool("ZONE") { state.addZone(around: market.currentPrice) }
                tool("UNDO") { state.removeLastDrawing() }
                tool("NO SUP") { state.removeSupport() }
                tool("NO RES") { state.removeResistance() }
                tool("CLEAR") { state.clearAllDrawings() }
            }
            .padding(.horizontal, 9 * scale)
        }
        .frame(height: 46 * scale)
        .background(Color(red: 0.039, green: 0.027, blue: 0.063))
        .overlay(alignment: .top) { Rectangle().fill(ZKTheme.border.opacity(0.7)).frame(height: 1) }
    }

    private func tool(_ name: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(name)
                .font(.system(size: 8 * scale, weight: .black))
                .foregroundStyle(Color(red: 0.831, green: 0.478, blue: 0.894))
                .padding(.horizontal, 10 * scale)
                .frame(height: 30 * scale)
                .background(Color(red: 0.086, green: 0.051, blue: 0.110))
                .overlay(Capsule().stroke(ZKTheme.borderStrong))
                .clipShape(Capsule())
        }
        .buttonStyle(ZKPressStyle())
    }

    private func footer(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 7.6 * scale, weight: .medium))
            .foregroundStyle(Color(red: 0.46, green: 0.42, blue: 0.48))
            .multilineTextAlignment(.center)
            .padding(.horizontal, 10 * scale)
            .frame(minHeight: 34 * scale)
            .background(ZKTheme.navBackground)
    }

    private var feedColor: Color {
        switch market.feedStatus {
        case .live: return ZKTheme.green
        case .stale, .connecting: return ZKTheme.gold
        case .offline: return ZKTheme.red
        }
    }
}
