import SwiftUI

struct NativeAgentChart: View {
    @Environment(\.zkScale) private var scale
    let candles: [ChartCandle]
    let drawings: [ChartDrawing]

    @AppStorage("zk.settings.chartGrid") private var showGrid = true
    @AppStorage("zk.settings.priceLine") private var showPriceLine = true
    @AppStorage("zk.settings.chartMomentum") private var chartMomentum = true

    @State private var visibleCount: CGFloat = 44
    @State private var panOffset: CGFloat = 0
    @State private var pinchBaseCount: CGFloat?
    @State private var selectedIndex: Int?
    @GestureState private var dragPixels: CGFloat = 0

    var body: some View {
        GeometryReader { geo in
            let chartWidth = max(geo.size.width - (56 * scale), 60)
            let baseCount = max(16, min(visibleCount, CGFloat(max(candles.count, 16))))
            let step = chartWidth / max(baseCount, 1)
            let livePan = effectivePanOffset(step: step)
            let layout = makeLayout(size: geo.size, effectivePan: livePan)

            ZStack(alignment: .topTrailing) {
                Canvas { context, _ in
                    if showGrid { drawGrid(context: context, layout: layout) }
                    drawCandles(context: context, layout: layout)
                    drawDrawings(context: context, layout: layout)
                    if showPriceLine { drawLatestPrice(context: context, layout: layout) }
                    drawSelection(context: context, layout: layout)
                    drawAxes(context: context, layout: layout)
                }
                .contentShape(Rectangle())
                .gesture(panGesture(step: step))
                .simultaneousGesture(zoomGesture)
                .simultaneousGesture(tapGesture(layout: layout))

                HStack(spacing: 6 * scale) {
                    if let selected = selectedCandle(in: layout.visible) {
                        Text(selectionText(selected))
                            .font(.system(size: 8 * scale, weight: .semibold, design: .monospaced))
                            .foregroundStyle(.white.opacity(0.88))
                            .padding(.horizontal, 8 * scale)
                            .frame(height: 25 * scale)
                            .background(ZKTheme.navBackground.opacity(0.94))
                            .overlay(Capsule().stroke(ZKTheme.border.opacity(0.8)))
                            .clipShape(Capsule())
                            .lineLimit(1)
                            .minimumScaleFactor(0.62)
                    }

                    Button("FIT") {
                        withAnimation(.snappy(duration: 0.22)) {
                            visibleCount = min(44, CGFloat(max(candles.count, 16)))
                            panOffset = 0
                            selectedIndex = nil
                        }
                    }
                    .font(.system(size: 8 * scale, weight: .black))
                    .foregroundStyle(Color(red: 0.84, green: 0.48, blue: 0.91))
                    .padding(.horizontal, 8 * scale)
                    .frame(height: 25 * scale)
                    .background(ZKTheme.card.opacity(0.94))
                    .overlay(Capsule().stroke(ZKTheme.borderStrong))
                    .clipShape(Capsule())
                    .buttonStyle(ZKPressStyle())
                }
                .padding(7 * scale)
            }
        }
        .accessibilityLabel("Interactive XAUUSD candlestick chart")
        .accessibilityHint("Pinch to zoom, drag with momentum to move through candles, and tap a candle to inspect time and OHLC values")
    }

    private struct Layout {
        let size: CGSize
        let visible: [ChartCandle]
        let leadingExtra: Int
        let chartWidth: CGFloat
        let top: CGFloat
        let bottom: CGFloat
        let high: Double
        let low: Double
        let span: Double
        let step: CGFloat
        let candleWidth: CGFloat
        let fractionalShift: CGFloat

        func x(for localIndex: Int) -> CGFloat {
            (CGFloat(localIndex - leadingExtra) + 0.5 + fractionalShift) * step
        }

        func y(_ value: Double) -> CGFloat {
            top + CGFloat((high - value) / span) * (size.height - top - bottom)
        }
    }

    private func effectivePanOffset(step: CGFloat) -> CGFloat {
        guard step > 0 else { return panOffset }
        let maxOffset = max(0, CGFloat(candles.count) - min(visibleCount, CGFloat(candles.count)))
        return min(max(panOffset + dragPixels / step, 0), maxOffset)
    }

    private func makeLayout(size: CGSize, effectivePan: CGFloat) -> Layout {
        let total = candles.count
        let count = min(max(Int(visibleCount.rounded()), 16), max(total, 16))
        let maxOffset = max(0, total - min(count, total))
        let clamped = min(max(effectivePan, 0), CGFloat(maxOffset))
        let whole = min(max(Int(floor(clamped)), 0), maxOffset)
        let fraction = clamped - CGFloat(whole)

        let end = max(0, total - whole)
        let start = max(0, end - min(count, total))
        let extraStart = max(0, start - 1)
        let extraEnd = min(total, end + 1)
        let leadingExtra = start - extraStart
        let visible = extraStart < extraEnd ? Array(candles[extraStart..<extraEnd]) : candles

        let plotted = visible.filter { candle in
            let local = visible.firstIndex(where: { $0.id == candle.id }) ?? 0
            let x = (CGFloat(local - leadingExtra) + 0.5 + fraction)
            return x >= -1 && x <= CGFloat(count) + 1
        }

        var allPrices = plotted.flatMap { [$0.high, $0.low] }
        for d in drawings {
            allPrices.append(d.price)
            if let p = d.secondaryPrice { allPrices.append(p) }
        }

        let rawHigh = allPrices.max() ?? 1
        let rawLow = allPrices.min() ?? 0
        let rawSpan = max(rawHigh - rawLow, 0.001)
        let high = rawHigh + rawSpan * 0.085
        let low = rawLow - rawSpan * 0.085
        let span = max(high - low, 0.001)
        let chartWidth = max(size.width - (56 * scale), 60)
        let step = chartWidth / CGFloat(max(count, 1))
        let candleWidth = min(max(step * 0.62, 2.2), 11 * scale)

        return Layout(
            size: size,
            visible: visible,
            leadingExtra: leadingExtra,
            chartWidth: chartWidth,
            top: 18 * scale,
            bottom: 22 * scale,
            high: high,
            low: low,
            span: span,
            step: step,
            candleWidth: candleWidth,
            fractionalShift: fraction
        )
    }

    private func drawGrid(context: GraphicsContext, layout: Layout) {
        for row in 0...5 {
            let y = layout.top + (layout.size.height - layout.top - layout.bottom) * CGFloat(row) / 5
            var path = Path()
            path.move(to: CGPoint(x: 0, y: y))
            path.addLine(to: CGPoint(x: layout.chartWidth, y: y))
            context.stroke(path, with: .color(ZKTheme.border.opacity(0.30)), lineWidth: 0.55)
        }

        for col in 0...4 {
            let x = layout.chartWidth * CGFloat(col) / 4
            var path = Path()
            path.move(to: CGPoint(x: x, y: layout.top))
            path.addLine(to: CGPoint(x: x, y: layout.size.height - layout.bottom))
            context.stroke(path, with: .color(ZKTheme.border.opacity(0.14)), lineWidth: 0.45)
        }
    }

    private func drawCandles(context: GraphicsContext, layout: Layout) {
        for (i, candle) in layout.visible.enumerated() {
            let x = layout.x(for: i)
            guard x > -layout.step && x < layout.chartWidth + layout.step else { continue }
            let color = candle.isUp ? ZKTheme.green : ZKTheme.red

            var wick = Path()
            wick.move(to: CGPoint(x: x, y: layout.y(candle.high)))
            wick.addLine(to: CGPoint(x: x, y: layout.y(candle.low)))
            context.stroke(wick, with: .color(color.opacity(0.95)), lineWidth: max(1, scale))

            let top = min(layout.y(candle.open), layout.y(candle.close))
            let bottom = max(layout.y(candle.open), layout.y(candle.close))
            let rect = CGRect(
                x: x - layout.candleWidth / 2,
                y: top,
                width: layout.candleWidth,
                height: max(2 * scale, bottom - top)
            )
            context.fill(Path(roundedRect: rect, cornerRadius: 1.0 * scale), with: .color(color))
        }
    }

    private func drawDrawings(context: GraphicsContext, layout: Layout) {
        for drawing in drawings {
            guard drawing.price >= layout.low && drawing.price <= layout.high else { continue }
            let y1 = layout.y(drawing.price)
            let color = color(for: drawing.kind)

            if drawing.kind == .zone, let second = drawing.secondaryPrice {
                let y2 = layout.y(second)
                let rect = CGRect(x: 0, y: min(y1, y2), width: layout.chartWidth, height: abs(y2 - y1))
                context.fill(Path(rect), with: .color(color.opacity(0.08)))
                context.stroke(Path(rect), with: .color(color.opacity(0.55)), lineWidth: 0.9)
            } else {
                var path = Path()
                path.move(to: CGPoint(x: 0, y: y1))
                path.addLine(to: CGPoint(x: layout.chartWidth, y: y1))
                context.stroke(path, with: .color(color.opacity(0.92)), style: StrokeStyle(lineWidth: 1, dash: [5, 4]))
            }

            let label = Text(drawing.label)
                .font(.system(size: 7 * scale, weight: .black))
                .foregroundColor(color)
            context.draw(label, at: CGPoint(x: layout.chartWidth - 4, y: y1 - 7 * scale), anchor: .trailing)
        }
    }

    private func drawLatestPrice(context: GraphicsContext, layout: Layout) {
        guard let latest = candles.last else { return }
        guard latest.close >= layout.low && latest.close <= layout.high else { return }
        let y = layout.y(latest.close)
        let color = latest.isUp ? ZKTheme.green : ZKTheme.red

        var line = Path()
        line.move(to: CGPoint(x: 0, y: y))
        line.addLine(to: CGPoint(x: layout.chartWidth, y: y))
        context.stroke(line, with: .color(color.opacity(0.36)), style: StrokeStyle(lineWidth: 0.8, dash: [2, 3]))

        let badge = Text(String(format: "%.2f", latest.close))
            .font(.system(size: 7.5 * scale, weight: .black, design: .monospaced))
            .foregroundColor(color)
        context.draw(badge, at: CGPoint(x: layout.size.width - 2, y: y), anchor: .trailing)
    }

    private func drawSelection(context: GraphicsContext, layout: Layout) {
        guard let selectedIndex,
              let local = layout.visible.firstIndex(where: { $0.index == selectedIndex }) else { return }
        let candle = layout.visible[local]
        let x = layout.x(for: local)
        guard x >= 0 && x <= layout.chartWidth else { return }
        let y = layout.y(candle.close)

        var vertical = Path()
        vertical.move(to: CGPoint(x: x, y: layout.top))
        vertical.addLine(to: CGPoint(x: x, y: layout.size.height - layout.bottom))
        context.stroke(vertical, with: .color(.white.opacity(0.28)), style: StrokeStyle(lineWidth: 0.7, dash: [3, 3]))

        var horizontal = Path()
        horizontal.move(to: CGPoint(x: 0, y: y))
        horizontal.addLine(to: CGPoint(x: layout.chartWidth, y: y))
        context.stroke(horizontal, with: .color(.white.opacity(0.22)), style: StrokeStyle(lineWidth: 0.7, dash: [3, 3]))

        context.fill(
            Path(ellipseIn: CGRect(x: x - 3 * scale, y: y - 3 * scale, width: 6 * scale, height: 6 * scale)),
            with: .color(.white)
        )
    }

    private func drawAxes(context: GraphicsContext, layout: Layout) {
        for row in 0...5 {
            let fraction = Double(row) / 5.0
            let price = layout.high - layout.span * fraction
            let y = layout.top + (layout.size.height - layout.top - layout.bottom) * CGFloat(row) / 5
            let text = Text(String(format: "%.2f", price))
                .font(.system(size: 7.2 * scale, weight: .semibold, design: .monospaced))
                .foregroundColor(ZKTheme.textMuted)
            context.draw(text, at: CGPoint(x: layout.size.width - 2, y: y), anchor: .trailing)
        }

        let onScreen = layout.visible.enumerated().filter { pair in
            let x = layout.x(for: pair.offset)
            return x >= 0 && x <= layout.chartWidth
        }
        guard let first = onScreen.first?.element, let last = onScreen.last?.element else { return }
        let left = Text(timeLabel(first.timestamp))
            .font(.system(size: 7 * scale, weight: .medium, design: .monospaced))
            .foregroundColor(ZKTheme.textMuted)
        let right = Text(timeLabel(last.timestamp))
            .font(.system(size: 7 * scale, weight: .medium, design: .monospaced))
            .foregroundColor(ZKTheme.textMuted)
        context.draw(left, at: CGPoint(x: 2, y: layout.size.height - 3), anchor: .bottomLeading)
        context.draw(right, at: CGPoint(x: layout.chartWidth - 2, y: layout.size.height - 3), anchor: .bottomTrailing)
    }

    private func selectedCandle(in visible: [ChartCandle]) -> ChartCandle? {
        guard let selectedIndex else { return nil }
        return visible.first(where: { $0.index == selectedIndex })
    }

    private func panGesture(step: CGFloat) -> some Gesture {
        DragGesture(minimumDistance: 2)
            .updating($dragPixels) { value, state, _ in
                state = value.translation.width
            }
            .onChanged { _ in
                if selectedIndex != nil { selectedIndex = nil }
            }
            .onEnded { value in
                guard step > 0 else { return }
                let maxOffset = max(0, CGFloat(candles.count) - min(visibleCount, CGFloat(candles.count)))
                let finalTranslation = chartMomentum ? value.predictedEndTranslation.width : value.translation.width
                let target = min(max(panOffset + finalTranslation / step, 0), maxOffset)
                withAnimation(chartMomentum ? .interactiveSpring(response: 0.42, dampingFraction: 0.90, blendDuration: 0.08) : .easeOut(duration: 0.12)) {
                    panOffset = target
                }
            }
    }

    private var zoomGesture: some Gesture {
        MagnificationGesture()
            .onChanged { value in
                if pinchBaseCount == nil { pinchBaseCount = visibleCount }
                guard let base = pinchBaseCount else { return }
                let maxCount = max(16, min(CGFloat(candles.count), 140))
                visibleCount = min(max(base / max(value, 0.25), 16), maxCount)
                let maxOffset = max(0, CGFloat(candles.count) - min(visibleCount, CGFloat(candles.count)))
                panOffset = min(panOffset, maxOffset)
            }
            .onEnded { _ in
                pinchBaseCount = nil
            }
    }

    private func tapGesture(layout: Layout) -> some Gesture {
        SpatialTapGesture()
            .onEnded { value in
                guard value.location.x >= 0,
                      value.location.x <= layout.chartWidth,
                      !layout.visible.isEmpty else { return }

                let candidates = layout.visible.enumerated().map { index, candle in
                    (distance: abs(layout.x(for: index) - value.location.x), candle: candle)
                }
                selectedIndex = candidates.min(by: { $0.distance < $1.distance })?.candle.index
            }
    }

    private func timeLabel(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: date)
    }

    private func selectionText(_ candle: ChartCandle) -> String {
        "\(timeLabel(candle.timestamp))  O \(String(format: "%.2f", candle.open))  H \(String(format: "%.2f", candle.high))  L \(String(format: "%.2f", candle.low))  C \(String(format: "%.2f", candle.close))"
    }

    private func color(for kind: DrawingKind) -> Color {
        switch kind {
        case .support: return ZKTheme.green
        case .resistance: return ZKTheme.red
        case .zone: return ZKTheme.purple
        case .entry: return ZKTheme.blue
        case .stopLoss: return ZKTheme.red
        case .takeProfit: return ZKTheme.green
        case .note: return ZKTheme.gold
        }
    }
}
