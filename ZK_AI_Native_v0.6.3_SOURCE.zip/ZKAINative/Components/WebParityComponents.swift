import SwiftUI
import UIKit

struct HomeLogo: View {
    @Environment(\.zkScale) private var scale
    @State private var pulse = false

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 18 * scale, style: .continuous)
                .stroke(ZKTheme.goldLogo.opacity(pulse ? 0.18 : 0.42), lineWidth: 1.2)
                .frame(width: 68 * scale, height: 68 * scale)
                .scaleEffect(pulse ? 1.18 : 0.96)

            RoundedRectangle(cornerRadius: 17 * scale, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [Color(red: 0.08, green: 0.065, blue: 0.055), Color(red: 0.02, green: 0.02, blue: 0.028)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .frame(width: 62 * scale, height: 62 * scale)
                .overlay(
                    RoundedRectangle(cornerRadius: 17 * scale, style: .continuous)
                        .stroke(
                            LinearGradient(colors: [ZKTheme.goldLogo, ZKTheme.gold.opacity(0.60)], startPoint: .topLeading, endPoint: .bottomTrailing),
                            lineWidth: 2.4
                        )
                )
                .shadow(color: ZKTheme.goldLogo.opacity(0.16), radius: 14)

            Text("ZK")
                .font(.system(size: 22 * scale, weight: .black, design: .rounded))
                .foregroundStyle(.white)
                .shadow(color: .white.opacity(0.18), radius: 4)
        }
        .frame(width: 78 * scale, height: 78 * scale)
        .onAppear {
            withAnimation(.easeInOut(duration: 2.8).repeatForever(autoreverses: true)) { pulse = true }
        }
    }
}

struct MiniMarketChart: View {
    @Environment(\.zkScale) private var scale
    let candles: [ChartCandle]

    var body: some View {
        GeometryReader { geo in
            Canvas { context, size in
                let closes = Array(candles.suffix(48)).map(\.close)
                guard closes.count > 1,
                      let hi = closes.max(),
                      let lo = closes.min() else { return }
                let span = max(hi - lo, 0.001)
                let inset: CGFloat = 5 * scale
                let usableW = max(1, size.width - inset * 2)
                let usableH = max(1, size.height - inset * 2)
                let step = usableW / CGFloat(max(closes.count - 1, 1))

                var line = Path()
                for (i, value) in closes.enumerated() {
                    let x = inset + CGFloat(i) * step
                    let y = inset + CGFloat((hi - value) / span) * usableH
                    if i == 0 { line.move(to: CGPoint(x: x, y: y)) }
                    else { line.addLine(to: CGPoint(x: x, y: y)) }
                }

                let isUp = (closes.last ?? 0) >= (closes.first ?? 0)
                let color = isUp ? ZKTheme.green : ZKTheme.red
                context.stroke(line, with: .color(color), style: StrokeStyle(lineWidth: 2.0 * scale, lineCap: .round, lineJoin: .round))

                if let last = closes.last {
                    let y = inset + CGFloat((hi - last) / span) * usableH
                    let rect = CGRect(x: size.width - inset - 3 * scale, y: y - 3 * scale, width: 6 * scale, height: 6 * scale)
                    context.fill(Path(ellipseIn: rect), with: .color(color))
                }
            }
        }
    }
}

struct MarketStatTile: View {
    @Environment(\.zkScale) private var scale
    let title: String
    let value: String
    var valueColor: Color = .white

    var body: some View {
        VStack(alignment: .leading, spacing: 4 * scale) {
            Text(title.uppercased())
                .font(.system(size: 7.5 * scale, weight: .black, design: .rounded))
                .tracking(0.5 * scale)
                .foregroundStyle(ZKTheme.textMuted)
            Text(value)
                .font(.system(size: 12 * scale, weight: .black, design: .monospaced))
                .foregroundStyle(valueColor)
                .lineLimit(1)
                .minimumScaleFactor(0.72)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(10 * scale)
        .background(Color.black.opacity(0.18))
        .overlay(RoundedRectangle(cornerRadius: 11 * scale).stroke(ZKTheme.border.opacity(0.8)))
        .clipShape(RoundedRectangle(cornerRadius: 11 * scale))
    }
}

struct HomeActionButton: View {
    @Environment(\.zkScale) private var scale
    let icon: String
    let title: String
    let subtitle: String
    var primary: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 12 * scale) {
                Image(systemName: icon)
                    .font(.system(size: 18 * scale, weight: .bold))
                    .foregroundStyle(Color(red: 0.82, green: 0.47, blue: 0.90))
                    .frame(width: 46 * scale, height: 46 * scale)
                    .background(Color(red: 0.086, green: 0.059, blue: 0.106))
                    .overlay(RoundedRectangle(cornerRadius: 14 * scale).stroke(Color(red: 0.286, green: 0.196, blue: 0.322)))
                    .clipShape(RoundedRectangle(cornerRadius: 14 * scale))

                VStack(alignment: .leading, spacing: 4 * scale) {
                    Text(title)
                        .font(.system(size: 16 * scale, weight: .bold))
                        .foregroundStyle(.white)
                    Text(subtitle)
                        .font(.system(size: 11 * scale, weight: .medium))
                        .foregroundStyle(ZKTheme.textMuted)
                        .lineLimit(2)
                        .fixedSize(horizontal: false, vertical: true)
                }

                Spacer(minLength: 4)
                Image(systemName: "chevron.right")
                    .font(.system(size: 14 * scale, weight: .bold))
                    .foregroundStyle(Color(red: 0.68, green: 0.46, blue: 0.73))
            }
            .padding(.horizontal, 14 * scale)
            .padding(.vertical, 12 * scale)
            .background(
                LinearGradient(
                    colors: [Color(red: 0.055, green: 0.039, blue: 0.071), Color(red: 0.031, green: 0.024, blue: 0.043)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .overlay(RoundedRectangle(cornerRadius: 20 * scale).stroke(primary ? ZKTheme.borderStrong : ZKTheme.border, lineWidth: 1))
            .clipShape(RoundedRectangle(cornerRadius: 20 * scale))
        }
        .buttonStyle(ZKPressStyle())
    }
}

struct BottomNav: View {
    @EnvironmentObject private var state: AppState
    @Environment(\.zkScale) private var scale
    @AppStorage("zk.settings.reduceMotion") private var reduceMotion = false
    @AppStorage("zk.settings.haptics") private var haptics = true

    var body: some View {
        HStack(alignment: .bottom, spacing: 1 * scale) {
            ForEach(ZKPage.allCases) { item in
                Button {
                    if haptics { UISelectionFeedbackGenerator().selectionChanged() }
                    state.go(item)
                } label: {
                    if item == .signal {
                        signalItem(selected: state.page == item)
                    } else {
                        standardItem(item, selected: state.page == item)
                    }
                }
                .buttonStyle(ZKPressStyle())
                .accessibilityLabel(item.title)
            }
        }
        .padding(.horizontal, 5 * scale)
        .padding(.top, 5 * scale)
        .padding(.bottom, 2 * scale)
        .background(.ultraThinMaterial.opacity(0.92))
        .background(ZKTheme.navBackground.opacity(0.97))
        .overlay(alignment: .top) {
            Rectangle().fill(ZKTheme.border.opacity(0.65)).frame(height: 1)
        }
    }

    private func standardItem(_ item: ZKPage, selected: Bool) -> some View {
        VStack(spacing: 3 * scale) {
            Image(systemName: item.systemImage)
                .font(.system(size: 14 * scale, weight: .semibold))
            Text(item.title)
                .font(.system(size: 7.3 * scale, weight: .bold, design: .rounded))
                .lineLimit(1)
                .minimumScaleFactor(0.72)
        }
        .foregroundStyle(selected ? Color(red: 0.84, green: 0.48, blue: 0.91) : Color(red: 0.53, green: 0.49, blue: 0.56))
        .frame(maxWidth: .infinity, minHeight: 54 * scale)
        .background(selected ? ZKTheme.purple.opacity(0.08) : .clear)
        .clipShape(RoundedRectangle(cornerRadius: 12 * scale))
    }

    private func signalItem(selected: Bool) -> some View {
        VStack(spacing: 1 * scale) {
            AnimatedSignalNavIcon(selected: selected, reduceMotion: reduceMotion)
                .offset(y: -8 * scale)
                .padding(.bottom, -7 * scale)
            Text("Signal")
                .font(.system(size: 7.5 * scale, weight: .black, design: .rounded))
                .foregroundStyle(selected ? .white : Color(red: 0.72, green: 0.57, blue: 0.76))
        }
        .frame(maxWidth: .infinity, minHeight: 58 * scale)
    }
}

struct AnimatedSignalNavIcon: View {
    @Environment(\.zkScale) private var scale
    let selected: Bool
    let reduceMotion: Bool
    @State private var pulse = false
    @State private var rotate = false

    var body: some View {
        ZStack {
            Circle()
                .stroke(ZKTheme.purple.opacity(selected ? 0.42 : 0.22), lineWidth: 1)
                .frame(width: 43 * scale, height: 43 * scale)
                .scaleEffect(reduceMotion ? 1 : (pulse ? 1.18 : 0.92))
                .opacity(reduceMotion ? 0.45 : (pulse ? 0.05 : 0.6))

            Circle()
                .fill(
                    LinearGradient(
                        colors: [Color(red: 0.24, green: 0.08, blue: 0.33), Color(red: 0.10, green: 0.05, blue: 0.14)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .frame(width: 39 * scale, height: 39 * scale)
                .overlay(Circle().stroke(ZKTheme.borderStrong, lineWidth: 1.2))
                .shadow(color: ZKTheme.purple.opacity(selected ? 0.38 : 0.18), radius: 10 * scale)

            RoundedRectangle(cornerRadius: 3 * scale)
                .stroke(selected ? ZKTheme.gold : Color(red: 0.84, green: 0.48, blue: 0.91), lineWidth: 1.7 * scale)
                .frame(width: 15 * scale, height: 15 * scale)
                .rotationEffect(.degrees(45.0 + (reduceMotion ? 0.0 : (rotate ? 360.0 : 0.0))))

            Circle()
                .fill(selected ? ZKTheme.gold : Color(red: 0.84, green: 0.48, blue: 0.91))
                .frame(width: 5 * scale, height: 5 * scale)
                .shadow(color: selected ? ZKTheme.gold : ZKTheme.purple, radius: 5 * scale)
        }
        .frame(width: 46 * scale, height: 46 * scale)
        .onAppear {
            guard !reduceMotion else { return }
            withAnimation(.easeOut(duration: 2.0).repeatForever(autoreverses: false)) { pulse = true }
            withAnimation(.linear(duration: 7.0).repeatForever(autoreverses: false)) { rotate = true }
        }
    }
}

struct MetricCell: View {
    @Environment(\.zkScale) private var scale
    let label: String
    let value: String
    var color: Color = .white

    var body: some View {
        VStack(spacing: 4 * scale) {
            Text(label.uppercased())
                .font(.system(size: 8 * scale, weight: .black, design: .rounded))
                .foregroundStyle(ZKTheme.textMuted)
            Text(value)
                .font(.system(size: 11 * scale, weight: .black, design: .monospaced))
                .foregroundStyle(color)
                .lineLimit(1)
                .minimumScaleFactor(0.75)
        }
        .frame(maxWidth: .infinity)
    }
}

struct ProbabilityCell: View {
    @Environment(\.zkScale) private var scale
    let label: String
    let value: Double
    let color: Color

    var body: some View {
        VStack(spacing: 3 * scale) {
            Text(label)
                .font(.system(size: 8 * scale, weight: .black))
                .foregroundStyle(ZKTheme.textMuted)
            Text("\(Int(value * 100))%")
                .font(.system(size: 13 * scale, weight: .black, design: .monospaced))
                .foregroundStyle(color)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 8 * scale)
        .background(Color.black.opacity(0.22))
        .overlay(RoundedRectangle(cornerRadius: 10 * scale).stroke(ZKTheme.border.opacity(0.85)))
        .clipShape(RoundedRectangle(cornerRadius: 10 * scale))
    }
}

struct SignalOrb: View {
    @Environment(\.zkScale) private var scale
    let color: Color
    @State private var pulse1 = false
    @State private var pulse2 = false

    var body: some View {
        ZStack {
            Circle().stroke(color.opacity(0.50), lineWidth: 1).frame(width: 46 * scale, height: 46 * scale).scaleEffect(pulse1 ? 1.18 : 0.65).opacity(pulse1 ? 0 : 0.55)
            Circle().stroke(color.opacity(0.25), lineWidth: 1).frame(width: 56 * scale, height: 56 * scale).scaleEffect(pulse2 ? 1.18 : 0.65).opacity(pulse2 ? 0 : 0.35)
            Circle().fill(color).frame(width: 18 * scale, height: 18 * scale).shadow(color: color.opacity(0.9), radius: 10)
        }
        .frame(width: 58 * scale, height: 58 * scale)
        .onAppear {
            withAnimation(.easeOut(duration: 2.4).repeatForever(autoreverses: false)) { pulse1 = true }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.15) {
                withAnimation(.easeOut(duration: 2.4).repeatForever(autoreverses: false)) { pulse2 = true }
            }
        }
    }
}

struct ConfidenceRing: View {
    @Environment(\.zkScale) private var scale
    let value: Double
    let color: Color
    let label: String

    var body: some View {
        ZStack {
            Circle().stroke(Color(red: 0.145, green: 0.110, blue: 0.169), lineWidth: 7 * scale)
            Circle()
                .trim(from: 0, to: max(0, min(value, 1)))
                .stroke(color, style: StrokeStyle(lineWidth: 7 * scale, lineCap: .round))
                .rotationEffect(.degrees(-90))
                .shadow(color: color.opacity(0.18), radius: 8)
            VStack(spacing: 1) {
                Text("\(Int(value * 100))%")
                    .font(.system(size: 12 * scale, weight: .black))
                Text(label.uppercased())
                    .font(.system(size: 7 * scale, weight: .black))
                    .foregroundStyle(ZKTheme.textMuted)
            }
        }
        .frame(width: 64 * scale, height: 64 * scale)
    }
}
