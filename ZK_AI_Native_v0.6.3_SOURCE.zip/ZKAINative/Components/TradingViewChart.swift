import SwiftUI
import WebKit

struct TradingViewICMarketsChart: View {
    @Environment(\.zkScale) private var scale
    var compact = false
    var showHeader = true

    @State private var loading = true
    @State private var failed = false

    var body: some View {
        ZStack {
            TradingViewWebContainer(compact: compact, loading: $loading, failed: $failed)
                .background(ZKTheme.background)

            if loading {
                VStack(spacing: 8 * scale) {
                    ProgressView().tint(ZKTheme.purple)
                    Text("Loading IC Markets XAUUSD from TradingView…")
                        .font(.system(size: 9 * scale, weight: .bold))
                        .foregroundStyle(ZKTheme.textMuted)
                }
                .padding(14 * scale)
                .background(ZKTheme.card.opacity(0.92))
                .overlay(RoundedRectangle(cornerRadius: 12 * scale).stroke(ZKTheme.border))
                .clipShape(RoundedRectangle(cornerRadius: 12 * scale))
            }

            if failed {
                VStack(spacing: 7 * scale) {
                    Image(systemName: "wifi.exclamationmark")
                        .font(.system(size: 22 * scale, weight: .semibold))
                        .foregroundStyle(ZKTheme.gold)
                    Text("TradingView chart unavailable")
                        .font(.system(size: 11 * scale, weight: .bold))
                    Text("The ZK native chart remains available as a fallback.")
                        .font(.system(size: 8 * scale, weight: .medium))
                        .foregroundStyle(ZKTheme.textMuted)
                }
                .padding(16 * scale)
                .background(ZKTheme.card.opacity(0.96))
                .overlay(RoundedRectangle(cornerRadius: 14 * scale).stroke(ZKTheme.border))
                .clipShape(RoundedRectangle(cornerRadius: 14 * scale))
            }

            if showHeader && !compact {
                VStack {
                    HStack(spacing: 6 * scale) {
                        Circle()
                            .fill(ZKTheme.green)
                            .frame(width: 6 * scale, height: 6 * scale)
                            .shadow(color: ZKTheme.green, radius: 4)
                        Text("ICMARKETS:XAUUSD • TRADINGVIEW")
                            .font(.system(size: 7.5 * scale, weight: .black, design: .rounded))
                            .tracking(0.4)
                            .foregroundStyle(.white.opacity(0.82))
                        Spacer()
                    }
                    .padding(.horizontal, 10 * scale)
                    .padding(.top, 8 * scale)
                    Spacer()
                }
                .allowsHitTesting(false)
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 16 * scale))
    }
}

private struct TradingViewWebContainer: UIViewRepresentable {
    let compact: Bool
    @Binding var loading: Bool
    @Binding var failed: Bool

    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        config.defaultWebpagePreferences.allowsContentJavaScript = true

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = UIColor(red: 0.012, green: 0.012, blue: 0.024, alpha: 1)
        webView.scrollView.backgroundColor = .clear
        webView.scrollView.bounces = false
        webView.scrollView.alwaysBounceVertical = false
        webView.scrollView.alwaysBounceHorizontal = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.allowsBackForwardNavigationGestures = false
        webView.allowsLinkPreview = false

        loadChart(into: webView)
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        // TradingView owns the interactive chart after initial load. Avoiding reloads keeps pan/zoom state smooth.
    }

    private func loadChart(into webView: WKWebView) {
        let hideTop = compact ? "true" : "false"
        let hideLegend = compact ? "true" : "false"

        let html = """
        <!doctype html>
        <html>
        <head>
          <meta name=\"viewport\" content=\"width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no\">
          <style>
            html, body { margin:0; padding:0; width:100%; height:100%; overflow:hidden; background:#030306; }
            .tradingview-widget-container, .tradingview-widget-container__widget { width:100%; height:100%; }
            a { display:none !important; }
          </style>
        </head>
        <body>
          <div class=\"tradingview-widget-container\">
            <div class=\"tradingview-widget-container__widget\"></div>
            <script type=\"text/javascript\" src=\"https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js\" async>
            {
              \"autosize\": true,
              \"symbol\": \"ICMARKETS:XAUUSD\",
              \"interval\": \"1\",
              \"timezone\": \"Etc/UTC\",
              \"theme\": \"dark\",
              \"style\": \"1\",
              \"locale\": \"en\",
              \"backgroundColor\": \"rgba(3, 3, 6, 1)\",
              \"gridColor\": \"rgba(48, 35, 55, 0.28)\",
              \"hide_top_toolbar\": \(hideTop),
              \"hide_legend\": \(hideLegend),
              \"allow_symbol_change\": false,
              \"save_image\": false,
              \"calendar\": false,
              \"support_host\": \"https://www.tradingview.com\"
            }
            </script>
          </div>
        </body>
        </html>
        """

        webView.loadHTMLString(html, baseURL: URL(string: "https://www.tradingview.com"))
    }

    final class Coordinator: NSObject, WKNavigationDelegate {
        var parent: TradingViewWebContainer

        init(parent: TradingViewWebContainer) {
            self.parent = parent
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                self.parent.failed = false
                self.parent.loading = false
            }
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            DispatchQueue.main.async {
                self.parent.loading = false
                self.parent.failed = true
            }
        }

        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            DispatchQueue.main.async {
                self.parent.loading = false
                self.parent.failed = true
            }
        }
    }
}
