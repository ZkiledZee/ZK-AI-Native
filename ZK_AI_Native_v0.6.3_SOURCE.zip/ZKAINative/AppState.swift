import SwiftUI
import Foundation

@MainActor
final class AppState: ObservableObject {
    @Published var page: ZKPage = .home
    @Published var signal: SignalSnapshot = .dataOnly
    @Published var models: [ModelRecord] = ModelRecord.seed
    @Published var selectedModelID: UUID?
    @Published var drawings: [ChartDrawing] = []
    @Published var journal: [TradeJournalEntry] = []
    @Published var macroCoverage: Double = 0
    @Published var macroRegime: String = "NO MACRO DATA"
    @Published var agentLoaded = false
    @Published var chartMode: Int = UserDefaults.standard.integer(forKey: "zk.settings.chartMode")
    @Published var notificationPermission = false
    @Published var chatMessages: [ChatMessage] = [
        .init(
            role: .assistant,
            text: "ZK Local AI can be downloaded from this app. Once installed, it runs locally and receives fresh market, chart, settings, signal, model, drawing, journal and backtest context for every question."
        )
    ]

    private(set) var installID: String = ""
    private(set) var launchCount: Int = 0

    init() {
        let defaults = UserDefaults.standard
        let existing = defaults.string(forKey: "zk.installID")
        let id = existing ?? UUID().uuidString
        if existing == nil { defaults.set(id, forKey: "zk.installID") }

        let nextCount = defaults.integer(forKey: "zk.launchCount") + 1
        defaults.set(nextCount, forKey: "zk.launchCount")

        installID = id
        launchCount = nextCount
        selectedModelID = models.first?.id
        loadDrawings()
    }

    var selectedModel: ModelRecord? {
        models.first(where: { $0.id == selectedModelID })
    }

    func go(_ destination: ZKPage) {
        if destination == .chart {
            chartMode = UserDefaults.standard.integer(forKey: "zk.settings.chartMode")
        }
        withAnimation(.easeOut(duration: 0.18)) {
            page = destination
        }
    }

    func replaceSupportResistance(around passedPrice: Double? = nil) {
        guard let price = referencePrice(passedPrice) else { return }
        let distance = max(price * 0.0012, 4.0)
        drawings.removeAll { $0.kind == .support || $0.kind == .resistance }
        drawings.append(.init(kind: .support, price: price - distance, label: "SUPPORT"))
        drawings.append(.init(kind: .resistance, price: price + distance, label: "RESISTANCE"))
        persistDrawings()
    }

    func addZone(around passedPrice: Double? = nil) {
        guard let price = referencePrice(passedPrice) else { return }
        let half = max(price * 0.00035, 1.25)
        drawings.removeAll { $0.kind == .zone }
        drawings.append(.init(kind: .zone, price: price - half, secondaryPrice: price + half, label: "MARKET ZONE"))
        persistDrawings()
    }

    func removeLastDrawing() {
        guard !drawings.isEmpty else { return }
        drawings.removeLast()
        persistDrawings()
    }

    func clearAllDrawings() {
        drawings.removeAll()
        persistDrawings()
    }

    func removeSupport() {
        drawings.removeAll { $0.kind == .support }
        persistDrawings()
    }

    func removeResistance() {
        drawings.removeAll { $0.kind == .resistance }
        persistDrawings()
    }

    private func referencePrice(_ passedPrice: Double?) -> Double? {
        if let passedPrice, passedPrice > 0 { return passedPrice }
        let saved = UserDefaults.standard.double(forKey: "zk.lastMarketPrice")
        return saved > 0 ? saved : nil
    }

    private func persistDrawings() {
        if let data = try? JSONEncoder().encode(drawings) {
            UserDefaults.standard.set(data, forKey: "zk.drawings")
        }
    }

    private func loadDrawings() {
        guard
            let data = UserDefaults.standard.data(forKey: "zk.drawings"),
            let decoded = try? JSONDecoder().decode([ChartDrawing].self, from: data)
        else { return }
        drawings = decoded.filter { !$0.label.uppercased().contains("DEMO") }
    }

    func appendUserMessage(_ text: String) {
        chatMessages.append(.init(role: .user, text: text))
    }

    @discardableResult
    func appendAssistantMessage(_ text: String = "") -> UUID {
        let message = ChatMessage(role: .assistant, text: text)
        chatMessages.append(message)
        return message.id
    }

    func appendToAssistantMessage(id: UUID, token: String) {
        guard let index = chatMessages.firstIndex(where: { $0.id == id }) else { return }
        chatMessages[index].text += token
    }

    func replaceAssistantMessage(id: UUID, text: String) {
        guard let index = chatMessages.firstIndex(where: { $0.id == id }) else { return }
        chatMessages[index].text = text
    }

    func clearChat() {
        chatMessages = [
            .init(
                role: .assistant,
                text: "ZK Local AI is ready to use once its downloadable model is installed. I receive fresh app and market context with every question."
            )
        ]
    }

}
