import SwiftUI

@main
struct ZKAINativeApp: App {
    @StateObject private var state = AppState()
    @StateObject private var market = MarketDataService()
    @StateObject private var ai = LocalAIService()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(state)
                .environmentObject(market)
                .environmentObject(ai)
                .preferredColorScheme(.dark)
                .task {
                    market.start()
                }
        }
    }
}
