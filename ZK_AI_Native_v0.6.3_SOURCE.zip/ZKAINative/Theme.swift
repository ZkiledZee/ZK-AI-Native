import SwiftUI

private struct ZKScaleKey: EnvironmentKey {
    static let defaultValue: CGFloat = 1.0
}

extension EnvironmentValues {
    var zkScale: CGFloat {
        get { self[ZKScaleKey.self] }
        set { self[ZKScaleKey.self] = newValue }
    }
}

enum ZKTheme {
    static let background = Color(red: 0.012, green: 0.012, blue: 0.024)
    static let navBackground = Color(red: 0.027, green: 0.020, blue: 0.039)
    static let card = Color(red: 0.043, green: 0.031, blue: 0.063)
    static let card2 = Color(red: 0.059, green: 0.039, blue: 0.075)
    static let border = Color(red: 0.235, green: 0.169, blue: 0.267)
    static let borderStrong = Color(red: 0.404, green: 0.251, blue: 0.459)
    static let purple = Color(red: 0.710, green: 0.361, blue: 1.000)
    static let pink = Color(red: 1.000, green: 0.247, blue: 0.784)
    static let green = Color(red: 0.090, green: 0.851, blue: 0.576)
    static let red = Color(red: 1.000, green: 0.388, blue: 0.451)
    static let gold = Color(red: 0.945, green: 0.722, blue: 0.243)
    static let blue = Color(red: 0.357, green: 0.655, blue: 1.000)
    static let textMuted = Color(red: 0.58, green: 0.53, blue: 0.61)
    static let textSoft = Color(red: 0.70, green: 0.65, blue: 0.73)
    static let goldLogo = Color(red: 0.965, green: 0.741, blue: 0.222)

    static let accentGradient = LinearGradient(
        colors: [Color(red: 0.45, green: 0.14, blue: 0.56), Color(red: 0.68, green: 0.20, blue: 0.59)],
        startPoint: .leading,
        endPoint: .trailing
    )

    static func scale(for width: CGFloat) -> CGFloat {
        min(max(width / 390.0, 0.92), 1.08)
    }
}

struct ZKMicroLabel: View {
    @Environment(\.zkScale) private var scale
    let text: String

    var body: some View {
        Text(text.uppercased())
            .font(.system(size: 9.5 * scale, weight: .black, design: .rounded))
            .tracking(1.35 * scale)
            .foregroundStyle(ZKTheme.textSoft)
    }
}

struct ZKCard<Content: View>: View {
    @Environment(\.zkScale) private var scale
    var strongBorder = false
    @ViewBuilder var content: Content

    var body: some View {
        content
            .padding(12 * scale)
            .background(
                LinearGradient(
                    colors: [ZKTheme.card2.opacity(0.97), ZKTheme.card.opacity(0.97)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .overlay(
                RoundedRectangle(cornerRadius: 16 * scale, style: .continuous)
                    .stroke(strongBorder ? ZKTheme.borderStrong : ZKTheme.border, lineWidth: 1)
            )
            .clipShape(RoundedRectangle(cornerRadius: 16 * scale, style: .continuous))
    }
}

struct ZKDataPill: View {
    @Environment(\.zkScale) private var scale
    let text: String
    let color: Color

    var body: some View {
        HStack(spacing: 6 * scale) {
            Circle()
                .fill(color)
                .frame(width: 7 * scale, height: 7 * scale)
                .shadow(color: color.opacity(0.9), radius: 5)
            Text(text.uppercased())
                .font(.system(size: 8 * scale, weight: .black, design: .rounded))
                .tracking(0.65 * scale)
                .foregroundStyle(ZKTheme.textSoft)
        }
        .padding(.horizontal, 9 * scale)
        .padding(.vertical, 7 * scale)
        .background(ZKTheme.card)
        .overlay(Capsule().stroke(ZKTheme.borderStrong.opacity(0.8)))
        .clipShape(Capsule())
    }
}

struct ZKPageHeader: View {
    @Environment(\.zkScale) private var scale
    let micro: String
    let title: String
    let pill: String
    let pillColor: Color

    var body: some View {
        HStack(alignment: .bottom, spacing: 10 * scale) {
            VStack(alignment: .leading, spacing: 4 * scale) {
                ZKMicroLabel(text: micro)
                Text(title)
                    .font(.system(size: 24 * scale, weight: .black, design: .rounded))
                    .tracking(-0.7 * scale)
                    .lineLimit(1)
                    .minimumScaleFactor(0.82)
            }
            Spacer(minLength: 4)
            ZKDataPill(text: pill, color: pillColor)
        }
    }
}

struct ZKPressStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.985 : 1)
            .opacity(configuration.isPressed ? 0.90 : 1)
            .animation(.easeOut(duration: 0.10), value: configuration.isPressed)
    }
}
