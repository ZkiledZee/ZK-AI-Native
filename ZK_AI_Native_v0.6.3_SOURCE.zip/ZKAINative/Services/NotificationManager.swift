import Foundation
import UserNotifications

@MainActor
final class NotificationManager: ObservableObject {
    static let shared = NotificationManager()
    @Published private(set) var status = "NOT REQUESTED"

    private init() {}

    func refresh() async -> Bool {
        let settings = await UNUserNotificationCenter.current().notificationSettings()
        switch settings.authorizationStatus {
        case .authorized, .provisional, .ephemeral:
            status = "ENABLED"
            return true
        case .denied:
            status = "DENIED"
            return false
        case .notDetermined:
            status = "NOT REQUESTED"
            return false
        @unknown default:
            status = "UNKNOWN"
            return false
        }
    }

    func request() async -> Bool {
        do {
            let granted = try await UNUserNotificationCenter.current()
                .requestAuthorization(options: [.alert, .sound, .badge])
            _ = await refresh()
            return granted
        } catch {
            status = "ERROR"
            return false
        }
    }

    func sendDemo() async {
        let content = UNMutableNotificationContent()
        content.title = "ZK AI — NATIVE TEST"
        content.body = "Native notifications are working. Live trading signals are not enabled in this build."
        content.sound = .default

        let request = UNNotificationRequest(
            identifier: "zk.native.test.\(UUID().uuidString)",
            content: content,
            trigger: UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        )
        try? await UNUserNotificationCenter.current().add(request)
    }
}
