import Foundation
import SwiftUI

#if canImport(SwiftLlama)
import SwiftLlama
#endif

@MainActor
final class LocalAIService: ObservableObject {
    enum RuntimeState: Equatable {
        case notDownloaded
        case downloading
        case verifying
        case downloaded
        case loading
        case ready
        case generating
        case failed(String)
    }

    static let modelName = "Qwen2.5 0.5B • Q4_K_M"
    static let modelFile = "qwen2.5-0.5b-instruct-q4_k_m.gguf"
    static let modelBytes: Int64 = 491_000_000
    static let modelSHA256 = "74a4da8c9fdbcd15bd1f6d01d621410d31c6fc00986f5eb687824e7b93d7a9db"

    @Published private(set) var state: RuntimeState = .notDownloaded
    @Published private(set) var downloadProgress: Double = 0
    @Published private(set) var bytesDownloaded: Int64 = 0
    @Published private(set) var totalBytes: Int64 = modelBytes
    @Published private(set) var lastError: String?
    @Published private(set) var lastPromptCharacters: Int = 0

    static let safePromptCharacterBudget = 4_500

    #if canImport(SwiftLlama)
    private var loadedModel: LlamaModel?
    private let downloader = ModelDownloader()
    #endif
    private var downloadTask: Task<Void, Never>?

    init() {
        refreshInstalledState()
    }

    var isInstalled: Bool {
        FileManager.default.fileExists(atPath: modelURL.path)
    }

    var isReady: Bool {
        if case .ready = state { return true }
        return false
    }

    var isBusy: Bool {
        switch state {
        case .downloading, .verifying, .loading, .generating: return true
        default: return false
        }
    }

    var shortStatus: String {
        switch state {
        case .notDownloaded: return "DOWNLOAD"
        case .downloading: return "\(Int(downloadProgress * 100))%"
        case .verifying: return "VERIFY"
        case .downloaded: return "LOCAL"
        case .loading: return "LOADING"
        case .ready: return "READY"
        case .generating: return "THINKING"
        case .failed: return "ERROR"
        }
    }

    var statusDetail: String {
        switch state {
        case .notDownloaded:
            return "Download the ~491 MB local chat model once. After that, chat inference runs on the iPhone."
        case .downloading:
            return "Downloading \(Self.formatBytes(bytesDownloaded)) of \(Self.formatBytes(totalBytes))"
        case .verifying:
            return "Verifying the model checksum before it can run."
        case .downloaded:
            return "Model is stored locally and ready to load."
        case .loading:
            return "Loading the local model into memory."
        case .ready:
            return "Local model loaded. App context is injected fresh for every question."
        case .generating:
            return "ZK AI is generating locally on this iPhone."
        case .failed(let message):
            return message
        }
    }

    var modelURL: URL {
        let base = try? FileManager.default.url(
            for: .applicationSupportDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        )
        let dir = (base ?? FileManager.default.temporaryDirectory)
            .appendingPathComponent("ZKAI", isDirectory: true)
            .appendingPathComponent("Models", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent(Self.modelFile)
    }

    func refreshInstalledState() {
        if isInstalled {
            if !isReady && !isBusy { state = .downloaded }
            if let attrs = try? FileManager.default.attributesOfItem(atPath: modelURL.path),
               let size = attrs[.size] as? NSNumber {
                bytesDownloaded = size.int64Value
                totalBytes = max(Self.modelBytes, size.int64Value)
                downloadProgress = 1
            }
        } else if !isBusy {
            state = .notDownloaded
            downloadProgress = 0
            bytesDownloaded = 0
        }
    }

    func downloadModel() {
        guard downloadTask == nil else { return }
        lastError = nil
        state = .downloading

        #if canImport(SwiftLlama)
        downloadTask = Task { [weak self] in
            guard let self else { return }
            let source = ModelSource.huggingFace(
                repo: "Qwen/Qwen2.5-0.5B-Instruct-GGUF",
                file: Self.modelFile
            )

            let stream = await downloader.download(
                from: source,
                to: modelURL,
                expectedSHA256: Self.modelSHA256
            )

            for await event in stream {
                if Task.isCancelled { break }
                switch event {
                case .progress(let percent, let downloaded, let total):
                    self.bytesDownloaded = downloaded
                    self.totalBytes = total > 0 ? total : Self.modelBytes
                    self.downloadProgress = min(max(percent / 100.0, 0), 1)
                    self.state = .downloading
                case .verifying:
                    self.state = .verifying
                case .completed:
                    self.downloadProgress = 1
                    self.bytesDownloaded = self.totalBytes
                    self.state = .downloaded
                    self.downloadTask = nil
                    await self.loadModel()
                case .failed(let error):
                    let text = error.localizedDescription
                    self.lastError = text
                    self.state = .failed(text)
                    self.downloadTask = nil
                }
            }
            if self.downloadTask != nil { self.downloadTask = nil }
        }
        #else
        state = .failed("The local inference runtime is not linked in this build.")
        #endif
    }

    func cancelDownload() {
        downloadTask?.cancel()
        downloadTask = nil
        refreshInstalledState()
    }

    func loadModel() async {
        guard isInstalled else {
            state = .notDownloaded
            return
        }
        #if canImport(SwiftLlama)
        if loadedModel != nil {
            state = .ready
            return
        }
        state = .loading
        lastError = nil
        let path = modelURL.path
        do {
            let model = try await Task.detached(priority: .userInitiated) {
                try LlamaModel(
                    path: path,
                    config: ModelConfig(
                        contextSize: 2048,
                        // v0.6.2 vendors a patched SwiftLlama prefill path that feeds the
                        // prompt in small chunks. This keeps transient llama.cpp memory low
                        // instead of allocating a 4096-token inference batch on a 4 GB iPhone.
                        batchSize: 192,
                        gpuLayers: .none,
                        threads: 4
                    )
                )
            }.value
            loadedModel = model
            state = .ready
        } catch {
            loadedModel = nil
            lastError = error.localizedDescription
            state = .failed("Model load failed: \(error.localizedDescription)")
        }
        #else
        state = .failed("The local inference runtime is not linked in this build.")
        #endif
    }

    func unloadModel() {
        #if canImport(SwiftLlama)
        loadedModel = nil
        #endif
        refreshInstalledState()
    }

    func deleteModel() {
        downloadTask?.cancel()
        downloadTask = nil
        #if canImport(SwiftLlama)
        loadedModel = nil
        #endif
        try? FileManager.default.removeItem(at: modelURL)
        state = .notDownloaded
        downloadProgress = 0
        bytesDownloaded = 0
        lastError = nil
    }

    func generate(
        appContext: String,
        conversation: [ChatMessage],
        onToken: @escaping @MainActor (String) -> Void
    ) async throws {
        guard isInstalled else { throw LocalAIError.modelNotDownloaded }
        #if canImport(SwiftLlama)
        if loadedModel == nil { await loadModel() }
        guard let loadedModel else { throw LocalAIError.modelNotLoaded }

        state = .generating
        defer {
            if isInstalled { state = .ready } else { state = .notDownloaded }
        }

        let actor = try LlamaActor(
            model: loadedModel,
            params: SamplingParams(
                temperature: 0.28,
                topP: 0.88,
                topK: 35,
                repeatPenalty: 1.12,
                maxTokens: 192
            )
        )

        let prompt = buildPrompt(appContext: appContext, conversation: conversation)
        lastPromptCharacters = prompt.count
        let stream = await actor.generate(
            prompt: prompt,
            params: SamplingParams(
                temperature: 0.28,
                topP: 0.88,
                topK: 35,
                repeatPenalty: 1.12,
                maxTokens: 192
            )
        )

        for try await token in stream {
            await onToken(token)
        }
        #else
        throw LocalAIError.runtimeUnavailable
        #endif
    }

    private func buildPrompt(appContext: String, conversation: [ChatMessage]) -> String {
        // Keep the prompt compact for a 2048-token context. The patched local runtime
        // tokenizes first, rejects overlong prompts safely, and prefills in 192-token chunks.
        let compactContext = clipped(appContext, maxCharacters: 2_800)

        let system = """
        You are ZK AI, the local assistant inside an XAUUSD trading-analysis iPhone app.
        Use only APP CONTEXT for live prices, candles, settings, signals, model state, drawings, journal and backtest state.
        Never invent live values, model probabilities, broker quotes, results or macro facts.
        TradingView is visible to the user but its protected internal candle data is not readable by you.
        If the trading model is disabled/untrained, analyse the supplied structure and indicators but do not fabricate a BUY/SELL signal.
        If a deterministic app tool was executed, acknowledge exactly what happened.
        Be practical and concise.

        APP CONTEXT
        \(compactContext)
        END APP CONTEXT
        """

        var parts: [String] = []
        parts.append("<|im_start|>system\n\(system)\n<|im_end|>")

        // Three recent turns keep continuity while leaving headroom for the reply.
        let recent = conversation.suffix(3)
        for message in recent {
            let role = message.role == .user ? "user" : "assistant"
            let cleaned = message.text.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !cleaned.isEmpty else { continue }
            let compact = clipped(cleaned, maxCharacters: 420)
            parts.append("<|im_start|>\(role)\n\(compact)\n<|im_end|>")
        }
        parts.append("<|im_start|>assistant\n")

        let prompt = parts.joined(separator: "\n")
        return clipped(prompt, maxCharacters: Self.safePromptCharacterBudget, keepTail: true)
    }

    private func clipped(_ text: String, maxCharacters: Int, keepTail: Bool = false) -> String {
        guard text.count > maxCharacters else { return text }
        if keepTail {
            let start = text.index(text.endIndex, offsetBy: -maxCharacters)
            return String(text[start...])
        }
        let end = text.index(text.startIndex, offsetBy: maxCharacters)
        return String(text[..<end]) + "\n[context trimmed for local inference safety]"
    }

    private static func formatBytes(_ value: Int64) -> String {
        let formatter = ByteCountFormatter()
        formatter.allowedUnits = [.useMB, .useGB]
        formatter.countStyle = .file
        return formatter.string(fromByteCount: value)
    }
}

enum LocalAIError: LocalizedError {
    case modelNotDownloaded
    case modelNotLoaded
    case runtimeUnavailable

    var errorDescription: String? {
        switch self {
        case .modelNotDownloaded: return "Download the local AI model first."
        case .modelNotLoaded: return "The local AI model could not be loaded."
        case .runtimeUnavailable: return "The local inference runtime is unavailable in this build."
        }
    }
}
