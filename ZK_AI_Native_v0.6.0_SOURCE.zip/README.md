# ZK AI Native v0.6.0 — Local AI Foundation

This build adds the first real on-device conversational AI layer while keeping the numerical trading-model layer disabled until it is trained and validated.

## Local chat AI

- Adds a one-tap model download inside **ZK AI Chat** and **Settings**.
- Model: **Qwen2.5-0.5B-Instruct Q4_K_M GGUF**, about 491 MB.
- The model is not bundled in the IPA; it downloads to Application Support on the iPhone and stays local afterwards.
- SHA-256 is verified before the model is loaded.
- On-device inference uses llama.cpp through the SwiftLlama package / Metal-enabled XCFramework.
- The model is loaded with a 4096-token context, GPU layers enabled, and conservative sampling for grounded analysis.
- Chat streams text token-by-token into the existing ZK chat UI.

## What the local AI can see

Fresh context is rebuilt for every question. It includes:

- current app screen
- native market feed status/freshness/current XAUUSD price
- loaded M1 candle count and latest 24 native OHLC candles
- session open/high/low/range
- calculated EMA20, EMA50, RSI14, ATR14, 5-candle momentum
- basic HH/HL/LH/LL swing-structure classification
- current Signal page state and probabilities
- Market AI model-vault slot/evidence state
- macro coverage/regime state
- chart drawings/zones/support/resistance
- trade journal count
- chart/data/settings state
- last Backtest data-integrity result
- feed errors when present

The IC Markets TradingView iframe remains a visual reference. Cross-origin TradingView internals are not exposed to native Swift or the local AI. The assistant is explicitly instructed not to pretend it can read those protected candles.

## Deterministic app tools from chat

Before the LLM answers, the app can safely execute a small set of deterministic commands when explicitly requested:

- mark/replace support and resistance around the latest native price
- add a market zone
- remove support or resistance
- clear drawings
- refresh market data
- open Chart / Signal / Backtest / Settings

The executed tool result is injected into the model context so the assistant can accurately acknowledge what happened.

## Important separation

The downloadable local LLM is the **conversation/explanation layer**. It does not become the authority for BUY/SELL decisions. The future numerical Market AI remains separate and is still untrained in v0.6.0. This build can analyse the available market features conversationally but must not fabricate trained-model signals or performance.

## Existing v0.5 features retained

- `ICMARKETS:XAUUSD` 1M TradingView visual mode
- ZK native chart with smooth pan/zoom and drawings
- centred animated Signal tab
- Backtest tab
- Settings tab
- forced ZK app icon asset fix
- same bundle ID: `com.zk.goldai.native`

## Build

Upload this archive as:

`ZK_AI_Native_v0.6.0_SOURCE.zip`

The existing GitHub workflow should detect `0.6.0`, resolve the pinned SwiftLlama dependency, build the iPhone app, and publish `ZK-AI-v0.6.0.ipa`.
