import Foundation
import SwiftUI

#if canImport(SwiftLlama)
import SwiftLlama
#endif

@MainActor
final class LocalAIService: ObservableObject {
    enum RuntimeState: Equatable {
        case notDownloaded
        case downloading
        case verifying
        case downloaded
        case loading
        case ready
        case generating
        case failed(String)
    }

    static let modelName = "Qwen2.5 0.5B • Q4_K_M"
    static let modelFile = "qwen2.5-0.5b-instruct-q4_k_m.gguf"
    static let modelBytes: Int64 = 491_000_000
    static let modelSHA256 = "74a4da8c9fdbcd15bd1f6d01d621410d31c6fc00986f5eb687824e7b93d7a9db"

    @Published private(set) var state: RuntimeState = .notDownloaded
    @Published private(set) var downloadProgress: Double = 0
    @Published private(set) var bytesDownloaded: Int64 = 0
    @Published private(set) var totalBytes: Int64 = modelBytes
    @Published private(set) var lastError: String?

    #if canImport(SwiftLlama)
    private var loadedModel: LlamaModel?
    private let downloader = ModelDownloader()
    #endif
    private var downloadTask: Task<Void, Never>?

    init() {
        refreshInstalledState()
    }

    var isInstalled: Bool {
        FileManager.default.fileExists(atPath: modelURL.path)
    }

    var isReady: Bool {
        if case .ready = state { return true }
        return false
    }

    var isBusy: Bool {
        switch state {
        case .downloading, .verifying, .loading, .generating: return true
        default: return false
        }
    }

    var shortStatus: String {
        switch state {
        case .notDownloaded: return "DOWNLOAD"
        case .downloading: return "\(Int(downloadProgress * 100))%"
        case .verifying: return "VERIFY"
        case .downloaded: return "LOCAL"
        case .loading: return "LOADING"
        case .ready: return "READY"
        case .generating: return "THINKING"
        case .failed: return "ERROR"
        }
    }

    var statusDetail: String {
        switch state {
        case .notDownloaded:
            return "Download the ~491 MB local chat model once. After that, chat inference runs on the iPhone."
        case .downloading:
            return "Downloading \(Self.formatBytes(bytesDownloaded)) of \(Self.formatBytes(totalBytes))"
        case .verifying:
            return "Verifying the model checksum before it can run."
        case .downloaded:
            return "Model is stored locally and ready to load."
        case .loading:
            return "Loading the local model into memory."
        case .ready:
            return "Local model loaded. App context is injected fresh for every question."
        case .generating:
            return "ZK AI is generating locally on this iPhone."
        case .failed(let message):
            return message
        }
    }

    var modelURL: URL {
        let base = try? FileManager.default.url(
            for: .applicationSupportDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        )
        let dir = (base ?? FileManager.default.temporaryDirectory)
            .appendingPathComponent("ZKAI", isDirectory: true)
            .appendingPathComponent("Models", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent(Self.modelFile)
    }

    func refreshInstalledState() {
        if isInstalled {
            if !isReady && !isBusy { state = .downloaded }
            if let attrs = try? FileManager.default.attributesOfItem(atPath: modelURL.path),
               let size = attrs[.size] as? NSNumber {
                bytesDownloaded = size.int64Value
                totalBytes = max(Self.modelBytes, size.int64Value)
                downloadProgress = 1
            }
        } else if !isBusy {
            state = .notDownloaded
            downloadProgress = 0
            bytesDownloaded = 0
        }
    }

    func downloadModel() {
        guard downloadTask == nil else { return }
        lastError = nil
        state = .downloading

        #if canImport(SwiftLlama)
        downloadTask = Task { [weak self] in
            guard let self else { return }
            let source = ModelSource.huggingFace(
                repo: "Qwen/Qwen2.5-0.5B-Instruct-GGUF",
                file: Self.modelFile
            )

            let stream = await downloader.download(
                from: source,
                to: modelURL,
                expectedSHA256: Self.modelSHA256
            )

            for await event in stream {
                if Task.isCancelled { break }
                switch event {
                case .progress(let percent, let downloaded, let total):
                    self.bytesDownloaded = downloaded
                    self.totalBytes = total > 0 ? total : Self.modelBytes
                    self.downloadProgress = min(max(percent / 100.0, 0), 1)
                    self.state = .downloading
                case .verifying:
                    self.state = .verifying
                case .completed:
                    self.downloadProgress = 1
                    self.bytesDownloaded = self.totalBytes
                    self.state = .downloaded
                    self.downloadTask = nil
                    await self.loadModel()
                case .failed(let error):
                    let text = error.localizedDescription
                    self.lastError = text
                    self.state = .failed(text)
                    self.downloadTask = nil
                }
            }
            if self.downloadTask != nil { self.downloadTask = nil }
        }
        #else
        state = .failed("The local inference runtime is not linked in this build.")
        #endif
    }

    func cancelDownload() {
        downloadTask?.cancel()
        downloadTask = nil
        refreshInstalledState()
    }

    func loadModel() async {
        guard isInstalled else {
            state = .notDownloaded
            return
        }
        #if canImport(SwiftLlama)
        if loadedModel != nil {
            state = .ready
            return
        }
        state = .loading
        lastError = nil
        let path = modelURL.path
        do {
            let model = try await Task.detached(priority: .userInitiated) {
                try LlamaModel(
                    path: path,
                    config: ModelConfig(
                        contextSize: 4096,
                        batchSize: 256,
                        gpuLayers: .all,
                        threads: 4
                    )
                )
            }.value
            loadedModel = model
            state = .ready
        } catch {
            loadedModel = nil
            lastError = error.localizedDescription
            state = .failed("Model load failed: \(error.localizedDescription)")
        }
        #else
        state = .failed("The local inference runtime is not linked in this build.")
        #endif
    }

    func unloadModel() {
        #if canImport(SwiftLlama)
        loadedModel = nil
        #endif
        refreshInstalledState()
    }

    func deleteModel() {
        downloadTask?.cancel()
        downloadTask = nil
        #if canImport(SwiftLlama)
        loadedModel = nil
        #endif
        try? FileManager.default.removeItem(at: modelURL)
        state = .notDownloaded
        downloadProgress = 0
        bytesDownloaded = 0
        lastError = nil
    }

    func generate(
        appContext: String,
        conversation: [ChatMessage],
        onToken: @escaping @MainActor (String) -> Void
    ) async throws {
        guard isInstalled else { throw LocalAIError.modelNotDownloaded }
        #if canImport(SwiftLlama)
        if loadedModel == nil { await loadModel() }
        guard let loadedModel else { throw LocalAIError.modelNotLoaded }

        state = .generating
        defer {
            if isInstalled { state = .ready } else { state = .notDownloaded }
        }

        let actor = try LlamaActor(
            model: loadedModel,
            params: SamplingParams(
                temperature: 0.28,
                topP: 0.88,
                topK: 35,
                repeatPenalty: 1.12,
                maxTokens: 420
            )
        )

        let prompt = buildPrompt(appContext: appContext, conversation: conversation)
        let stream = await actor.generate(
            prompt: prompt,
            params: SamplingParams(
                temperature: 0.28,
                topP: 0.88,
                topK: 35,
                repeatPenalty: 1.12,
                maxTokens: 420
            )
        )

        for try await token in stream {
            await onToken(token)
        }
        #else
        throw LocalAIError.runtimeUnavailable
        #endif
    }

    private func buildPrompt(appContext: String, conversation: [ChatMessage]) -> String {
        let system = """
        You are ZK AI, the local assistant inside a gold/XAUUSD trading-analysis iPhone app.
        You are a concise market-analysis assistant, not an autonomous trade executor.
        Use ONLY the APP CONTEXT supplied below for live prices, candles, chart state, settings, signals, model state, drawings, journal and backtest state.
        Never invent a live price, broker quote, indicator value, signal, performance result or macro fact that is absent from APP CONTEXT.
        The IC Markets TradingView iframe is visible to the user, but its protected internal candle data is not readable by you. Treat the native numeric feed in APP CONTEXT as your machine-readable market data.
        If a trading model is disabled or untrained, do not fabricate BUY/SELL probabilities. You may analyse structure, momentum and risk from the available data and clearly label that as analysis, not a trained model signal.
        If APP CONTEXT says a deterministic app tool was executed, acknowledge the result accurately.
        Keep answers practical and usually under 160 words unless the user asks for detail.

        APP CONTEXT
        \(appContext)
        END APP CONTEXT
        """

        var parts: [String] = []
        parts.append("<|im_start|>system\n\(system)\n<|im_end|>")

        let recent = conversation.suffix(8)
        for message in recent {
            let role = message.role == .user ? "user" : "assistant"
            let cleaned = message.text.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !cleaned.isEmpty else { continue }
            parts.append("<|im_start|>\(role)\n\(cleaned)\n<|im_end|>")
        }
        parts.append("<|im_start|>assistant\n")
        return parts.joined(separator: "\n")
    }

    private static func formatBytes(_ value: Int64) -> String {
        let formatter = ByteCountFormatter()
        formatter.allowedUnits = [.useMB, .useGB]
        formatter.countStyle = .file
        return formatter.string(fromByteCount: value)
    }
}

enum LocalAIError: LocalizedError {
    case modelNotDownloaded
    case modelNotLoaded
    case runtimeUnavailable

    var errorDescription: String? {
        switch self {
        case .modelNotDownloaded: return "Download the local AI model first."
        case .modelNotLoaded: return "The local AI model could not be loaded."
        case .runtimeUnavailable: return "The local inference runtime is unavailable in this build."
        }
    }
}
