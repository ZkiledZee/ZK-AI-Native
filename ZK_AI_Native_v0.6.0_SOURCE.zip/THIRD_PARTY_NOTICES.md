# Third-party notices

## Qwen2.5-0.5B-Instruct-GGUF

The app offers an optional user-initiated download of Qwen/Qwen2.5-0.5B-Instruct-GGUF from Hugging Face. The model repository identifies the model license as Apache-2.0. Model weights are not redistributed inside this source archive or IPA.

## swift-llama / llama.cpp

The project uses the SwiftLlama Swift package as an on-device llama.cpp wrapper. SwiftLlama is MIT licensed. llama.cpp is provided through the package's pinned pre-built Apple XCFramework and remains subject to its upstream license.
