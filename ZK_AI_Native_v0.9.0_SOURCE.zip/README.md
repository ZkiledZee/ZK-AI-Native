# ZK AI Native v0.9.0 — Clean Chat + Signal Engine Alpha

This build cleans the local-agent chat into a minimal ChatGPT-style conversation screen and starts the first forward-running XAUUSD signal engine on the same custom 1-minute candle array used by the chart and ZK Agent.

## Clean local-agent chat
- Minimal top bar with chat history, current local model state and New Chat.
- Assistant replies render as clean edge-to-edge text with a small ZK avatar; user messages use a compact right-aligned bubble.
- Rounded composer with a working `+` tool menu and circular send button.
- Heavy status/model cards and permanent suggestion rows were removed from the conversation surface.
- Agent progress is reduced to one compact working/status line.
- Persistent local conversations from v0.8 remain intact.
- Fast 0.5B and Smart 1.5B model download/selection remain supported.

## ZK Signal Engine Alpha
- Enabled by default after update unless the user pauses it.
- Runs locally on the same machine-readable 1M `ChartCandle` array shown on Signal and read by ZK Agent.
- Uses confluence from EMA8/21, RSI14, ATR14, 1M breakout/impulse, 5M/15M context, BOS/CHOCH, liquidity sweeps and nearby S/R.
- Maintains one paper setup at a time until TP or SL is reached.
- Draws active Entry / SL / TP directly onto the custom Signal chart.
- Persists recent paper setups across app relaunches.
- Can send local iOS alerts when a new qualifying paper setup opens (if notifications are enabled).

### SELECTIVE mode
- Higher confluence threshold.
- ~55 minute cooldown between paper signals.
- Daily cap 4.
- Intended to target a few cleaner qualifying setups on an active day. Trade count is not guaranteed; WAIT is valid when no setup qualifies.

### FAST SCALPER mode
- Lower confluence threshold.
- ~8 minute cooldown.
- Daily cap 14.
- Shorter ATR-based stop/target distances and lower R:R than Selective.
- Intended to surface more short-lived 1M paper opportunities.

## Safety / evidence boundary
The v0.9 Signal Engine is an **alpha heuristic/confluence engine**, not a trained predictive ML model, not a profitability claim and not broker order execution. Signals are explicitly paper signals. The conversational model is not allowed to invent a separate trade; it reads the actual engine state.

The current chart still uses the existing reference feed. Exact candle-for-candle `ICMARKETS:XAUUSD` parity still requires an authorized IC Markets/cTrader or other broker-quality stream.
