import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var state: AppState
    @EnvironmentObject private var market: MarketDataService
    @EnvironmentObject private var ai: LocalAIService
    @EnvironmentObject private var signalEngine: SignalEngine
    @Environment(\.zkScale) private var scale

    @AppStorage("zk.settings.chartMode") private var chartMode = 0
    @AppStorage("zk.settings.chartGrid") private var chartGrid = true
    @AppStorage("zk.settings.priceLine") private var priceLine = true
    @AppStorage("zk.settings.chartMomentum") private var chartMomentum = true
    @AppStorage("zk.settings.haptics") private var haptics = true
    @AppStorage("zk.settings.reduceMotion") private var reduceMotion = false
    @AppStorage("zk.settings.refreshSeconds") private var refreshSeconds = 30

    var body: some View {
        ScrollView {
            VStack(spacing: 10 * scale) {
                ZKPageHeader(
                    micro: "APP + MARKET CONTROLS",
                    title: "Settings",
                    pill: "v0.9.0",
                    pillColor: ZKTheme.purple
                )

                sourceCard
                signalEngineCard
                chartCard
                experienceCard
                dataCard
                localAICard
                maintenanceCard
            }
            .padding(.horizontal, 16 * scale)
            .padding(.top, 8 * scale)
            .padding(.bottom, 18 * scale)
        }
        .scrollIndicators(.hidden)
        .background(ZKTheme.background)
        .onChange(of: chartMode) { _, newValue in
            state.chartMode = newValue
        }
    }

    private var sourceCard: some View {
        settingsCard(title: "MARKET + CHART SOURCE", subtitle: "Signal now uses our custom AI-readable 1M chart") {
            VStack(spacing: 10 * scale) {
                infoRow(
                    icon: "waveform.path.ecg.rectangle",
                    title: "Signal custom chart",
                    detail: "ZK 1M candle mirror • every received quote updates the current candle • same array ZK Agent reads",
                    color: feedColor
                )
                infoRow(
                    icon: "rectangle.on.rectangle",
                    title: "TradingView reference",
                    detail: "ICMARKETS:XAUUSD • visual reference remains on the Chart tab",
                    color: ZKTheme.green
                )
                infoRow(
                    icon: "link.badge.plus",
                    title: "Exact IC Markets parity",
                    detail: "Needs authorized IC Markets/cTrader live quotes + trendbars. The chart engine is ready to swap to that stream later.",
                    color: ZKTheme.gold
                )

                Picker("Default Chart tab", selection: $chartMode) {
                    Text("IC Markets TV").tag(0)
                    Text("ZK Custom").tag(1)
                }
                .pickerStyle(.segmented)
            }
        }
    }

    private var signalEngineCard: some View {
        settingsCard(title: "SIGNAL ENGINE", subtitle: "Paper-signal scanner running on the same 1M candles the Agent sees") {
            VStack(spacing: 10 * scale) {
                Toggle(isOn: Binding(get: { signalEngine.enabled }, set: { signalEngine.setEnabled($0) })) {
                    settingLabel("Enable signal engine", "Scans XAUUSD locally and keeps an active paper setup open until its TP or SL is reached")
                }
                .tint(ZKTheme.green)

                Picker("Signal mode", selection: Binding(get: { signalEngine.mode }, set: { signalEngine.setMode($0) })) {
                    Text("SELECTIVE").tag(SignalEngineMode.selective)
                    Text("FAST SCALPER").tag(SignalEngineMode.fastScalper)
                }
                .pickerStyle(.segmented)
                .disabled(!signalEngine.enabled)

                infoRow(
                    icon: signalEngine.mode == .fastScalper ? "bolt.fill" : "scope",
                    title: signalEngine.mode.rawValue,
                    detail: signalEngine.mode == .fastScalper
                        ? "Lower confluence threshold and ~8 minute cooldown. Designed to surface more short-lived M1 paper setups."
                        : "Higher confluence threshold and ~55 minute cooldown. Designed to target a few cleaner paper setups on an active day.",
                    color: signalEngine.mode == .fastScalper ? ZKTheme.pink : ZKTheme.purple
                )

                Text("The current engine is an alpha heuristic/confluence engine, not a trained predictive model and not broker order execution. Trade frequency is a target, not a guarantee; it will stay WAIT when conditions do not qualify.")
                    .font(.system(size: 8 * scale, weight: .medium))
                    .foregroundStyle(ZKTheme.textMuted)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var chartCard: some View {
        settingsCard(title: "CHART BEHAVIOUR", subtitle: "Tune the native chart without affecting TradingView") {
            VStack(spacing: 10 * scale) {
                Toggle(isOn: $chartMomentum) {
                    settingLabel("Momentum panning", "Uses predicted finger velocity for smooth inertial scrolling")
                }
                .tint(ZKTheme.purple)

                Toggle(isOn: $chartGrid) {
                    settingLabel("Grid", "Show native price/time grid")
                }
                .tint(ZKTheme.purple)

                Toggle(isOn: $priceLine) {
                    settingLabel("Latest-price line", "Show the current native close across the chart")
                }
                .tint(ZKTheme.purple)
            }
        }
    }

    private var experienceCard: some View {
        settingsCard(title: "IPHONE EXPERIENCE", subtitle: "Useful controls for everyday use") {
            VStack(spacing: 10 * scale) {
                Toggle(isOn: $haptics) {
                    settingLabel("Navigation haptics", "Subtle feedback when changing tabs")
                }
                .tint(ZKTheme.purple)

                Toggle(isOn: $reduceMotion) {
                    settingLabel("Reduce ZK animations", "Stops the rotating/pulsing Signal tab animation")
                }
                .tint(ZKTheme.purple)
            }
        }
    }

    private var dataCard: some View {
        settingsCard(title: "REFRESH", subtitle: "Controls the native fallback data service") {
            VStack(alignment: .leading, spacing: 10 * scale) {
                Picker("Refresh interval", selection: $refreshSeconds) {
                    Text("15 sec").tag(15)
                    Text("30 sec").tag(30)
                    Text("60 sec").tag(60)
                }
                .pickerStyle(.segmented)

                HStack {
                    VStack(alignment: .leading, spacing: 2 * scale) {
                        Text("Feed status")
                            .font(.system(size: 10 * scale, weight: .bold))
                        Text("\(market.feedStatus.rawValue) • \(market.freshnessText)")
                            .font(.system(size: 9 * scale, weight: .medium))
                            .foregroundStyle(feedColor)
                    }
                    Spacer()
                    Button("REFRESH NOW") {
                        Task { await market.refreshAll() }
                    }
                    .font(.system(size: 8 * scale, weight: .black))
                    .foregroundStyle(Color(red: 0.84, green: 0.48, blue: 0.91))
                    .padding(.horizontal, 10 * scale)
                    .frame(height: 30 * scale)
                    .background(ZKTheme.card2)
                    .overlay(Capsule().stroke(ZKTheme.borderStrong))
                    .clipShape(Capsule())
                    .buttonStyle(ZKPressStyle())
                }
            }
        }
    }

    private var localAICard: some View {
        settingsCard(title: "ZK AGENT MODELS", subtitle: "Choose lightweight Fast or optional stronger Smart local reasoning") {
            VStack(spacing: 10 * scale) {
                Picker("Agent model", selection: Binding(
                    get: { ai.selectedTier.rawValue },
                    set: { raw in if let tier = LocalAIService.ModelTier(rawValue: raw) { ai.selectTier(tier) } }
                )) {
                    Text("FAST 0.5B").tag(LocalAIService.ModelTier.fast.rawValue)
                    Text("SMART 1.5B").tag(LocalAIService.ModelTier.smart.rawValue)
                }
                .pickerStyle(.segmented)
                .disabled(ai.isBusy)

                infoRow(
                    icon: "brain.head.profile.fill",
                    title: ai.modelName,
                    detail: ai.statusDetail,
                    color: aiSettingsColor
                )

                HStack(spacing: 8 * scale) {
                    modelState(title: "FAST", installed: ai.fastInstalled)
                    modelState(title: "SMART", installed: ai.smartInstalled)
                }

                if case .downloading = ai.state {
                    ProgressView(value: ai.downloadProgress).tint(ZKTheme.purple)
                    HStack {
                        Text("\(Int(ai.downloadProgress * 100))%").font(.system(size: 8 * scale, weight: .black))
                        Spacer()
                        Text("KEEP APP OPEN").font(.system(size: 8 * scale, weight: .black)).foregroundStyle(ZKTheme.textMuted)
                    }
                } else if !ai.isInstalled {
                    Button { ai.downloadModel() } label: {
                        Label(ai.selectedTier == .smart ? "Download Smart ~924 MB" : "Download Fast ~491 MB", systemImage: "arrow.down.circle.fill")
                            .font(.system(size: 9 * scale, weight: .black))
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity, minHeight: 38 * scale)
                            .background(ZKTheme.accentGradient)
                            .clipShape(RoundedRectangle(cornerRadius: 11 * scale))
                    }
                    .buttonStyle(ZKPressStyle())
                } else {
                    HStack(spacing: 8 * scale) {
                        Button { Task { await ai.loadModel() } } label: {
                            Label(ai.isReady ? "Loaded" : "Load selected", systemImage: ai.isReady ? "checkmark.circle.fill" : "bolt.fill")
                                .font(.system(size: 9 * scale, weight: .bold))
                                .foregroundStyle(ai.isReady ? ZKTheme.green : .white)
                                .frame(maxWidth: .infinity, minHeight: 36 * scale)
                                .background(ai.isReady ? ZKTheme.green.opacity(0.06) : ZKTheme.card2)
                                .overlay(RoundedRectangle(cornerRadius: 10 * scale).stroke(ai.isReady ? ZKTheme.green.opacity(0.28) : ZKTheme.border))
                                .clipShape(RoundedRectangle(cornerRadius: 10 * scale))
                        }
                        .buttonStyle(ZKPressStyle())
                        .disabled(ai.isReady || ai.isBusy)

                        Button { ai.deleteModel() } label: {
                            Label("Delete selected", systemImage: "trash")
                                .font(.system(size: 9 * scale, weight: .bold))
                                .foregroundStyle(ZKTheme.red)
                                .frame(maxWidth: .infinity, minHeight: 36 * scale)
                                .background(ZKTheme.red.opacity(0.06))
                                .overlay(RoundedRectangle(cornerRadius: 10 * scale).stroke(ZKTheme.red.opacity(0.28)))
                                .clipShape(RoundedRectangle(cornerRadius: 10 * scale))
                        }
                        .buttonStyle(ZKPressStyle())
                    }
                }

                VStack(alignment: .leading, spacing: 4 * scale) {
                    Text("AGENT RUNTIME")
                        .font(.system(size: 7 * scale, weight: .black))
                        .foregroundStyle(ZKTheme.green)
                    Text("Stable greedy llama.cpp path • 64-token physical batches • 2 CPU threads • local persistent chats • planner/tool/verification loop • prompt budget \(ai.safePromptCharacterBudget) characters. Current prompt: \(ai.lastPromptCharacters).")
                        .font(.system(size: 8 * scale, weight: .medium))
                        .foregroundStyle(ZKTheme.textMuted)
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                Text("Smart is optional and uses more storage/RAM. Fast stays available as the proven fallback. The agent can inspect the custom Signal candle/tick stream, call app tools, navigate tabs and persist conversations, while the future numerical trading model remains separate.")
                    .font(.system(size: 8 * scale, weight: .medium))
                    .foregroundStyle(ZKTheme.textMuted)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private func modelState(title: String, installed: Bool) -> some View {
        HStack(spacing: 6 * scale) {
            Circle().fill(installed ? ZKTheme.green : ZKTheme.textMuted).frame(width: 6 * scale, height: 6 * scale)
            Text("\(title) • \(installed ? "ON DEVICE" : "NOT DOWNLOADED")")
                .font(.system(size: 7 * scale, weight: .black))
                .foregroundStyle(installed ? ZKTheme.textSoft : ZKTheme.textMuted)
            Spacer()
        }
        .padding(.horizontal, 8 * scale)
        .frame(maxWidth: .infinity, minHeight: 28 * scale)
        .background(ZKTheme.card2)
        .overlay(RoundedRectangle(cornerRadius: 8 * scale).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 8 * scale))
    }

    private var maintenanceCard: some View {
        settingsCard(title: "CHART STORAGE", subtitle: "Local tools only — no model data is touched") {
            HStack(spacing: 8 * scale) {
                Button {
                    state.clearAllDrawings()
                } label: {
                    Label("Clear drawings", systemImage: "trash")
                        .font(.system(size: 9 * scale, weight: .bold))
                        .foregroundStyle(ZKTheme.red)
                        .frame(maxWidth: .infinity, minHeight: 36 * scale)
                        .background(ZKTheme.red.opacity(0.06))
                        .overlay(RoundedRectangle(cornerRadius: 10 * scale).stroke(ZKTheme.red.opacity(0.28)))
                        .clipShape(RoundedRectangle(cornerRadius: 10 * scale))
                }
                .buttonStyle(ZKPressStyle())

                Button {
                    chartMode = 0
                    chartGrid = true
                    priceLine = true
                    chartMomentum = true
                    haptics = true
                    reduceMotion = false
                    refreshSeconds = 30
                } label: {
                    Label("Defaults", systemImage: "arrow.counterclockwise")
                        .font(.system(size: 9 * scale, weight: .bold))
                        .foregroundStyle(ZKTheme.textSoft)
                        .frame(maxWidth: .infinity, minHeight: 36 * scale)
                        .background(ZKTheme.card2)
                        .overlay(RoundedRectangle(cornerRadius: 10 * scale).stroke(ZKTheme.border))
                        .clipShape(RoundedRectangle(cornerRadius: 10 * scale))
                }
                .buttonStyle(ZKPressStyle())
            }
        }
    }

    private func settingsCard<Content: View>(title: String, subtitle: String, @ViewBuilder content: () -> Content) -> some View {
        ZKCard {
            VStack(alignment: .leading, spacing: 10 * scale) {
                VStack(alignment: .leading, spacing: 2 * scale) {
                    Text(title)
                        .font(.system(size: 8 * scale, weight: .black))
                        .tracking(0.7)
                        .foregroundStyle(ZKTheme.textSoft)
                    Text(subtitle)
                        .font(.system(size: 9 * scale, weight: .medium))
                        .foregroundStyle(ZKTheme.textMuted)
                }
                content()
            }
        }
    }

    private func settingLabel(_ title: String, _ subtitle: String) -> some View {
        VStack(alignment: .leading, spacing: 2 * scale) {
            Text(title)
                .font(.system(size: 10 * scale, weight: .bold))
            Text(subtitle)
                .font(.system(size: 8 * scale, weight: .medium))
                .foregroundStyle(ZKTheme.textMuted)
        }
    }

    private func infoRow(icon: String, title: String, detail: String, color: Color) -> some View {
        HStack(spacing: 9 * scale) {
            Image(systemName: icon)
                .font(.system(size: 13 * scale, weight: .bold))
                .foregroundStyle(color)
                .frame(width: 30 * scale, height: 30 * scale)
                .background(color.opacity(0.07))
                .clipShape(RoundedRectangle(cornerRadius: 9 * scale))
            VStack(alignment: .leading, spacing: 2 * scale) {
                Text(title)
                    .font(.system(size: 10 * scale, weight: .bold))
                Text(detail)
                    .font(.system(size: 8 * scale, weight: .medium))
                    .foregroundStyle(ZKTheme.textMuted)
            }
            Spacer()
        }
    }

    private var aiSettingsColor: Color {
        switch ai.state {
        case .ready, .generating: return ZKTheme.green
        case .downloading, .verifying, .loading, .downloaded: return ZKTheme.gold
        case .failed: return ZKTheme.red
        case .notDownloaded: return ZKTheme.purple
        }
    }

    private var feedColor: Color {
        switch market.feedStatus {
        case .live: return ZKTheme.green
        case .stale, .connecting: return ZKTheme.gold
        case .offline: return ZKTheme.red
        }
    }
}
