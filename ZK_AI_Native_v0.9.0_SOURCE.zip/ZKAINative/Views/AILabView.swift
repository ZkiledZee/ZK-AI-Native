import SwiftUI

struct AILabView: View {
    @EnvironmentObject private var state: AppState
    @EnvironmentObject private var ai: LocalAIService
    @Environment(\.zkScale) private var scale

    private let macroItems: [MacroItem] = [
        .init(name: "DXY / USD", value: "—", subtitle: "Dollar pressure", state: .unavailable),
        .init(name: "US 10Y", value: "—", subtitle: "Yield pressure", state: .unavailable),
        .init(name: "COT GOLD", value: "—", subtitle: "Managed Money", state: .unavailable),
        .init(name: "SILVER", value: "—", subtitle: "Precious metals", state: .unavailable),
        .init(name: "EURUSD", value: "—", subtitle: "USD cross-check", state: .unavailable),
        .init(name: "USDJPY", value: "—", subtitle: "USD cross-check", state: .unavailable),
        .init(name: "VIX", value: "—", subtitle: "Risk stress", state: .unavailable),
        .init(name: "NEWS", value: "—", subtitle: "CPI • NFP • FOMC", state: .unavailable)
    ]

    var body: some View {
        ScrollView {
            VStack(spacing: 10 * scale) {
                ZKPageHeader(micro: "NATIVE MACHINE LEARNING", title: "AI Lab", pill: ai.isReady ? "CHAT READY" : "NO MARKET MODEL", pillColor: ai.isReady ? ZKTheme.green : ZKTheme.gold)
                labHero
                localAIRuntime
                modelVault
                multiLayer
                macroCard
                evidenceCard
                journalDiagnostics
            }
            .padding(.horizontal, 16 * scale).padding(.top, 8 * scale).padding(.bottom, 18 * scale)
        }
        .scrollIndicators(.hidden).background(ZKTheme.background)
    }

    private var labHero: some View {
        HStack(spacing: 12 * scale) {
            Image(systemName: "sparkles")
                .font(.system(size: 23 * scale, weight: .bold)).foregroundStyle(Color(red: 0.855, green: 0.490, blue: 0.925))
                .frame(width: 52 * scale, height: 52 * scale).background(Color(red: 0.094, green: 0.051, blue: 0.114))
                .overlay(RoundedRectangle(cornerRadius: 16 * scale).stroke(ZKTheme.borderStrong)).clipShape(RoundedRectangle(cornerRadius: 16 * scale))

            VStack(alignment: .leading, spacing: 4 * scale) {
                Text("MODEL SLOT").font(.system(size: 8 * scale, weight: .black)).tracking(0.7).foregroundStyle(ZKTheme.textMuted)
                Text(state.selectedModel?.name ?? "No trained model").font(.system(size: 15 * scale, weight: .bold)).lineLimit(1)
                Text("ZK Agent is separate from the future numerical trading model. It can inspect the custom Signal chart, use app tools and keep persistent local conversations without inventing market-model signals.")
                    .font(.system(size: 10 * scale, weight: .medium)).foregroundStyle(ZKTheme.textMuted).lineLimit(2)
            }
            Spacer()
        }
        .padding(12 * scale)
        .background(RadialGradient(colors: [ZKTheme.purple.opacity(0.10), ZKTheme.card2], center: .topTrailing, startRadius: 0, endRadius: 180))
        .overlay(RoundedRectangle(cornerRadius: 17 * scale).stroke(ZKTheme.borderStrong)).clipShape(RoundedRectangle(cornerRadius: 17 * scale))
    }

    private var localAIRuntime: some View {
        ZKCard(strongBorder: true) {
            HStack(spacing: 10 * scale) {
                Image(systemName: "brain.head.profile.fill")
                    .font(.system(size: 20 * scale, weight: .bold))
                    .foregroundStyle(ai.isReady ? ZKTheme.green : ZKTheme.purple)
                    .frame(width: 44 * scale, height: 44 * scale)
                    .background((ai.isReady ? ZKTheme.green : ZKTheme.purple).opacity(0.08))
                    .clipShape(RoundedRectangle(cornerRadius: 13 * scale))
                VStack(alignment: .leading, spacing: 3 * scale) {
                    Text("LOCAL ZK AGENT")
                        .font(.system(size: 8 * scale, weight: .black))
                        .tracking(0.7)
                        .foregroundStyle(ZKTheme.textSoft)
                    Text(ai.modelName)
                        .font(.system(size: 11 * scale, weight: .bold))
                    Text(ai.statusDetail)
                        .font(.system(size: 8 * scale, weight: .medium))
                        .foregroundStyle(ZKTheme.textMuted)
                        .lineLimit(2)
                }
                Spacer()
                Button { state.go(.chat) } label: {
                    Image(systemName: "arrow.right")
                        .font(.system(size: 13 * scale, weight: .black))
                        .foregroundStyle(.white)
                        .frame(width: 34 * scale, height: 34 * scale)
                        .background(ZKTheme.accentGradient)
                        .clipShape(Circle())
                }
                .buttonStyle(ZKPressStyle())
            }
        }
    }

    private var modelVault: some View {
        ZKCard {
            VStack(alignment: .leading, spacing: 10 * scale) {
                sectionHeader("MODEL VAULT", "Active + challengers + older models", trailing: "\(state.models.count) SAVED")
                Menu {
                    ForEach(state.models) { model in Button("\(model.status) • \(model.name)") { state.selectedModelID = model.id } }
                } label: {
                    HStack {
                        Text(state.selectedModel.map { "\($0.status) • \($0.name)" } ?? "No saved models")
                            .font(.system(size: 11 * scale, weight: .bold)).foregroundStyle(.white).lineLimit(1).minimumScaleFactor(0.8)
                        Spacer(); Image(systemName: "chevron.down").foregroundStyle(ZKTheme.textSoft)
                    }
                    .padding(.horizontal, 11 * scale).frame(height: 42 * scale).background(Color(red: 0.039, green: 0.027, blue: 0.063))
                    .overlay(RoundedRectangle(cornerRadius: 11 * scale).stroke(ZKTheme.borderStrong)).clipShape(RoundedRectangle(cornerRadius: 11 * scale))
                }

                if let m = state.selectedModel {
                    Text("\(m.evidence) • Train: \(m.trainRange) • Unseen: \(m.unseenRange)")
                        .font(.system(size: 9 * scale, weight: .medium)).foregroundStyle(ZKTheme.textMuted).lineLimit(1).minimumScaleFactor(0.7)
                    HStack(spacing: 5 * scale) {
                        MetricCell(label: "TRADES", value: "\(m.resolvedTrades)")
                        MetricCell(label: "PF", value: m.profitFactor.map { String(format: "%.2f", $0) } ?? "—")
                        MetricCell(label: "EXP", value: m.expectancyR.map { String(format: "%+.2fR", $0) } ?? "—")
                        MetricCell(label: "DD", value: m.drawdownR.map { String(format: "%.1fR", $0) } ?? "—")
                    }
                }
            }
        }
    }

    private var multiLayer: some View {
        ZKCard {
            VStack(alignment: .leading, spacing: 9 * scale) {
                sectionHeader("MULTI-LAYER AI", "Market AI → Macro AI → Execution Gate", trailing: "WAIT")
                flowRow("1", "MARKET AI", "Price, structure, volatility, MFE/MAE")
                flowRow("2", "MACRO AI", "USD, yields, COT, silver and event context")
                flowRow("3", "EXECUTION GATE", "Expected value, spread, structure and 2R+ filter")
            }
        }
    }

    private func flowRow(_ num: String, _ title: String, _ subtitle: String) -> some View {
        HStack(spacing: 10 * scale) {
            Text(num).font(.system(size: 9 * scale, weight: .black)).foregroundStyle(Color(red: 0.831, green: 0.478, blue: 0.894))
                .frame(width: 25 * scale, height: 25 * scale).overlay(RoundedRectangle(cornerRadius: 7 * scale).stroke(ZKTheme.borderStrong))
            VStack(alignment: .leading, spacing: 2 * scale) {
                Text(title).font(.system(size: 10 * scale, weight: .black))
                Text(subtitle).font(.system(size: 9 * scale, weight: .medium)).foregroundStyle(ZKTheme.textMuted).lineLimit(1).minimumScaleFactor(0.75)
            }
            Spacer()
        }
        .padding(9 * scale).background(Color(red: 0.035, green: 0.027, blue: 0.051))
        .overlay(RoundedRectangle(cornerRadius: 11 * scale).stroke(ZKTheme.border)).clipShape(RoundedRectangle(cornerRadius: 11 * scale))
    }

    private var macroCard: some View {
        ZKCard {
            VStack(alignment: .leading, spacing: 10 * scale) {
                sectionHeader("GOLD INTELLIGENCE", "Macro regime unavailable", trailing: "\(Int(state.macroCoverage * 100))% COVERAGE")

                HStack(spacing: 11 * scale) {
                    VStack(spacing: 2 * scale) {
                        Text("—").font(.system(size: 24 * scale, weight: .black))
                        Text("REGIME").font(.system(size: 7 * scale, weight: .black)).foregroundStyle(ZKTheme.textMuted)
                    }
                    .frame(width: 78 * scale, height: 68 * scale).background(ZKTheme.purple.opacity(0.06))
                    .overlay(RoundedRectangle(cornerRadius: 14 * scale).stroke(ZKTheme.borderStrong)).clipShape(RoundedRectangle(cornerRadius: 14 * scale))

                    VStack(alignment: .leading, spacing: 4 * scale) {
                        Text("Macro influence is gated off").font(.system(size: 11 * scale, weight: .bold))
                        Text("Until source coverage is reliable, Macro AI stays informational and cannot alter a trade.")
                            .font(.system(size: 9 * scale, weight: .medium)).foregroundStyle(ZKTheme.textMuted)
                    }
                }

                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 7 * scale) {
                    ForEach(macroItems) { item in
                        VStack(alignment: .leading, spacing: 3 * scale) {
                            Text(item.name).font(.system(size: 8 * scale, weight: .black)).foregroundStyle(ZKTheme.textMuted)
                            Text(item.value).font(.system(size: 11 * scale, weight: .black))
                            Text(item.subtitle).font(.system(size: 8.5 * scale, weight: .medium)).foregroundStyle(Color(red: 0.48, green: 0.44, blue: 0.50))
                        }
                        .frame(maxWidth: .infinity, alignment: .leading).padding(9 * scale).background(Color(red: 0.035, green: 0.027, blue: 0.051))
                        .overlay(RoundedRectangle(cornerRadius: 10 * scale).stroke(ZKTheme.border)).clipShape(RoundedRectangle(cornerRadius: 10 * scale))
                    }
                }

                Text("COT planned: net, weekly Δ, %OI, 13/52w percentile and z-score")
                    .font(.system(size: 9 * scale, weight: .medium)).foregroundStyle(ZKTheme.textMuted)
            }
        }
    }

    private var evidenceCard: some View {
        ZKCard {
            VStack(alignment: .leading, spacing: 9 * scale) {
                sectionHeader("MODEL EVIDENCE", "Minimum proof before promotion", trailing: state.selectedModel?.evidence ?? "EXPERIMENTAL")
                HStack(spacing: 6 * scale) {
                    evidence("EXPERIMENTAL", "0–99 unseen")
                    evidence("DEVELOPING", "100–299")
                    evidence("VALIDATED", "300+")
                }
                Text("Promotion also requires positive expectancy after costs and acceptable drawdown.")
                    .font(.system(size: 9 * scale, weight: .medium)).foregroundStyle(ZKTheme.textMuted)
            }
        }
    }

    private func evidence(_ title: String, _ subtitle: String) -> some View {
        VStack(spacing: 3 * scale) {
            Text(title).font(.system(size: 8 * scale, weight: .black)).lineLimit(1).minimumScaleFactor(0.7)
            Text(subtitle).font(.system(size: 8 * scale)).foregroundStyle(ZKTheme.textMuted)
        }
        .frame(maxWidth: .infinity).padding(.vertical, 8 * scale).background(Color(red: 0.035, green: 0.027, blue: 0.051))
        .overlay(RoundedRectangle(cornerRadius: 9 * scale).stroke(ZKTheme.border)).clipShape(RoundedRectangle(cornerRadius: 9 * scale))
    }

    private var journalDiagnostics: some View {
        ZKCard {
            VStack(alignment: .leading, spacing: 8 * scale) {
                sectionHeader("TRADE JOURNAL", "Diagnostics foundation", trailing: "\(state.journal.count) TRADES")
                Text("Future trades will save model probabilities, macro coverage, volatility, structure, spread, session, similarity, entry/SL/TP and outcome.")
                    .font(.system(size: 9 * scale, weight: .medium)).foregroundStyle(ZKTheme.textMuted)
            }
        }
    }

    private func sectionHeader(_ micro: String, _ title: String, trailing: String) -> some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 3 * scale) {
                Text(micro).font(.system(size: 8 * scale, weight: .black)).tracking(0.7).foregroundStyle(ZKTheme.textMuted)
                Text(title).font(.system(size: 11 * scale, weight: .bold))
            }
            Spacer()
            Text(trailing).font(.system(size: 8 * scale, weight: .bold)).foregroundStyle(ZKTheme.textSoft).lineLimit(1)
        }
    }
}
