import SwiftUI

struct SignalView: View {
    @EnvironmentObject private var state: AppState
    @EnvironmentObject private var market: MarketDataService
    @EnvironmentObject private var engine: SignalEngine
    @Environment(\.zkScale) private var scale
    @StateObject private var notifications = NotificationManager.shared

    var body: some View {
        VStack(spacing: 8 * scale) {
            ZKPageHeader(
                micro: "SIGNAL ENGINE • XAUUSD • 1M",
                title: "Signal",
                pill: engine.enabled ? engine.mode.rawValue : "PAUSED",
                pillColor: engine.enabled ? modeColor : ZKTheme.textMuted
            )

            marketStrip
            engineControls
            signalCore
            chart.frame(maxHeight: .infinity)
            levels
            lifecycle
        }
        .padding(.horizontal, 16 * scale)
        .padding(.top, 8 * scale)
        .padding(.bottom, 8 * scale)
        .background(ZKTheme.background)
        .task { state.notificationPermission = await notifications.refresh() }
    }

    private var marketStrip: some View {
        HStack(spacing: 6 * scale) {
            VStack(alignment: .leading, spacing: 2 * scale) {
                Text("XAU / USD")
                    .font(.system(size: 8 * scale, weight: .black))
                    .foregroundStyle(ZKTheme.textMuted)
                Text(market.currentPrice.map { String(format: "$%.2f", $0) } ?? "—")
                    .font(.system(size: 15 * scale, weight: .black, design: .monospaced))
                    .contentTransition(.numericText())
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 2 * scale) {
                Text("CUSTOM 1M • AI READABLE")
                    .font(.system(size: 7 * scale, weight: .black))
                    .foregroundStyle(ZKTheme.textMuted)
                Text("\(market.feedStatus.rawValue) • \(market.freshnessText)")
                    .font(.system(size: 9 * scale, weight: .bold))
                    .foregroundStyle(feedColor)
            }
        }
        .padding(.horizontal, 11 * scale)
        .padding(.vertical, 9 * scale)
        .background(Color(red: 0.035, green: 0.027, blue: 0.051))
        .overlay(RoundedRectangle(cornerRadius: 12 * scale).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 12 * scale))
    }

    private var engineControls: some View {
        VStack(spacing: 8 * scale) {
            HStack {
                VStack(alignment: .leading, spacing: 2 * scale) {
                    Text("ZK SIGNAL ENGINE ALPHA")
                        .font(.system(size: 8 * scale, weight: .black))
                        .tracking(0.7)
                    Text(engine.mode.subtitle)
                        .font(.system(size: 8 * scale, weight: .medium))
                        .foregroundStyle(ZKTheme.textMuted)
                        .lineLimit(2)
                }
                Spacer(minLength: 8)
                Toggle("", isOn: Binding(get: { engine.enabled }, set: { engine.setEnabled($0) }))
                    .labelsHidden()
                    .tint(ZKTheme.green)
            }

            Picker("Signal mode", selection: Binding(
                get: { engine.mode },
                set: { engine.setMode($0) }
            )) {
                Text("SELECTIVE").tag(SignalEngineMode.selective)
                Text("FAST SCALPER").tag(SignalEngineMode.fastScalper)
            }
            .pickerStyle(.segmented)
            .disabled(!engine.enabled)

            HStack(spacing: 6 * scale) {
                statPill("TODAY", "\(engine.todayTradeCount)", modeColor)
                statPill("SCORE", "\(Int(engine.lastScore))", ZKTheme.textSoft)
                statPill("STATE", engine.activeTrade == nil ? "SCAN" : "OPEN", engine.activeTrade == nil ? ZKTheme.gold : ZKTheme.green)
            }
        }
        .padding(10 * scale)
        .background(LinearGradient(colors: [Color(red: 0.063, green: 0.043, blue: 0.078), Color(red: 0.031, green: 0.024, blue: 0.043)], startPoint: .topLeading, endPoint: .bottomTrailing))
        .overlay(RoundedRectangle(cornerRadius: 14 * scale).stroke(ZKTheme.borderStrong))
        .clipShape(RoundedRectangle(cornerRadius: 14 * scale))
    }

    private func statPill(_ title: String, _ value: String, _ color: Color) -> some View {
        VStack(spacing: 2 * scale) {
            Text(title).font(.system(size: 6 * scale, weight: .black)).foregroundStyle(ZKTheme.textMuted)
            Text(value).font(.system(size: 8 * scale, weight: .black, design: .monospaced)).foregroundStyle(color).lineLimit(1)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 5 * scale)
        .background(Color.black.opacity(0.16))
        .overlay(RoundedRectangle(cornerRadius: 8 * scale).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 8 * scale))
    }

    private var signalCore: some View {
        let s = engine.snapshot
        return VStack(spacing: 8 * scale) {
            HStack(alignment: .center, spacing: 11 * scale) {
                SignalOrb(color: signalColor)
                VStack(alignment: .leading, spacing: 4 * scale) {
                    Text("ENGINE BIAS")
                        .font(.system(size: 8 * scale, weight: .black))
                        .tracking(0.8)
                        .foregroundStyle(ZKTheme.textSoft)
                    Text(s.side.rawValue)
                        .font(.system(size: 27 * scale, weight: .black, design: .rounded))
                        .tracking(-0.8)
                        .foregroundStyle(signalColor)
                    Text(s.lifecycle)
                        .font(.system(size: 7.5 * scale, weight: .black))
                        .foregroundStyle(ZKTheme.textMuted)
                }
                Spacer()
                ConfidenceRing(value: s.executionConfidence, color: signalColor, label: "EXEC")
            }

            HStack(spacing: 6 * scale) {
                ProbabilityCell(label: "BUY", value: s.buyProbability, color: ZKTheme.green)
                ProbabilityCell(label: "WAIT", value: s.waitProbability, color: ZKTheme.gold)
                ProbabilityCell(label: "SELL", value: s.sellProbability, color: ZKTheme.red)
            }

            Text(s.reason)
                .font(.system(size: 9.5 * scale, weight: .medium))
                .foregroundStyle(ZKTheme.textMuted)
                .frame(maxWidth: .infinity, alignment: .leading)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(12 * scale)
        .background(RadialGradient(colors: [signalColor.opacity(0.09), Color(red: 0.051, green: 0.035, blue: 0.067)], center: .topTrailing, startRadius: 0, endRadius: 180))
        .overlay(RoundedRectangle(cornerRadius: 18 * scale).stroke(signalColor.opacity(0.24)))
        .clipShape(RoundedRectangle(cornerRadius: 18 * scale))
    }

    private var chart: some View {
        ZStack(alignment: .top) {
            if market.candles.isEmpty {
                VStack(spacing: 8 * scale) {
                    ProgressView().tint(ZKTheme.purple)
                    Text(market.feedStatus == .offline ? "Custom chart unavailable" : "Building ZK custom XAUUSD 1M chart…")
                        .font(.system(size: 10 * scale, weight: .bold))
                        .foregroundStyle(ZKTheme.textMuted)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                NativeAgentChart(candles: market.candles, drawings: signalDrawings)
                    .padding(.top, 43 * scale)
            }

            HStack(alignment: .top, spacing: 8 * scale) {
                VStack(alignment: .leading, spacing: 2 * scale) {
                    Text("ZK CUSTOM • XAUUSD • 1M")
                        .font(.system(size: 11 * scale, weight: .black))
                    Text("Visible candles = engine candles = agent candles")
                        .font(.system(size: 7.4 * scale, weight: .medium))
                        .foregroundStyle(ZKTheme.textMuted)
                }
                Spacer()
                Button {
                    engine.forceEvaluate()
                } label: {
                    Text("SCAN NOW")
                        .font(.system(size: 7 * scale, weight: .black))
                        .foregroundStyle(ZKTheme.textSoft)
                        .padding(.horizontal, 8 * scale)
                        .frame(height: 27 * scale)
                        .background(ZKTheme.card2)
                        .overlay(Capsule().stroke(ZKTheme.border))
                        .clipShape(Capsule())
                }
                .buttonStyle(ZKPressStyle())
            }
            .padding(10 * scale)
            .background(ZKTheme.navBackground.opacity(0.92))
        }
        .frame(minHeight: 200 * scale)
        .background(RadialGradient(colors: [ZKTheme.purple.opacity(0.07), Color(red: 0.031, green: 0.024, blue: 0.043)], center: .topTrailing, startRadius: 0, endRadius: 220))
        .overlay(RoundedRectangle(cornerRadius: 18 * scale).stroke(ZKTheme.borderStrong))
        .clipShape(RoundedRectangle(cornerRadius: 18 * scale))
        .overlay(alignment: .bottomLeading) {
            Text("Paper signals only • no broker order execution")
                .font(.system(size: 6.6 * scale, weight: .bold))
                .foregroundStyle(ZKTheme.textMuted)
                .padding(.horizontal, 9 * scale)
                .padding(.bottom, 5 * scale)
                .allowsHitTesting(false)
        }
    }

    private var signalDrawings: [ChartDrawing] {
        var result = state.drawings
        if let trade = engine.activeTrade {
            result.removeAll { [.entry, .stopLoss, .takeProfit].contains($0.kind) }
            result.append(.init(kind: .entry, price: trade.entry, label: "ENTRY"))
            result.append(.init(kind: .stopLoss, price: trade.stopLoss, label: "SL"))
            result.append(.init(kind: .takeProfit, price: trade.takeProfit, label: "TP"))
        }
        return result
    }

    private var levels: some View {
        let s = engine.snapshot
        return HStack(spacing: 5 * scale) {
            levelText("ENTRY", priceText(s.entry), signalColor)
            levelText("SL", priceText(s.stopLoss), ZKTheme.red)
            levelText("TP", priceText(s.takeProfit), ZKTheme.green)
            levelText("R:R", s.riskReward.map { String(format: "%.2f", $0) } ?? "—", ZKTheme.purple)
        }
    }

    private func priceText(_ value: Double?) -> String { value.map { String(format: "%.2f", $0) } ?? "—" }

    private func levelText(_ title: String, _ text: String, _ color: Color) -> some View {
        VStack(spacing: 3 * scale) {
            Text(title).font(.system(size: 7 * scale, weight: .black)).foregroundStyle(ZKTheme.textMuted)
            Text(text).font(.system(size: 9 * scale, weight: .black, design: .monospaced)).foregroundStyle(color).minimumScaleFactor(0.65).lineLimit(1)
        }
        .frame(maxWidth: .infinity).padding(.vertical, 8 * scale)
        .background(Color(red: 0.035, green: 0.027, blue: 0.051))
        .overlay(RoundedRectangle(cornerRadius: 11 * scale).stroke(ZKTheme.border)).clipShape(RoundedRectangle(cornerRadius: 11 * scale))
    }

    private var lifecycle: some View {
        HStack(spacing: 7 * scale) {
            Circle().fill(engine.enabled ? modeColor : ZKTheme.textMuted).frame(width: 7 * scale, height: 7 * scale)
            Text(engine.enabled ? "ENGINE ON • \(engine.mode.rawValue) • PAPER" : "SIGNAL ENGINE PAUSED")
                .font(.system(size: 8 * scale, weight: .black))
                .foregroundStyle(.white.opacity(0.86))
            Spacer()
            Button {
                Task {
                    if !state.notificationPermission { state.notificationPermission = await notifications.request() }
                    if state.notificationPermission { await notifications.sendDemo() }
                }
            } label: {
                Text(state.notificationPermission ? "ALERTS ON" : "ENABLE ALERTS")
                    .font(.system(size: 8 * scale, weight: .black))
                    .foregroundStyle(ZKTheme.purple)
            }
            .buttonStyle(ZKPressStyle())
        }
        .padding(.horizontal, 10 * scale)
        .frame(height: 34 * scale)
        .background(Color(red: 0.035, green: 0.027, blue: 0.051))
        .overlay(RoundedRectangle(cornerRadius: 10 * scale).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 10 * scale))
    }

    private var signalColor: Color {
        switch engine.snapshot.side {
        case .buy: return ZKTheme.green
        case .sell: return ZKTheme.red
        case .wait: return ZKTheme.gold
        }
    }

    private var modeColor: Color { engine.mode == .fastScalper ? ZKTheme.pink : ZKTheme.purple }

    private var feedColor: Color {
        switch market.feedStatus {
        case .live: return ZKTheme.green
        case .stale, .connecting: return ZKTheme.gold
        case .offline: return ZKTheme.red
        }
    }
}
