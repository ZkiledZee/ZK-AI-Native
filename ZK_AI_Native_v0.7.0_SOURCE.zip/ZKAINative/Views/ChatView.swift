import SwiftUI

struct ChatView: View {
    @EnvironmentObject private var state: AppState
    @EnvironmentObject private var market: MarketDataService
    @EnvironmentObject private var ai: LocalAIService
    @Environment(\.zkScale) private var scale
    @State private var input = ""
    @FocusState private var composerFocused: Bool

    var body: some View {
        VStack(spacing: 9 * scale) {
            ZKPageHeader(
                micro: "ON-DEVICE • APP-AWARE",
                title: "ZK AI Chat",
                pill: ai.shortStatus,
                pillColor: aiColor
            )

            aiStatusCard

            messages
                .frame(maxHeight: .infinity)

            chips
            composer
        }
        .padding(.horizontal, 16 * scale)
        .padding(.top, 8 * scale)
        .padding(.bottom, 8 * scale)
        .background(ZKTheme.background)
        .contentShape(Rectangle())
        .onTapGesture { composerFocused = false }
        .task {
            if ai.isInstalled && !ai.isReady && !ai.isBusy {
                await ai.loadModel()
            }
            consumePendingPrompt()
        }
        .onChange(of: state.pendingChatPrompt) {
            consumePendingPrompt()
        }
    }

    private var aiStatusCard: some View {
        ZKCard(strongBorder: true) {
            VStack(spacing: 10 * scale) {
                HStack(spacing: 10 * scale) {
                    ZStack {
                        Circle()
                            .fill(aiColor.opacity(0.12))
                            .frame(width: 42 * scale, height: 42 * scale)
                        Image(systemName: ai.isReady ? "brain.head.profile.fill" : "arrow.down.circle.fill")
                            .font(.system(size: 20 * scale, weight: .bold))
                            .foregroundStyle(aiColor)
                    }

                    VStack(alignment: .leading, spacing: 2 * scale) {
                        Text(LocalAIService.modelName)
                            .font(.system(size: 11 * scale, weight: .black))
                        Text(ai.statusDetail)
                            .font(.system(size: 8.5 * scale, weight: .medium))
                            .foregroundStyle(ZKTheme.textMuted)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    Spacer(minLength: 4)
                }

                if case .downloading = ai.state {
                    VStack(spacing: 5 * scale) {
                        ProgressView(value: ai.downloadProgress)
                            .tint(ZKTheme.purple)
                        HStack {
                            Text("\(Int(ai.downloadProgress * 100))%")
                            Spacer()
                            Text("KEEP APP OPEN")
                                .foregroundStyle(ZKTheme.textMuted)
                        }
                        .font(.system(size: 8 * scale, weight: .black))
                    }
                } else if case .verifying = ai.state {
                    HStack(spacing: 7 * scale) {
                        ProgressView().tint(ZKTheme.gold)
                        Text("VERIFYING MODEL CHECKSUM")
                            .font(.system(size: 8 * scale, weight: .black))
                            .foregroundStyle(ZKTheme.gold)
                        Spacer()
                    }
                } else if !ai.isInstalled {
                    Button {
                        ai.downloadModel()
                    } label: {
                        HStack(spacing: 8 * scale) {
                            Image(systemName: "arrow.down.circle.fill")
                            Text("DOWNLOAD ZK LOCAL AI • ~491 MB")
                        }
                        .font(.system(size: 9 * scale, weight: .black))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity, minHeight: 39 * scale)
                        .background(ZKTheme.accentGradient)
                        .clipShape(RoundedRectangle(cornerRadius: 11 * scale))
                    }
                    .buttonStyle(ZKPressStyle())
                } else if !ai.isReady && !ai.isBusy {
                    Button {
                        Task { await ai.loadModel() }
                    } label: {
                        Label("LOAD LOCAL AI", systemImage: "bolt.fill")
                            .font(.system(size: 9 * scale, weight: .black))
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity, minHeight: 38 * scale)
                            .background(ZKTheme.accentGradient)
                            .clipShape(RoundedRectangle(cornerRadius: 11 * scale))
                    }
                    .buttonStyle(ZKPressStyle())
                }

                HStack(spacing: 7 * scale) {
                    contextBadge("MARKET", market.feedStatus.rawValue, feedColor)
                    contextBadge("APP", "LIVE", ZKTheme.green)
                    contextBadge("INFERENCE", ai.isReady ? "LOCAL" : "OFF", ai.isReady ? ZKTheme.green : ZKTheme.textMuted)
                }

                HStack {
                    Text("RUNTIME CHECKPOINT")
                        .font(.system(size: 6.5 * scale, weight: .black))
                        .foregroundStyle(ZKTheme.textMuted)
                    Spacer()
                    Text(ai.lastInferenceCheckpoint)
                        .font(.system(size: 7 * scale, weight: .black, design: .monospaced))
                        .foregroundStyle(ZKTheme.textSoft)
                        .lineLimit(1)
                }
            }
        }
    }

    private func contextBadge(_ title: String, _ value: String, _ color: Color) -> some View {
        VStack(spacing: 2 * scale) {
            Text(title)
                .font(.system(size: 6.5 * scale, weight: .black))
                .foregroundStyle(ZKTheme.textMuted)
            Text(value)
                .font(.system(size: 8 * scale, weight: .black))
                .foregroundStyle(color)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 6 * scale)
        .background(Color.black.opacity(0.16))
        .overlay(RoundedRectangle(cornerRadius: 9 * scale).stroke(ZKTheme.border))
        .clipShape(RoundedRectangle(cornerRadius: 9 * scale))
    }

    private var messages: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 9 * scale) {
                    ForEach(state.chatMessages) { message in
                        bubble(message).id(message.id)
                    }
                }
                .padding(.vertical, 3 * scale)
            }
            .scrollDismissesKeyboard(.interactively)
            .scrollIndicators(.hidden)
            .onChange(of: state.chatMessages) {
                if let last = state.chatMessages.last {
                    withAnimation(.easeOut(duration: 0.16)) {
                        proxy.scrollTo(last.id, anchor: .bottom)
                    }
                }
            }
        }
    }

    private func bubble(_ msg: ChatMessage) -> some View {
        HStack {
            if msg.role == .user { Spacer(minLength: 42 * scale) }

            VStack(alignment: .leading, spacing: 5 * scale) {
                HStack(spacing: 5 * scale) {
                    Text(msg.role == .user ? "YOU" : "ZK AI")
                        .font(.system(size: 8 * scale, weight: .black))
                        .tracking(0.6)
                    if msg.role == .assistant && ai.state == .generating && msg.id == state.chatMessages.last?.id {
                        ProgressView().controlSize(.mini).tint(ZKTheme.purple)
                    }
                }
                .foregroundStyle(msg.role == .user ? Color(red: 0.831, green: 0.478, blue: 0.894) : ZKTheme.textMuted)

                if msg.text.isEmpty {
                    Text("Thinking locally…")
                        .font(.system(size: 11 * scale, weight: .medium))
                        .foregroundStyle(ZKTheme.textMuted)
                } else {
                    Text(msg.text)
                        .font(.system(size: 12 * scale, weight: .medium))
                        .foregroundStyle(.white.opacity(0.92))
                        .lineSpacing(2.2 * scale)
                        .textSelection(.enabled)
                }
            }
            .padding(12 * scale)
            .background(msg.role == .user ? Color(red: 0.086, green: 0.051, blue: 0.110) : ZKTheme.card)
            .overlay(RoundedRectangle(cornerRadius: 15 * scale).stroke(msg.role == .user ? ZKTheme.borderStrong : ZKTheme.border))
            .clipShape(RoundedRectangle(cornerRadius: 15 * scale))

            if msg.role == .assistant { Spacer(minLength: 42 * scale) }
        }
    }

    private var chips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 7 * scale) {
                chip("Analyse gold now")
                chip("What do you see?")
                chip("Explain structure")
                chip("Mark support resistance")
                chip("App status")
                chip("Backtest status")
                chip("Clear drawings")
            }
            .padding(.horizontal, 1)
        }
        .frame(height: 36 * scale)
    }

    private func chip(_ text: String) -> some View {
        Button { send(text) } label: {
            Text(text)
                .font(.system(size: 9 * scale, weight: .bold))
                .foregroundStyle(ZKTheme.textSoft)
                .padding(.horizontal, 11 * scale)
                .frame(height: 31 * scale)
                .background(ZKTheme.card)
                .overlay(Capsule().stroke(ZKTheme.border))
                .clipShape(Capsule())
        }
        .buttonStyle(ZKPressStyle())
        .disabled(ai.state == .generating)
    }

    private var composer: some View {
        HStack(spacing: 7 * scale) {
            TextField(ai.isInstalled ? "Ask ZK AI about anything in the app…" : "Download ZK Local AI to start chatting…", text: $input, axis: .vertical)
                .focused($composerFocused)
                .font(.system(size: 12 * scale, weight: .medium))
                .padding(.horizontal, 12 * scale)
                .padding(.vertical, 8 * scale)
                .frame(minHeight: 46 * scale, maxHeight: 92 * scale)
                .background(ZKTheme.card)
                .overlay(RoundedRectangle(cornerRadius: 14 * scale).stroke(ZKTheme.borderStrong))
                .clipShape(RoundedRectangle(cornerRadius: 14 * scale))
                .submitLabel(.send)
                .onSubmit { send() }
                .disabled(ai.state == .generating)

            Button(action: send) {
                Image(systemName: ai.state == .generating ? "ellipsis" : "arrow.up")
                    .font(.system(size: 18 * scale, weight: .black))
                    .foregroundStyle(.white)
                    .frame(width: 46 * scale, height: 46 * scale)
                    .background(ai.state == .generating ? AnyShapeStyle(ZKTheme.card2) : AnyShapeStyle(ZKTheme.accentGradient))
                    .clipShape(RoundedRectangle(cornerRadius: 14 * scale))
            }
            .buttonStyle(ZKPressStyle())
            .disabled(ai.state == .generating)
        }
    }

    private func send() { send(input) }

    private func send(_ supplied: String) {
        let text = supplied.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        input = ""
        composerFocused = false

        guard ai.isInstalled else {
            state.appendUserMessage(text)
            state.appendAssistantMessage("Download ZK Local AI above first. The model is kept out of the IPA so the app stays small; after the one-time download it runs locally on your iPhone.")
            return
        }
        guard ai.state != .generating else { return }

        Task {
            state.appendUserMessage(text)

            if ChartIntelligenceEngine.shouldUseDirectReport(text) {
                let chart = ChartIntelligenceEngine.snapshot(candles: market.candles, currentPrice: market.currentPrice)
                state.appendAssistantMessage(chart.userFacingReport)
                return
            }

            let toolNote = await AIToolRouter.execute(query: text, state: state, market: market)
            let context = AIAppContextBuilder.build(state: state, market: market, query: text, toolNote: toolNote)
            let history = state.chatMessages
            let responseID = state.appendAssistantMessage()

            do {
                try await ai.generate(appContext: context, conversation: history) { token in
                    state.appendToAssistantMessage(id: responseID, token: token)
                }
                if state.chatMessages.first(where: { $0.id == responseID })?.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == true {
                    state.replaceAssistantMessage(id: responseID, text: "I didn't produce a usable response. Try asking again with a shorter question.")
                }
            } catch {
                state.replaceAssistantMessage(id: responseID, text: "Local AI error: \(error.localizedDescription)")
            }
        }
    }


    private func consumePendingPrompt() {
        guard let prompt = state.pendingChatPrompt?.trimmingCharacters(in: .whitespacesAndNewlines), !prompt.isEmpty else { return }
        state.pendingChatPrompt = nil
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) {
            send(prompt)
        }
    }

    private var aiColor: Color {
        switch ai.state {
        case .ready, .generating: return ZKTheme.green
        case .downloading, .verifying, .loading, .downloaded: return ZKTheme.gold
        case .failed: return ZKTheme.red
        case .notDownloaded: return ZKTheme.purple
        }
    }

    private var feedColor: Color {
        switch market.feedStatus {
        case .live: return ZKTheme.green
        case .stale, .connecting: return ZKTheme.gold
        case .offline: return ZKTheme.red
        }
    }
}
