# ZK AI Native v0.7.0 — Chart Intelligence

This build keeps the stable v0.6.4 local Qwen runtime and adds a deterministic chart-intelligence layer for XAUUSD.

## New in v0.7.0
- Multi-timeframe 1M/5M/15M trend from loaded candles.
- Swing structure (HH/HL/LH/LL), BOS/CHOCH detection.
- Chart-derived support/resistance with touch clustering.
- Liquidity sweep / equal-high / equal-low detection.
- Recent FVG/imbalance detection.
- Momentum, ATR volatility, rejection/body read and recent range location.
- ZK AI context now receives the compact chart read instead of mostly raw feed metadata.
- Common prompts like “Analyse gold now”, “What do you see?” and “Explain structure” return a deterministic chart breakdown immediately, then normal local chat remains available for follow-ups.
- “Mark support resistance” uses chart-derived levels rather than arbitrary offsets.
- Chart page has an AI CHART READ strip and ASK AI button.

## Important data-source boundary
The embedded TradingView widget displays `ICMARKETS:XAUUSD` visually, but its protected iframe candle stream is not exposed to the native app. ZK AI therefore analyses the app's machine-readable XAU/USD candle feed. This gives the AI real chart structure and levels, but exact candle-for-candle equality with the TradingView IC Markets chart requires a broker-authorized IC Markets/cTrader/MT5 data connection later.

No trained trading decision model is enabled yet. Chart intelligence is analysis only.
