# ZK AI Native v0.6.4 — iOS Stability Runtime

This build targets the local-chat crash seen after `THINKING LOCALLY` on iPhone.

Key changes:
- replaces top-k/top-p/temperature sampler chain with llama.cpp's core greedy sampler
- samples from output `-1`, matching llama.cpp's official simple example
- explicit `n_ubatch = n_batch`
- strict CPU path (`offload_kqv = false`, `op_offload = false`, `n_gpu_layers = 0`)
- 1536-token context, 64-token physical/logical batch, 2 threads
- smaller 160-token reply ceiling
- tighter but still app-aware prompt context
- persistent runtime checkpoint so a native crash can be localized on next launch
- same Qwen2.5 0.5B Q4_K_M download; existing model should be reused on update

The conversational model is an explanation/analysis layer. It is not the future trained trading decision model and must not fabricate trade probabilities.
