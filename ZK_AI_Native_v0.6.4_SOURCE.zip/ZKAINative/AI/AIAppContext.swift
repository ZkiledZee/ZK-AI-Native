import Foundation

struct MarketFeatureSnapshot {
    let trend: String
    let structure: String
    let rsi14: Double?
    let atr14: Double?
    let ema20: Double?
    let ema50: Double?
    let momentum5: Double?
    let recentHigh: Double?
    let recentLow: Double?
}

enum MarketFeatureEngine {
    static func snapshot(candles: [ChartCandle]) -> MarketFeatureSnapshot {
        let ordered = candles.sorted { $0.timestamp < $1.timestamp }
        let closes = ordered.map(\.close)
        let ema20 = ema(closes, length: 20)
        let ema50 = ema(closes, length: 50)
        let rsi = rsi14(closes)
        let atr = atr14(ordered)
        let momentum: Double? = closes.count >= 6 ? closes.last! - closes[closes.count - 6] : nil
        let window = Array(ordered.suffix(30))
        let high = window.map(\.high).max()
        let low = window.map(\.low).min()

        let trend: String
        if let e20 = ema20, let e50 = ema50, let last = closes.last {
            if last > e20 && e20 > e50 { trend = "bullish" }
            else if last < e20 && e20 < e50 { trend = "bearish" }
            else { trend = "mixed/ranging" }
        } else { trend = "insufficient data" }

        return MarketFeatureSnapshot(
            trend: trend,
            structure: structure(ordered),
            rsi14: rsi,
            atr14: atr,
            ema20: ema20,
            ema50: ema50,
            momentum5: momentum,
            recentHigh: high,
            recentLow: low
        )
    }

    private static func ema(_ values: [Double], length: Int) -> Double? {
        guard values.count >= length, let first = values.first else { return nil }
        let alpha = 2.0 / Double(length + 1)
        var e = first
        for value in values.dropFirst() { e = alpha * value + (1 - alpha) * e }
        return e
    }

    private static func rsi14(_ closes: [Double]) -> Double? {
        guard closes.count >= 15 else { return nil }
        let recent = Array(closes.suffix(15))
        var gains = 0.0
        var losses = 0.0
        for i in 1..<recent.count {
            let d = recent[i] - recent[i - 1]
            if d >= 0 { gains += d } else { losses += -d }
        }
        let avgGain = gains / 14.0
        let avgLoss = losses / 14.0
        if avgLoss == 0 { return 100 }
        let rs = avgGain / avgLoss
        return 100 - (100 / (1 + rs))
    }

    private static func atr14(_ candles: [ChartCandle]) -> Double? {
        guard candles.count >= 15 else { return nil }
        let recent = Array(candles.suffix(15))
        var trs: [Double] = []
        for i in 1..<recent.count {
            let c = recent[i]
            let prev = recent[i - 1]
            let tr = max(c.high - c.low, abs(c.high - prev.close), abs(c.low - prev.close))
            trs.append(tr)
        }
        return trs.isEmpty ? nil : trs.reduce(0, +) / Double(trs.count)
    }

    private static func structure(_ candles: [ChartCandle]) -> String {
        guard candles.count >= 12 else { return "insufficient data" }
        var swingHighs: [Double] = []
        var swingLows: [Double] = []
        for i in 2..<(candles.count - 2) {
            let c = candles[i]
            if c.high > candles[i-1].high && c.high > candles[i-2].high && c.high >= candles[i+1].high && c.high >= candles[i+2].high {
                swingHighs.append(c.high)
            }
            if c.low < candles[i-1].low && c.low < candles[i-2].low && c.low <= candles[i+1].low && c.low <= candles[i+2].low {
                swingLows.append(c.low)
            }
        }
        guard swingHighs.count >= 2, swingLows.count >= 2 else { return "no clear swing sequence" }
        let h1 = swingHighs[swingHighs.count - 2], h2 = swingHighs.last!
        let l1 = swingLows[swingLows.count - 2], l2 = swingLows.last!
        if h2 > h1 && l2 > l1 { return "HH + HL" }
        if h2 < h1 && l2 < l1 { return "LH + LL" }
        if h2 > h1 && l2 < l1 { return "expanding/volatile" }
        return "compressed/mixed"
    }
}

@MainActor
enum AIAppContextBuilder {
    static func build(state: AppState, market: MarketDataService, toolNote: String? = nil) -> String {
        let f = MarketFeatureEngine.snapshot(candles: market.candles)
        var lines: [String] = []
        lines.append("App version: 0.6.4 stable local AI runtime")
        lines.append("Current screen: \(state.page.title)")
        lines.append("Machine-readable feed: \(market.sourceName) / \(market.feedStatus.rawValue), freshness \(market.freshnessText)")
        lines.append("Visible TradingView reference: ICMARKETS:XAUUSD, 1M; iframe internals not machine-readable")
        lines.append("Current price: \(money(market.currentPrice))")
        lines.append("Session: \(market.sessionName); loaded candles: \(market.candles.count) x 1M")
        lines.append("Loaded open/high/low/range: \(money(market.openPrice)) / \(money(market.dayHigh)) / \(money(market.dayLow)) / \(money(market.range))")
        lines.append("Native features: trend=\(f.trend), structure=\(f.structure), RSI14=\(num(f.rsi14)), ATR14=\(num(f.atr14)), EMA20=\(num(f.ema20)), EMA50=\(num(f.ema50)), 5-candle momentum=\(num(f.momentum5))")
        lines.append("Recent 30-candle high/low: \(money(f.recentHigh)) / \(money(f.recentLow))")

        lines.append("Trading signal engine: side=\(state.signal.side.rawValue), lifecycle=\(state.signal.lifecycle), reason=\(state.signal.reason)")
        lines.append("Signal probabilities: BUY \(pct(state.signal.buyProbability)), WAIT \(pct(state.signal.waitProbability)), SELL \(pct(state.signal.sellProbability)); execution confidence \(pct(state.signal.executionConfidence))")

        if let model = state.selectedModel {
            lines.append("Market model slot: \(model.name), status=\(model.status), evidence=\(model.evidence), train=\(model.trainRange), unseen=\(model.unseenRange), resolved trades=\(model.resolvedTrades)")
        } else {
            lines.append("Market model slot: none")
        }
        lines.append("Macro coverage: \(pct(state.macroCoverage)); regime=\(state.macroRegime)")
        lines.append("Trade journal count: \(state.journal.count)")

        if state.drawings.isEmpty {
            lines.append("Chart drawings: none")
        } else {
            let d = state.drawings.map { drawing in
                let second = drawing.secondaryPrice.map { "-\(String(format: "%.2f", $0))" } ?? ""
                return "\(drawing.kind.rawValue):\(drawing.label)@\(String(format: "%.2f", drawing.price))\(second)"
            }.joined(separator: ", ")
            lines.append("Chart drawings: \(d)")
        }

        let defaults = UserDefaults.standard
        lines.append("Settings: defaultChart=\(defaults.integer(forKey: "zk.settings.chartMode") == 0 ? "IC Markets TV" : "ZK Native"), signalTV=\(defaults.object(forKey: "zk.settings.signalTV") as? Bool ?? true), grid=\(defaults.object(forKey: "zk.settings.chartGrid") as? Bool ?? true), priceLine=\(defaults.object(forKey: "zk.settings.priceLine") as? Bool ?? true), momentumPan=\(defaults.object(forKey: "zk.settings.chartMomentum") as? Bool ?? true), refresh=\(max(defaults.integer(forKey: "zk.settings.refreshSeconds"), 30))s")

        if let result = defaults.string(forKey: "zk.backtest.integrityResult") {
            lines.append("Last backtest/data integrity result: \(result); \(defaults.string(forKey: "zk.backtest.integrityDetail") ?? "")")
        } else {
            lines.append("Last backtest/data integrity result: not run")
        }

        if let toolNote { lines.append("Deterministic app tool just executed: \(toolNote)") }

        let recent = market.candles.suffix(12).map { c in
            "\(time(c.timestamp)) O\(fmt(c.open)) H\(fmt(c.high)) L\(fmt(c.low)) C\(fmt(c.close))"
        }
        if !recent.isEmpty {
            lines.append("Latest native 1M OHLC (oldest→newest):\n" + recent.joined(separator: "\n"))
        }
        if let error = market.lastError { lines.append("Last market-feed error: \(error)") }
        return lines.joined(separator: "\n")
    }

    private static func fmt(_ x: Double) -> String { String(format: "%.2f", x) }
    private static func money(_ x: Double?) -> String { x.map { "$" + fmt($0) } ?? "unavailable" }
    private static func num(_ x: Double?) -> String { x.map { fmt($0) } ?? "unavailable" }
    private static func pct(_ x: Double) -> String { String(format: "%.0f%%", x * 100) }
    private static func time(_ date: Date) -> String {
        let f = DateFormatter(); f.dateFormat = "HH:mm"; return f.string(from: date)
    }
}

@MainActor
enum AIToolRouter {
    static func execute(query: String, state: AppState, market: MarketDataService) async -> String? {
        let q = query.lowercased()
        if q.contains("clear") && q.contains("drawing") {
            state.clearAllDrawings(); return "cleared all chart drawings"
        }
        if q.contains("remove") && q.contains("support") {
            state.removeSupport(); return "removed support drawings"
        }
        if q.contains("remove") && q.contains("resistance") {
            state.removeResistance(); return "removed resistance drawings"
        }
        if (q.contains("mark") || q.contains("draw") || q.contains("replace")) && (q.contains("support") || q.contains("resistance")) {
            state.replaceSupportResistance(around: market.currentPrice)
            return market.currentPrice == nil ? "support/resistance requested but no machine-readable live price was available" : "replaced support/resistance drawings around the latest native market price"
        }
        if (q.contains("mark") || q.contains("draw") || q.contains("add")) && q.contains("zone") {
            state.addZone(around: market.currentPrice)
            return market.currentPrice == nil ? "zone requested but no machine-readable live price was available" : "replaced the market zone around the latest native market price"
        }
        if q.contains("refresh") && (q.contains("market") || q.contains("data") || q.contains("price")) {
            await market.refreshAll(); return "refreshed the native market feed"
        }
        if q.contains("open chart") || q.contains("go to chart") { state.go(.chart); return "opened the Chart tab" }
        if q.contains("open signal") || q.contains("go to signal") { state.go(.signal); return "opened the Signal tab" }
        if q.contains("open backtest") || q.contains("go to backtest") { state.go(.backtest); return "opened the Backtest tab" }
        if q.contains("open settings") || q.contains("go to settings") { state.go(.settings); return "opened Settings" }
        return nil
    }
}
